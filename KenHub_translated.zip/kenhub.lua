--[[
🔥 KENHUB | ESP + INFINITE RANGE + TELEPORTS
✅ Smooth and safe teleport
✅ Total locations: 14
✅ Teleport menu in 4 columns
✅ Compatible with Delta and Arceus
]]

-- Basic settings
getgenv().SecureMode = true
getgenv().HideScript = false

-- Load Drawing
local Drawing = getgenv().Drawing or (syn and syn.Drawing) or (getgenv().getDrawing and getgenv().getDrawing()) or nil

-- Services
local Players = game:GetService("Players")
local RunService = game:GetService("RunService")
local StarterGui = game:GetService("StarterGui")
local TweenService = game:GetService("TweenService")
local UserInputService = game:GetService("UserInputService")
local Clipboard = getgenv().setclipboard or (syn and syn.setclipboard) or function() end

-- Wait for player to load
local LocalPlayer = Players.LocalPlayer
repeat task.wait(0.1) until LocalPlayer and LocalPlayer:IsDescendantOf(game)

local Character = LocalPlayer.Character or LocalPlayer.CharacterAdded:Wait()
local HRP = Character:WaitForChild("HumanoidRootPart", 15)
local Humanoid = Character:WaitForChild("Humanoid", 15)
local Camera = workspace.CurrentCamera

-- ⚙️ GENERAL SETTINGS
_G.Sistema = {
    LarguraMenu = 380,
    AlturaMenu = 420,
    MinLargura = 320,
    MaxLargura = 520,
    MinAltura = 350,
    MaxAltura = 550,
    VelocidadeCorrida = 16,
    Posicao1 = nil,
    Posicao2 = nil,
    JogadorEscolhido = nil,
    DistanciaPorPasso = 50,
    IntervaloEntrePassos = 0.14,
    TempoMovimento = 0.12,
    PararSePerto = 6,
    Teleportando = false,
    ESPAtivo = true,
    TrocarCor = true,
    VelocidadeCor = 0.004,
    MostrarLinha = true,
    MostrarNome = true,
    AlcanceMaximo = math.huge,
    FatorTamanhoESP = 12000,
    TamanhoMinimoESP = 2,
    TamanhoMaximoESP = 45,
    AimbotAtivo = false,
    Suavidade = 0.25,
    PontoMira = "Head",
    DesenharFOV = true,
    TamanhoFOV = 220,
    BypassAtivo = true,
    AtrasoAleatorio = true,
    TeclaAbrirFechar = Enum.KeyCode.Insert
}

-- Helper functions
local function EsperaSegura()
    if _G.Sistema.AtrasoAleatorio then
        task.wait(math.random(8, 18) / 100)
    else
        task.wait(0.1)
    end
end

local function AplicarVelocidade()
    if Character and Humanoid and Humanoid.Health > 0 then
        Humanoid.WalkSpeed = math.clamp(_G.Sistema.VelocidadeCorrida, 16, 220)
    end
end

-- 🚀 TELEPORT SYSTEM
local function TeleportarPassoAPasso(alvoPosicao)
    if _G.Sistema.Teleportando or not alvoPosicao then return end
    _G.Sistema.Teleportando = true
    Humanoid.PlatformStand = true

    task.spawn(function()
        while _G.Sistema.Teleportando and Character and HRP and Humanoid.Health > 0 do
            local posAtual = HRP.Position
            local direcao = (alvoPosicao - posAtual).Unit
            local distanciaTotal = (alvoPosicao - posAtual).Magnitude

            if distanciaTotal <= _G.Sistema.PararSePerto then break end

            local passo = math.min(_G.Sistema.DistanciaPorPasso, distanciaTotal)
            local novaPos = posAtual + direcao * passo
            novaPos = Vector3.new(novaPos.X, alvoPosicao.Y + 1.2, novaPos.Z)

            TweenService:Create(HRP, TweenInfo.new(_G.Sistema.TempoMovimento), {CFrame = CFrame.new(novaPos)}):Play()
            EsperaSegura()
        end

        Humanoid.PlatformStand = false
        _G.Sistema.Teleportando = false
        AplicarVelocidade()
    end)
end

local function PararTeleporte()
    _G.Sistema.Teleportando = false
    Humanoid.PlatformStand = false
    AplicarVelocidade()
end

local function Marcar1()
    if Character and HRP then
        _G.Sistema.Posicao1 = HRP.Position
        StarterGui:SetCore("SendNotification", {Title = "📌 Position 1", Text = "Saved", Duration = 2})
    end
end

local function Voltar1()
    if _G.Sistema.Teleportando or not _G.Sistema.Posicao1 then
        StarterGui:SetCore("SendNotification", {Title = "⚠️ Warning", Text = "No saved position", Duration = 2})
        return
    end
    TeleportarPassoAPasso(_G.Sistema.Posicao1)
end

local function Marcar2()
    if Character and HRP then
        _G.Sistema.Posicao2 = HRP.Position
        StarterGui:SetCore("SendNotification", {Title = "📌 Position 2", Text = "Saved", Duration = 2})
    end
end

local function Voltar2()
    if _G.Sistema.Teleportando or not _G.Sistema.Posicao2 then
        StarterGui:SetCore("SendNotification", {Title = "⚠️ Warning", Text = "No saved position", Duration = 2})
        return
    end
    TeleportarPassoAPasso(_G.Sistema.Posicao2)
end

local function SelecionarJogador()
    local lista = {}
    for _,j in ipairs(Players:GetPlayers()) do
        if j ~= LocalPlayer then table.insert(lista, j) end
    end
    if #lista == 0 then
        StarterGui:SetCore("SendNotification", {Title = "⚠️ Warning", Text = "No player found", Duration = 2})
        return
    end
    local indice = 1
    if _G.Sistema.JogadorEscolhido then
        for i,p in ipairs(lista) do if p == _G.Sistema.JogadorEscolhido then indice = i; break end end
    end
    indice = indice % #lista + 1
    _G.Sistema.JogadorEscolhido = lista[indice]
    StarterGui:SetCore("SendNotification", {Title = "👤 Selected", Text = _G.Sistema.JogadorEscolhido.Name, Duration = 2})
end

local function TeleportarParaJogador()
    if _G.Sistema.Teleportando then return end
    if not _G.Sistema.JogadorEscolhido or not _G.Sistema.JogadorEscolhido:IsDescendantOf(game) then return end
    local j = _G.Sistema.JogadorEscolhido
    if not j.Character or not j.Character:FindFirstChild("HumanoidRootPart") or j.Character.Humanoid.Health <= 0 then return end
    TeleportarPassoAPasso(j.Character.HumanoidRootPart.Position)
end

-- ✅ TODOS OS LOCAIS ATUALIZADOS
local function IrParaJungle()
    TeleportarPassoAPasso(Vector3.new(-1440.56, 65.83, 6.05))
    StarterGui:SetCore("SendNotification", {Title = "🌴 Teleportando", Text = "Jungle", Duration = 2})
end

local function IrParaCidadePirata()
    TeleportarPassoAPasso(Vector3.new(-1273.47, 13.21, 3981.66))
    StarterGui:SetCore("SendNotification", {Title = "🏴‍☠️ Teleportando", Text = "Pirate City", Duration = 2})
end

local function IrParaVilaDoDeserto()
    TeleportarPassoAPasso(Vector3.new(901.23, 10.08, 4383.97))
    StarterGui:SetCore("SendNotification", {Title = "🏜️ Teleportando", Text = "Desert Village", Duration = 2})
end

local function IrParaIlhaDeNeve()
    TeleportarPassoAPasso(Vector3.new(1350.13, 86.48, -1321.88))
    StarterGui:SetCore("SendNotification", {Title = "❄️ Teleportando", Text = "Snow Island", Duration = 2})
end

local function IrParaCeu1()
    TeleportarPassoAPasso(Vector3.new(-4805.24, 768.96, -2664.80))
    StarterGui:SetCore("SendNotification", {Title = "☁️ Teleportando", Text = "CEU-1", Duration = 2})
end

local function IrParaCeu2()
    TeleportarPassoAPasso(Vector3.new(-4811.17, 904.78, -1912.79))
    StarterGui:SetCore("SendNotification", {Title = "☁️ Teleportando", Text = "CEU-2", Duration = 2})
end

local function IrParaCeu3()
    TeleportarPassoAPasso(Vector3.new(-4627.03, 856.15, -1708.92))
    StarterGui:SetCore("SendNotification", {Title = "☁️ Teleportando", Text = "CEU-3", Duration = 2})
end

local function IrParaIlhaParadisaca()
    TeleportarPassoAPasso(Vector3.new(-2859.69, 52.44, 5377.21))
    StarterGui:SetCore("SendNotification", {Title = "🏝️ Teleportando", Text = "Paradise Island", Duration = 2})
end

local function IrParaPrisao()
    TeleportarPassoAPasso(Vector3.new(5431.83, 161.33, 782.56))
    StarterGui:SetCore("SendNotification", {Title = "🔒 Teleportando", Text = "Prison", Duration = 2})
end

local function IrParaColosseum()
    TeleportarPassoAPasso(Vector3.new(-1524.02, 78.98, -2909.82))
    StarterGui:SetCore("SendNotification", {Title = "🏟️ Teleportando", Text = "Colosseum", Duration = 2})
end

local function IrParaIlhaDaFonte()
    TeleportarPassoAPasso(Vector3.new(5667.34, 579.57, 4300.10))
    StarterGui:SetCore("SendNotification", {Title = "💧 Teleportando", Text = "Fountain Island", Duration = 2})
end

local function IrParaCidadeAquatica()
    TeleportarPassoAPasso(Vector3.new(4051.38, -0.04, -1814.59))
    StarterGui:SetCore("SendNotification", {Title = "🌊 Teleportando", Text = "Water City", Duration = 2})
end

local function IrParaMarinhaForte()
    TeleportarPassoAPasso(Vector3.new(-5125.26, 294.48, 4432.10))
    StarterGui:SetCore("SendNotification", {Title = "⚓ Teleportando", Text = "Marine Fortress", Duration = 2})
end

local function IrParaIlhaDoVulcao()
    TeleportarPassoAPasso(Vector3.new(-5513.82, 62.62, 8577.85))
    StarterGui:SetCore("SendNotification", {Title = "🌋 Teleportando", Text = "Volcano Island", Duration = 2})
end

-- Copy Coordinates
local function CopiarCoordenadas()
    if not HRP then return end
    local pos = HRP.Position
    local texto = string.format("Vector3.new(%.2f, %.2f, %.2f)", pos.X, pos.Y, pos.Z)
    Clipboard(texto)
    StarterGui:SetCore("SendNotification", {Title = "📋 Copied!", Text = texto, Duration = 2})
end

-- 🎯 AIMBOT AND FOV
local CirculoFOV = nil
if Drawing then
    CirculoFOV = Drawing.new("Circle")
    CirculoFOV.Visible = false
    CirculoFOV.Radius = _G.Sistema.TamanhoFOV
    CirculoFOV.Thickness = 2
    CirculoFOV.Filled = false
end

local function PegarPontoAlvo(personagem)
    if not personagem then return nil end
    if _G.Sistema.PontoMira == "Head" and personagem:FindFirstChild("Head") then
        return personagem.Head.Position
    elseif _G.Sistema.PontoMira == "Chest" and personagem:FindFirstChild("UpperTorso") then
        return personagem.UpperTorso.Position
    elseif _G.Sistema.PontoMira == "Legs" and personagem:FindFirstChild("LowerTorso") then
        return personagem.LowerTorso.Position
    else
        return personagem.HumanoidRootPart.Position
    end
end

local function EncontrarAlvo()
    local melhorPonto = nil
    local menorDist = math.huge
    local centro = Vector2.new(Camera.ViewportSize.X / 2, Camera.ViewportSize.Y / 2)
    for _,j in ipairs(Players:GetPlayers()) do
        if j == LocalPlayer then continue end
        local char = j.Character
        if not char or not char:FindFirstChild("HumanoidRootPart") or not char.Humanoid or char.Humanoid.Health <= 0 then continue end
        local pos = PegarPontoAlvo(char)
        local visTela, _ = Camera:WorldToViewportPoint(pos)
        if visTela.Z > 0 then
            local distTela = (Vector2.new(visTela.X, visTela.Y) - centro).Magnitude
            if distTela < _G.Sistema.TamanhoFOV and distTela < menorDist then
                menorDist = distTela
                melhorPonto = pos
            end
        end
    end
    return melhorPonto
end

-- 🎛️ MAIN INTERFACE
local Gui = Instance.new("ScreenGui")
Gui.Name = "WM_Delta"
Gui.ResetOnSpawn = false
Gui.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
Gui.IgnoreGuiInset = true
Gui.Parent = LocalPlayer:WaitForChild("PlayerGui", 15)

-- MAIN MENU
local Menu = Instance.new("Frame")
Menu.Size = UDim2.new(0, _G.Sistema.LarguraMenu, 0, _G.Sistema.AlturaMenu)
Menu.Position = UDim2.new(0.05, 0, 0.15, 0)
Menu.BackgroundColor3 = Color3.new(0.12, 0.12, 0.15)
Menu.BorderSizePixel = 2
Menu.BorderColor3 = Color3.new(0.8, 0, 0)
Menu.Active = true
Menu.Draggable = true
Menu.Visible = true
Menu.Parent = Gui

local Topo = Instance.new("Frame")
Topo.Size = UDim2.new(1, 0, 0, 35)
Topo.BackgroundColor3 = Color3.new(0.2, 0, 0)
Topo.BorderSizePixel = 0
Topo.Parent = Menu

local Titulo = Instance.new("TextLabel")
Titulo.Size = UDim2.new(0.75, 0, 1, 0)
Titulo.Position = UDim2.new(0.03, 0, 0, 0)
Titulo.Text = "🔥 KENHUB"
Titulo.Font = Enum.Font.GothamBold
Titulo.TextSize = 15
Titulo.TextColor3 = Color3.new(1,1,1)
Titulo.BackgroundTransparency = 1
Titulo.Parent = Topo

local BtnFechar = Instance.new("TextButton")
BtnFechar.Size = UDim2.new(0, 30, 0, 28)
BtnFechar.Position = UDim2.new(0.91, 0, 0.1, 0)
BtnFechar.Text = "X"
BtnFechar.Font = Enum.Font.GothamBold
BtnFechar.TextColor3 = Color3.new(1,1,1)
BtnFechar.BackgroundColor3 = Color3.new(0.7, 0, 0)
BtnFechar.Parent = Topo

local BtnAbrir = Instance.new("TextButton")
BtnAbrir.Size = UDim2.new(0, 42, 0, 42)
BtnAbrir.Position = UDim2.new(0.01, 0, 0.05, 0)
BtnAbrir.Text = "⚙️"
BtnAbrir.Font = Enum.Font.GothamBold
BtnAbrir.TextSize = 18
BtnAbrir.TextColor3 = Color3.new(1,1,1)
BtnAbrir.BackgroundColor3 = Color3.new(0.18, 0.18, 0.22)
BtnAbrir.BorderSizePixel = 2
BtnAbrir.BorderColor3 = Color3.new(0.8, 0, 0)
BtnAbrir.Active = true
BtnAbrir.Draggable = true
BtnAbrir.Visible = false
BtnAbrir.Parent = Gui

-- ✅ TELEPORT MENU IN 4 COLUMNS
local MenuTeleportes = Instance.new("Frame")
MenuTeleportes.Size = UDim2.new(0, 420, 0, 280)
MenuTeleportes.Position = UDim2.new(0.06, 0, 0.16, 0)
MenuTeleportes.BackgroundColor3 = Color3.new(0.1, 0.1, 0.13)
MenuTeleportes.BorderSizePixel = 2
MenuTeleportes.BorderColor3 = Color3.new(0, 0.7, 0.7)
MenuTeleportes.Active = true
MenuTeleportes.Draggable = true
MenuTeleportes.Visible = false
MenuTeleportes.Parent = Gui

local TopoTeleportes = Instance.new("Frame")
TopoTeleportes.Size = UDim2.new(1, 0, 0, 30)
TopoTeleportes.BackgroundColor3 = Color3.new(0, 0.5, 0.5)
TopoTeleportes.BorderSizePixel = 0
TopoTeleportes.Parent = MenuTeleportes

local TituloTeleportes = Instance.new("TextLabel")
TituloTeleportes.Size = UDim2.new(0.8, 0, 1, 0)
TituloTeleportes.Position = UDim2.new(0.05, 0, 0, 0)
TituloTeleportes.Text = "📍 Quick Teleports"
TituloTeleportes.Font = Enum.Font.GothamBold
TituloTeleportes.TextSize = 13
TituloTeleportes.TextColor3 = Color3.new(1,1,1)
TituloTeleportes.BackgroundTransparency = 1
TituloTeleportes.Parent = TopoTeleportes

local BtnFecharTeleportes = Instance.new("TextButton")
BtnFecharTeleportes.Size = UDim2.new(0, 25, 0, 22)
BtnFecharTeleportes.Position = UDim2.new(0.90, 0, 0.12, 0)
BtnFecharTeleportes.Text = "X"
BtnFecharTeleportes.Font = Enum.Font.GothamBold
BtnFecharTeleportes.TextColor3 = Color3.new(1,1,1)
BtnFecharTeleportes.BackgroundColor3 = Color3.new(0.6, 0, 0)
BtnFecharTeleportes.Parent = TopoTeleportes

-- Location list organized in 4 columns
local locais = {
    {texto = "🌴 Jungle", funcao = IrParaJungle, x = 0.03, y = 0.15},
    {texto = "🏴‍☠️ Pirate City", funcao = IrParaCidadePirata, x = 0.26, y = 0.15},
    {texto = "🏜️ Desert Village", funcao = IrParaVilaDoDeserto, x = 0.49, y = 0.15},
    {texto = "❄️ Snow Island", funcao = IrParaIlhaDeNeve, x = 0.72, y = 0.15},
    {texto = "☁️ CEU-1", funcao = IrParaCeu1, x = 0.03, y = 0.32},
    {texto = "☁️ CEU-2", funcao = IrParaCeu2, x = 0.26, y = 0.32},
    {texto = "☁️ CEU-3", funcao = IrParaCeu3, x = 0.49, y = 0.32},
    {texto = "🏝️ Paradise Island", funcao = IrParaIlhaParadisaca, x = 0.72, y = 0.32},
    {texto = "🔒 Prison", funcao = IrParaPrisao, x = 0.03, y = 0.49},
    {texto = "🏟️ Colosseum", funcao = IrParaColosseum, x = 0.26, y = 0.49},
    {texto = "💧 Fountain Island", funcao = IrParaIlhaDaFonte, x = 0.49, y = 0.49},
    {texto = "🌊 Water City", funcao = IrParaCidadeAquatica, x = 0.72, y = 0.49},
    {texto = "⚓ Marine Fortress", funcao = IrParaMarinhaForte, x = 0.03, y = 0.66},
    {texto = "🌋 Volcano Island", funcao = IrParaIlhaDoVulcao, x = 0.26, y = 0.66}
}

for _, info in ipairs(locais) do
    local btn = Instance.new("TextButton")
    btn.Size = UDim2.new(0.22, 0, 0, 28)
    btn.Position = UDim2.new(info.x, 0, info.y, 0)
    btn.Text = info.texto
    btn.Font = Enum.Font.GothamBold
    btn.TextSize = 10
    btn.TextColor3 = Color3.new(1,1,1)
    btn.BackgroundColor3 = Color3.new(0.18, 0.18, 0.22)
    btn.BorderSizePixel = 1
    btn.BorderColor3 = Color3.new(0, 0.7, 0.7)
    btn.Parent = MenuTeleportes
    btn.MouseButton1Click:Connect(info.funcao)
end

-- Toggle visibility
local function AlternarMenuPrincipal()
    Menu.Visible = not Menu.Visible
    BtnAbrir.Visible = not Menu.Visible
    if not Menu.Visible then MenuTeleportes.Visible = false end
end
BtnFechar.MouseButton1Click:Connect(AlternarMenuPrincipal)
BtnAbrir.MouseButton1Click:Connect(AlternarMenuPrincipal)

local function AlternarMenuTeleportes()
    MenuTeleportes.Visible = not MenuTeleportes.Visible
end
BtnFecharTeleportes.MouseButton1Click:Connect(AlternarMenuTeleportes)

-- Coordinate Panel
local PainelCoords = Instance.new("Frame")
PainelCoords.Size = UDim2.new(0, 280, 0, 40)
PainelCoords.Position = UDim2.new(0.98, -285, 0.02, 0)
PainelCoords.BackgroundColor3 = Color3.new(0.15, 0.15, 0.18)
PainelCoords.BorderSizePixel = 1
PainelCoords.BorderColor3 = Color3.new(0.7, 0, 0)
PainelCoords.Active = true
PainelCoords.Draggable = true
PainelCoords.Parent = Gui

local TextoCoords = Instance.new("TextLabel")
TextoCoords.Size = UDim2.new(0.75, 0, 1, 0)
TextoCoords.Position = UDim2.new(0.02, 0, 0, 0)
TextoCoords.Text = "X: 0.00 | Y: 0.00 | Z: 0.00"
TextoCoords.Font = Enum.Font.GothamBold
TextoCoords.TextSize = 12
TextoCoords.TextColor3 = Color3.new(1,1,1)
TextoCoords.BackgroundTransparency = 1
TextoCoords.Parent = PainelCoords

local BtnCopiar = Instance.new("TextButton")
BtnCopiar.Size = UDim2.new(0.22, 0, 0.8, 0)
BtnCopiar.Position = UDim2.new(0.76, 0, 0.1, 0)
BtnCopiar.Text = "📋"
BtnCopiar.Font = Enum.Font.GothamBold
BtnCopiar.TextSize = 14
BtnCopiar.TextColor3 = Color3.new(1,1,1)
BtnCopiar.BackgroundColor3 = Color3.new(0, 0.5, 0.7)
BtnCopiar.Parent = PainelCoords
BtnCopiar.MouseButton1Click:Connect(CopiarCoordenadas)

local function AtualizarTamanhoMenu()
    Menu.Size = UDim2.new(0, _G.Sistema.LarguraMenu, 0, _G.Sistema.AlturaMenu)
end

-- ✅ MAIN BUTTONS IN 4 COLUMNS
local Botoes = {
    {Texto = "📌 Mark 1", Pos = UDim2.new(0.03,0,0,45), Funcao = Marcar1},
    {Texto = "🔙 Return 1", Pos = UDim2.new(0.27,0,0,45), Funcao = Voltar1},
    {Texto = "📌 Mark 2", Pos = UDim2.new(0.51,0,0,45), Funcao = Marcar2},
    {Texto = "🔙 Return 2", Pos = UDim2.new(0.75,0,0,45), Funcao = Voltar2},
    {Texto = "👤 Select", Pos = UDim2.new(0.03,0,0,78), Funcao = SelecionarJogador},
    {Texto = "🚀 Teleport", Pos = UDim2.new(0.27,0,0,78), Funcao = TeleportarParaJogador},
    {Texto = "🛑 Stop", Pos = UDim2.new(0.51,0,0,78), Funcao = PararTeleporte},
    {Texto = "👁️ ESP: ON", Pos = UDim2.new(0.75,0,0,78)},
    {Texto = "🎯 AIM: OFF", Pos = UDim2.new(0.03,0,0,111)},
    {Texto = "📍 Aim: Head", Pos = UDim2.new(0.27,0,0,111)},
    {Texto = "🏃 Vel: 16", Pos = UDim2.new(0.51,0,0,111)},
    {Texto = "⭕ FOV: 220", Pos = UDim2.new(0.75,0,0,111)},
    {Texto = "💨 Smooth: 0.25", Pos = UDim2.new(0.03,0,0,144)},
    {Texto = "🛡️ BYPASS: ON", Pos = UDim2.new(0.27,0,0,144)},
    {Texto = "⚡ Teleports", Pos = UDim2.new(0.51,0,0,144), Funcao = AlternarMenuTeleportes},
    {Texto = "📋 Copy", Pos = UDim2.new(0.75,0,0,144), Funcao = CopiarCoordenadas},
    {Texto = "⬅️ Width -", Pos = UDim2.new(0.03,0,0,177), Funcao = function() _G.Sistema.LarguraMenu = math.max(_G.Sistema.MinLargura, _G.Sistema.LarguraMenu - 20); AtualizarTamanhoMenu() end},
    {Texto = "➡️ Width +", Pos = UDim2.new(0.27,0,0,177), Funcao = function() _G.Sistema.LarguraMenu = math.min(_G.Sistema.MaxLargura, _G.Sistema.LarguraMenu + 20); AtualizarTamanhoMenu() end},
    {Texto = "⬇️ Height -", Pos = UDim2.new(0.51,0,0,177), Funcao = function() _G.Sistema.AlturaMenu = math.max(_G.Sistema.MinAltura, _G.Sistema.AlturaMenu - 25); AtualizarTamanhoMenu() end},
    {Texto = "⬆️ Height +", Pos = UDim2.new(0.75,0,0,177), Funcao = function() _G.Sistema.AlturaMenu = math.min(_G.Sistema.MaxAltura, _G.Sistema.AlturaMenu + 25); AtualizarTamanhoMenu() end}
}

local Criados = {}
for i, info in ipairs(Botoes) do
    local btn = Instance.new("TextButton")
    btn.Size = UDim2.new(0.22, 0, 0, 28)
    btn.Position = info.Pos
    btn.Text = info.Texto
    btn.BackgroundColor3 = Color3.new(0.23, 0.23, 0.26)
    btn.TextColor3 = Color3.new(1,1,1)
    btn.Font = Enum.Font.GothamBold
    btn.TextSize = 10
    btn.Parent = Menu
    Criados[i] = btn
    if info.Funcao then btn.MouseButton1Click:Connect(info.Funcao) end
end

-- Controles dos botões
Criados[8].MouseButton1Click:Connect(function() _G.Si
