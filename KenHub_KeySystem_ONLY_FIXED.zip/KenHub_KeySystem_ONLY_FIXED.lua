local e=game:GetService( "Players" )
local r=game:GetService( "Workspace" )
local y=game:GetService( "RunService" )
local u=game:GetService( "TweenService" )
local w=game:GetService( "UserInputService" )
local j=game:GetService( "ReplicatedStorage" )
local k=game:GetService( "ProximityPromptService" )
local a=game:GetService( "HttpService" )
local TeleportService=game:GetService( "TeleportService" )
local o=e.LocalPlayer

--// Ken Hub 24H Key Gate
--// The linked page currently generates keys in the format KENHUB-<16 HEX>-24H.
--// This gate caches a successfully entered key for 24 hours on the executor filesystem.
local KENHUB_KEY_PAGE = "https://jinwoosung555.github.io/Keysystem/"
local KENHUB_DISCORD = "https://discord.gg/NfVDJeNUc"
local KENHUB_KEY_FILE = "KenHub_Access_v2.dat"
local KENHUB_KEY_TTL = 24 * 60 * 60

local function kenHubReadKeyCache()
    if type(readfile) ~= "function" then return nil, nil end
    local ok, raw = pcall(readfile, KENHUB_KEY_FILE)
    if not ok or type(raw) ~= "string" then return nil, nil end
    local key, expiry = raw:match("^(.-)|(%d+)$")
    expiry = tonumber(expiry)
    if key and expiry and expiry > os.time() then
        return key, expiry
    end
    return nil, nil
end

local function kenHubSaveKey(key)
    if type(writefile) ~= "function" then return false end
    local expiry = os.time() + KENHUB_KEY_TTL
    local ok = pcall(writefile, KENHUB_KEY_FILE, key .. "|" .. tostring(expiry))
    return ok
end

local function kenHubLooksLikeKey(key)
    return type(key) == "string" and key:match("^KENHUB%-%x%x%x%x%x%x%x%x%x%x%x%x%x%x%x%x%-24H$") ~= nil
end

local function kenHubOpenKeyPage()
    pcall(function()
        if type(setclipboard) == "function" then
            setclipboard(KENHUB_KEY_PAGE)
        end
    end)
    pcall(function()
        if game:GetService("GuiService").OpenBrowserWindow then
            game:GetService("GuiService"):OpenBrowserWindow(KENHUB_KEY_PAGE)
        end
    end)
end

local function kenHubKeyGate()
    -- Show the key prompt whenever there is no valid, unexpired cached key.
    -- A valid redeemed key is cached for 24 hours, then the prompt returns.
    local cachedKey, cachedExpiry = kenHubReadKeyCache()
    if cachedKey and cachedExpiry and kenHubLooksLikeKey(cachedKey) then
        return true
    end

    local CoreGui = game:GetService("CoreGui")
    local guiParent = CoreGui

    pcall(function()
        if type(gethui) == "function" then
            local h = gethui()
            if h then
                guiParent = h
            end
        end
    end)

    pcall(function()
        local old = guiParent:FindFirstChild("KenHubKeyGate")
        if old then
            old:Destroy()
        end
    end)

    local gui = Instance.new("ScreenGui")
    gui.Name = "KenHubKeyGate"
    gui.ResetOnSpawn = false
    gui.IgnoreGuiInset = true
    gui.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
    gui.Parent = guiParent

    local overlay = Instance.new("Frame")
    overlay.Size = UDim2.fromScale(1, 1)
    overlay.BackgroundColor3 = Color3.fromRGB(5, 7, 12)
    overlay.BackgroundTransparency = 0.08
    overlay.Parent = gui

    local card = Instance.new("Frame")
    card.AnchorPoint = Vector2.new(0.5, 0.5)
    card.Position = UDim2.fromScale(0.5, 0.5)
    card.Size = UDim2.fromOffset(440, 320)
    card.BackgroundColor3 = Color3.fromRGB(15, 18, 27)
    card.BorderSizePixel = 0
    card.Parent = overlay
    Instance.new("UICorner", card).CornerRadius = UDim.new(0, 18)

    local stroke = Instance.new("UIStroke", card)
    stroke.Color = Color3.fromRGB(65, 75, 100)
    stroke.Transparency = 0.35
    stroke.Thickness = 1

    local scale = Instance.new("UIScale", card)
    scale.Scale = 0.92
    u:Create(scale, TweenInfo.new(0.35, Enum.EasingStyle.Quint, Enum.EasingDirection.Out), {Scale = 1}):Play()

    local top = Instance.new("Frame")
    top.Size = UDim2.new(1, 0, 0, 7)
    top.BackgroundColor3 = Color3.fromRGB(99, 102, 241)
    top.BorderSizePixel = 0
    top.Parent = card
    Instance.new("UICorner", top).CornerRadius = UDim.new(0, 18)

    local title = Instance.new("TextLabel")
    title.BackgroundTransparency = 1
    title.Position = UDim2.fromOffset(24, 28)
    title.Size = UDim2.new(1, -48, 0, 32)
    title.Font = Enum.Font.GothamBold
    title.Text = "KEN HUB  •  ACCESS REQUIRED"
    title.TextColor3 = Color3.fromRGB(245, 247, 255)
    title.TextSize = 19
    title.TextXAlignment = Enum.TextXAlignment.Left
    title.Parent = card

    local sub = Instance.new("TextLabel")
    sub.BackgroundTransparency = 1
    sub.Position = UDim2.fromOffset(24, 65)
    sub.Size = UDim2.new(1, -48, 0, 38)
    sub.Font = Enum.Font.Gotham
    sub.Text = "Join our Discord server to get your free 24H key.\nThen redeem it below to unlock Ken Hub."
    sub.TextColor3 = Color3.fromRGB(155, 165, 185)
    sub.TextSize = 12
    sub.TextWrapped = true
    sub.TextXAlignment = Enum.TextXAlignment.Left
    sub.Parent = card

    local input = Instance.new("TextBox")
    input.Position = UDim2.fromOffset(24, 118)
    input.Size = UDim2.new(1, -48, 0, 45)
    input.BackgroundColor3 = Color3.fromRGB(24, 28, 40)
    input.BorderSizePixel = 0
    input.ClearTextOnFocus = false
    input.Font = Enum.Font.GothamMedium
    input.PlaceholderText = "Enter your 24H key..."
    input.PlaceholderColor3 = Color3.fromRGB(105, 115, 135)
    input.Text = ""
    input.TextColor3 = Color3.fromRGB(235, 240, 250)
    input.TextSize = 13
    input.Parent = card
    Instance.new("UICorner", input).CornerRadius = UDim.new(0, 10)
    Instance.new("UIStroke", input).Color = Color3.fromRGB(55, 65, 85)

    local getKey = Instance.new("TextButton")
    getKey.Position = UDim2.fromOffset(24, 176)
    getKey.Size = UDim2.new(0.48, -30, 0, 43)
    getKey.BackgroundColor3 = Color3.fromRGB(31, 36, 52)
    getKey.BorderSizePixel = 0
    getKey.Font = Enum.Font.GothamBold
    getKey.Text = "JOIN DISCORD"
    getKey.TextColor3 = Color3.fromRGB(220, 225, 240)
    getKey.TextSize = 12
    getKey.AutoButtonColor = false
    getKey.Parent = card
    Instance.new("UICorner", getKey).CornerRadius = UDim.new(0, 10)

    local redeem = Instance.new("TextButton")
    redeem.Position = UDim2.new(0.52, 6, 0, 176)
    redeem.Size = UDim2.new(0.48, -30, 0, 43)
    redeem.BackgroundColor3 = Color3.fromRGB(99, 102, 241)
    redeem.BorderSizePixel = 0
    redeem.Font = Enum.Font.GothamBold
    redeem.Text = "REDEEM KEY"
    redeem.TextColor3 = Color3.new(1, 1, 1)
    redeem.TextSize = 12
    redeem.AutoButtonColor = false
    redeem.Parent = card
    Instance.new("UICorner", redeem).CornerRadius = UDim.new(0, 10)

    local status = Instance.new("TextLabel")
    status.BackgroundTransparency = 1
    status.Position = UDim2.fromOffset(24, 229)
    status.Size = UDim2.new(1, -48, 0, 30)
    status.Font = Enum.Font.Gotham
    status.Text = "KEY REQUIRED • 24H ACCESS"
    status.TextColor3 = Color3.fromRGB(120, 130, 150)
    status.TextSize = 10
    status.TextXAlignment = Enum.TextXAlignment.Center
    status.Parent = card

    local redeemLink = Instance.new("TextButton")
    redeemLink.BackgroundTransparency = 1
    redeemLink.Position = UDim2.fromOffset(24, 266)
    redeemLink.Size = UDim2.new(1, -48, 0, 30)
    redeemLink.Font = Enum.Font.GothamMedium
    redeemLink.Text = "REDEEM KEY  •  KEYSYSTEM"
    redeemLink.TextColor3 = Color3.fromRGB(140, 150, 255)
    redeemLink.TextSize = 11
    redeemLink.AutoButtonColor = false
    redeemLink.Parent = card

    redeemLink.MouseButton1Click:Connect(function()
        kenHubOpenKeyPage()
        status.Text = "KEYSYSTEM OPENED • PASTE YOUR KEY ABOVE"
        status.TextColor3 = Color3.fromRGB(120, 200, 255)
    end)

    local function hover(button, base, active)
        button.MouseEnter:Connect(function()
            u:Create(button, TweenInfo.new(0.16, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {BackgroundColor3 = active}):Play()
        end)
        button.MouseLeave:Connect(function()
            u:Create(button, TweenInfo.new(0.16, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {BackgroundColor3 = base}):Play()
        end)
    end

    hover(getKey, Color3.fromRGB(31,36,52), Color3.fromRGB(43,49,68))
    hover(redeem, Color3.fromRGB(99,102,241), Color3.fromRGB(118,120,255))

    local unlocked = false

    getKey.MouseButton1Click:Connect(function()
        kenHubOpenKeyPage()
        status.Text = "KEY PAGE OPENED • COPY YOUR 24H KEY"
        status.TextColor3 = Color3.fromRGB(120, 200, 255)
    end)

    redeem.MouseButton1Click:Connect(function()
        local key = tostring(input.Text or ""):upper():gsub("%s+", "")

        if not kenHubLooksLikeKey(key) then
            status.Text = "INVALID KEY FORMAT • USE THE OFFICIAL KEY PAGE"
            status.TextColor3 = Color3.fromRGB(255, 110, 120)
            u:Create(card, TweenInfo.new(0.05, Enum.EasingStyle.Linear), {Position = UDim2.fromScale(0.505, 0.5)}):Play()
            task.delay(0.06, function()
                u:Create(card, TweenInfo.new(0.18, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {Position = UDim2.fromScale(0.5, 0.5)}):Play()
            end)
            return
        end

        redeem.Text = "VERIFYING..."
        redeem.Active = false
        status.Text = "KEY ACCEPTED • SAVING 24H ACCESS..."
        status.TextColor3 = Color3.fromRGB(100, 230, 165)
        task.wait(0.35)

        if not kenHubSaveKey(key) then
            status.Text = "COULD NOT SAVE ACCESS • EXECUTOR FILE API REQUIRED"
            status.TextColor3 = Color3.fromRGB(255, 180, 90)
            redeem.Text = "REDEEM KEY"
            redeem.Active = true
            return
        end

        unlocked = true
        u:Create(scale, TweenInfo.new(0.25, Enum.EasingStyle.Back, Enum.EasingDirection.In), {Scale = 0.92}):Play()
        u:Create(overlay, TweenInfo.new(0.25, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {BackgroundTransparency = 1}):Play()
        task.wait(0.28)
        gui:Destroy()
    end)

    repeat task.wait() until unlocked
    return true
end

if not kenHubKeyGate() then
    return
end
local Window=nil
local currentLang="EN"
local executorCheckCaller=typeof(checkcaller)=="function" and checkcaller or function() return false end
local safeNewCClosure=typeof(newcclosure)=="function" and newcclosure or function(fn) return fn end
local V=game:GetService( "ProximityPromptService" )pcall(function(...) V.PromptButtonHoldBegan :Connect(function(e,...) pcall(function(...)
            if typeof(fireproximityprompt)== "function" then
                fireproximityprompt(e)
            end
        end
        )
    end
    )
end
)
local H=function(...)
end
local t=function(...)
end
local s=nil pcall(function(...) s=require((j:WaitForChild( "Client" , 5 )):WaitForChild( "EggState" , 5 ))
end
)
if not s then
    pcall(function(...) s=require(j.Client.EggState )
    end
    )
end
local p=nil pcall(function(...) p=require(((j:WaitForChild( "Shared" , 5 )):WaitForChild( "Util" , 5 )):WaitForChild( "AssetItems" , 5 ))
end
)
if not p then
    pcall(function(...) p=require(j.Shared.Util .AssetItems )
    end
    )
end
local B=nil pcall(function(...) B=require((j:WaitForChild( "Shared" , 5 )):WaitForChild( "Remotes" , 5 ))
end
)
if not B then
    pcall(function(...) B=require(j.Shared.Remotes )
    end
    )
end
local function J(e,r,...)
    local y=(j:FindFirstChild( "Packages" )and j.Packages :FindFirstChild( "Networking" ))or j:FindFirstChild( "Network" )or j
    local u=y:FindFirstChild(e)or j:FindFirstChild(e)
    if u then
        return u
    end
    local w=y:FindFirstChild(e, true )or j:FindFirstChild(e, true )
    if w then
        return w
    end
    if r then
        local e=y:FindFirstChild(r)or j:FindFirstChild(r)
        if e then
            return e
        end
        local u=y:FindFirstChild(r, true )or j:FindFirstChild(r, true )
        if u then
            return u
        end
    end
    local k=string.match (e, "[^/]+$" )
    if k then
        local e=y:FindFirstChild(k, true )or j:FindFirstChild(k, true )
        if e then
            return e
        end
    end
    return nil
end

local K=J( "RF/EggWorld/AskPlaceEgg" , "AskPlaceEgg" ) 
local c=J( "RF/EggWorld/AskLiveSnapshot" , "AskLiveSnapshot" ) 
local v=J( "RF/Homestead/AskState" , "RF/Plots/AskState" )or J( "AskState" )
local i=J( "RF/EggWorld/AskFieldEggCarry" , "AskFieldEggCarry" ) 
local R=J( "RF/EggWorld/AskFieldEggSnapshot" , "AskFieldEggSnapshot" )or J( "Eggs: RequestAreaEggSnapshot" , "RequestAreaEggSnapshot" )
local g=J( "RF/EggWorld/AskHatch" , "AskHatch" )or J( "Eggs: RequestHatchEgg" )
local Q=J( "RF/EggWorld/AskFinishHatch" , "AskFinishHatch" )or J( "Eggs: RequestCompleteHatchEgg" )
local P=J( "RE/GuardPatrol/ForestStrike" , "ForestStrike" )or(B and(B.GuardPatrol and B.GuardPatrol.ForestStrike ))
local N=J( "SpeedTollOffer" , "RE/GuardPatrol/SpeedTollOffer" )or(B and(B.GuardPatrol and B.GuardPatrol.SpeedTollOffer ))
local U=J( "RF/Treadmill/AskDoff" , "AskDoff" )
local l=J( "RF/Treadmill/AskDon" , "AskDon" )or J( "RF/Treadmill/AskMount" , "AskMount" )
local D=J( "RF/Treadmill/AskTierRaise" , "Treadmills: RequestUpgrade" , "AskTierRaise" )
local C=J( "RF/Trailwear/AskPurchase" , "Trailwear: RequestPurchase" , "AskPurchase" )
local q=J( "RF/Trailwear/AskChoose" , "Trailwear: RequestEquip" , "AskChoose" )
local n=J( "RF/Trailwear/AskDoff" , "Trailwear: RequestUnequip" , "AskDoff" )H(string.format ( "[RemoteCheck] Carry: %s | Snapshot: %s | Place: %s | Hatch: %s | FinishHatch: %s | Strike: %s | Toll: %s | Doff: %s" ,tostring(i~=nil),tostring(R~=nil),tostring(K~=nil),tostring(g~=nil),tostring(Q~=nil),tostring(P~=nil),tostring(N~=nil),tostring(U~=nil)))

local f={[ "Light Dark" ]= 1300 ,[ "LightDark" ]= 1300 ;
[ "Titan Temple" ]= 1100 ,[ "Cherry Blossom" ]= 1000 ,[ "Cosmic" ]= 900 ;
[ "Prehistoric" ]= 800 ;
[ "Abyss Ocean" ]= 700 ,[ "Volcano" ]= 600 ;
[ "Snow" ]= 500 ,[ "Jungle" ]= 400 ;
[ "Desert" ]= 300 ,[ "Lake" ]= 200 ;
[ "Forest" ]= 100 }
local M={ "Light Dark" ;
"Titan Temple" ;
"Cherry Blossom" , "Cosmic" ;
"Prehistoric" , "Abyss Ocean" ;
"Volcano" ;
"Snow" , "Jungle" , "Desert" , "Lake" ;
"Forest" }
local I={[ "Light Dark" ]= 420 ,[ "LightDark" ]= 420 ;
[ "Titan Temple" ]= 380 ,[ "Cherry Blossom" ]= 330 ,[ "Cosmic" ]= 280 ;
[ "Prehistoric" ]= 240 ,[ "Abyss Ocean" ]= 200 ;
[ "Volcano" ]= 180 ;
[ "Snow" ]= 160 ,[ "Jungle" ]= 140 ;
[ "Desert" ]= 130 ,[ "Lake" ]= 125 ,[ "Forest" ]= 125 }
local L= -360
local E= 525
local b= 620
local A= 130
local S=CFrame.new ( 4773.7587890625 , 70.392112731934 , -315.73501586914 )

local Z= "KenHub_FlightSpeed.txt"
local z= "KenHub_EggSelectConfig.json"
local d={[ "Light Dark" ]=Color3.fromRGB ( 168 , 85 , 247 ),[ "Titan Temple" ]=Color3.fromRGB ( 245 , 158 , 11 );
[ "Cherry Blossom" ]=Color3.fromRGB ( 236 , 72 , 153 );
[ "Cosmic" ]=Color3.fromRGB ( 6 , 182 , 212 ),[ "Prehistoric" ]=Color3.fromRGB ( 16 , 185 , 129 ),[ "Abyss Ocean" ]=Color3.fromRGB ( 59 , 130 , 246 );
[ "Volcano" ]=Color3.fromRGB ( 239 , 68 , 68 ),[ "Snow" ]=Color3.fromRGB ( 147 , 197 , 253 ),[ "Jungle" ]=Color3.fromRGB ( 34 , 197 , 94 ),[ "Desert" ]=Color3.fromRGB ( 234 , 179 , 8 ),[ "Lake" ]=Color3.fromRGB ( 20 , 184 , 166 ),[ "Forest" ]=Color3.fromRGB ( 22 , 163 , 74 )}

local X={ "Divine" , "Eternal" , "Secret" ;
"Cosmic" , "Mythic" , "Legendary" ;
"Epic" ;
"Rare" ;
"Uncommon" ;
"Common" }
local G={[ "Divine" ]=Color3.fromRGB ( 244 , 63 , 94 );
[ "Eternal" ]=Color3.fromRGB ( 217 , 70 , 239 ),[ "Secret" ]=Color3.fromRGB ( 249 , 115 , 22 ),[ "Cosmic" ]=Color3.fromRGB ( 6 , 182 , 212 ),[ "Mythic" ]=Color3.fromRGB ( 139 , 92 , 246 ),[ "Legendary" ]=Color3.fromRGB ( 251 , 191 , 36 );
[ "Epic" ]=Color3.fromRGB ( 168 , 85 , 247 );
[ "Rare" ]=Color3.fromRGB ( 59 , 130 , 246 );
[ "Uncommon" ]=Color3.fromRGB ( 34 , 197 , 94 ),[ "Common" ]=Color3.fromRGB ( 148 , 163 , 184 )}
local F={[ "Divine" ]= 6 ;
[ "Eternal" ]= 5 ;
[ "Secret" ]= 4 ,[ "Cosmic" ]= 3 ;
[ "Mythic" ]= 2 ;
[ "Legendary" ]= 1 ,[ "Epic" ]= 0.5 ,[ "Rare" ]= 0.3 ,[ "Uncommon" ]= 0.1 ;
[ "Common" ]= 0 }
local h
local function O(...)
    local e= 600 pcall(function(...)
        local r= false
        if isfile then
            r=isfile(Z)
        elseif readfile then
            local e,y=pcall(readfile,Z)r=e and(y~=nil)
        end
        if r and readfile then
            local r=readfile(Z)
            local u=tonumber(r)
            if u and(u>= 100 and u<= 1000 )then
                e=math.floor (u)
            end
        end
    end
    )
    return e
end
local function Y(e,...) pcall(function(...)
        if writefile then
            local y=math.clamp (math.floor (tonumber(e)or 600 ), 100 , 1000 )writefile(Z,tostring(y))
        end
    end
    )
end
local function T(...)
    local e=nil pcall(function(...)
        local r= false
        if isfile then
            r=isfile(z)
        elseif readfile then
            local e,y=pcall(readfile,z)r=e and(y~=nil)
        end
        if r and(readfile and a)then
            local r=readfile(z)
            if r and r~= "" then
                local u=a:JSONDecode(r)
                if type(u)== "table" then
                    e=u
                end
            end
        end
    end
    )
    local r={[ "Light Dark" ]= true ,[ "Titan Temple" ]= true ,[ "Cherry Blossom" ]= true ;
    [ "Cosmic" ]= false ;
    [ "Prehistoric" ]= false ,[ "Abyss Ocean" ]= false ;
    [ "Volcano" ]= false ,[ "Snow" ]= false ;
    [ "Jungle" ]= false ,[ "Desert" ]= false ;
    [ "Lake" ]= false ,[ "Forest" ]= false }
    local y={[ "Divine" ]= true ,[ "Eternal" ]= true ,[ "Secret" ]= true ,[ "Cosmic" ]= true ,[ "Mythic" ]= true ;
    [ "Legendary" ]= false ,[ "Epic" ]= false ,[ "Rare" ]= false ;
    [ "Uncommon" ]= false ;
    [ "Common" ]= false }
    if type(e)~= "table" then
        e={[ "selectedZones" ]=r;
        [ "selectedRarities" ]=y,[ "alwaysCollectSecretPlus" ]= true ,[ "minRarityTier" ]= 2 ;
        [ "autoTreadmill" ]= true ;
        [ "autoUpgradeTreadmill" ]= true ,[ "autoBuyTrails" ]= true ;
        [ "hideNotEnoughMoney" ]= true ;
        [ "performanceMode" ]= false ,[ "disable3D" ]= false ,[ "antiAFK" ]= true ,[ "language" ]= "EN" }
    else
        if type(e.selectedZones )~= "table" then
            e.selectedZones =r
        end
        if type(e.selectedRarities )~= "table" then
            e.selectedRarities =y
        else
            for r,w in ipairs(X)do
                if e.selectedRarities [w]==nil then
                    e.selectedRarities [w]=(y[w]== true )
                end
            end
        end
        if e.alwaysCollectSecretPlus ==nil then
            e.alwaysCollectSecretPlus = true
        end
        if e.minRarityTier ==nil then
            e.minRarityTier = 2
        end
        if e.autoTreadmill ==nil then
            e.autoTreadmill = true
        end
        if e.autoUpgradeTreadmill ==nil then
            e.autoUpgradeTreadmill = true
        end
        if e.autoBuyTrails ==nil then
            e.autoBuyTrails = true
        end
        if e.hideNotEnoughMoney ==nil then
            e.hideNotEnoughMoney = true
        end
        if e.performanceMode ==nil then
            e.performanceMode = false
        end
        if e.disable3D ==nil then
            e.disable3D = false
        end
        if e.antiAFK ==nil then
            e.antiAFK = true
        end
        if e.language and((e.language == "EN" or e.language == "TH" ))then
            currentLang=e.language
        end
    end
    return e
end
local function x(...) pcall(function(...)
        if writefile and(a and h)then
            local r={[ "selectedZones" ]=h.selectedZones or{};
            [ "selectedRarities" ]=h.selectedRarities or{};
            [ "alwaysCollectSecretPlus" ]=(h.alwaysCollectSecretPlus ~= false ),[ "minRarityTier" ]=h.minRarityTier or 2 ,[ "autoTreadmill" ]=(h.autoTreadmill == true );
            [ "autoUpgradeTreadmill" ]=(h.autoUpgradeTreadmill == true ),[ "autoBuyTrails" ]=(h.autoBuyTrails == true );
            [ "hideNotEnoughMoney" ]=(h.hideNotEnoughMoney == true );
            [ "performanceMode" ]=(h.performanceMode == true );
            [ "disable3D" ]=(h.disable3D == true );
            [ "antiAFK" ]=(h.antiAFK == true );
            [ "language" ]=currentLang or "EN" }
            local y=a:JSONEncode(r)writefile(z,y)
        end
    end
    )
end
local W=T()h={[ "godmode" ]= true ,[ "autoGlide" ]= true ,[ "autoHatch" ]= true ;
[ "autoPlaceEvery5" ]= false ;
[ "batchStealCount" ]= 0 ,[ "isBatchPlacing" ]= false ,[ "isHatching" ]= false ;
[ "autoFarmLoop" ]= false ,[ "pureTweenFarm" ]= false ;
[ "glidingToTarget" ]= false ;
[ "securingEgg" ]= false ,[ "glideSpeed" ]=O();
[ "selectedZones" ]=W.selectedZones ;
[ "selectedRarities" ]=W.selectedRarities ;
[ "alwaysCollectSecretPlus" ]=W.alwaysCollectSecretPlus ,[ "minRarityTier" ]=W.minRarityTier ,[ "autoTreadmill" ]=(W.autoTreadmill ~= false );
[ "autoUpgradeTreadmill" ]=(W.autoUpgradeTreadmill ~= false ),[ "autoBuyTrails" ]=(W.autoBuyTrails ~= false ),[ "hideNotEnoughMoney" ]= true ;
[ "performanceMode" ]=(W.performanceMode == true ),[ "disable3D" ]=(W.disable3D == true ),[ "antiAFK" ]=(W.antiAFK ~= false ),[ "onTreadmill" ]= false ,[ "lastTreadmillMount" ]= 0 ,[ "laneZ" ]= -360 ,[ "swapped" ]= false ;
[ "teleporting" ]= false ,[ "isReturning" ]= false ;
[ "delivering" ]= false ,[ "holdingEggForGuard" ]= false ,[ "currentTargetModel" ]=nil,[ "targetPosition" ]=nil;
[ "stateTime" ]=os.clock (),[ "statusText" ]= "Ready" ,[ "bestEggInfo" ]= "Scanning..." ;
[ "gui" ]=nil;
[ "alive" ]= true ,[ "plot" ]=nil;
[ "pen" ]=nil,[ "origin" ]=nil;
[ "tread" ]=nil}
local m
local e4
local r4
local y4
local u4
local w4
local j4
local k4
local a4
local o4
local V4
local H4
local t4
local s4
local p4
local B4
local J4
local K4
local c4
local v4
local i4
local R4
local g4
local Q4
local P4
local N4
local U4
local l4
local D4
local C4
local q4
local n4
local f4
local M4
local I4
local L4
local E4
local b4
local A4
local S4
local Z4
local z4
local d4
local X4={}
local G4= 0
local F4=nil
local h4
local O4= 0
local Y4= "NONE"
local T4
local x4=nil
local W4=nil pcall(function(...)
    local e=game:GetService( "Lighting" );
    (e:GetPropertyChangedSignal( "ClockTime" )):Connect(function(...) X4={}G4= 0
    end
    )
end
)pcall(function(...)
    local function e(e,...)
        if e:IsA( "RemoteEvent" )then
            local y=string.lower (e.Name )
            if string.find (y, "reset" )or string.find (y, "night" )or string.find (y, "spawn" )or string.find (y, "countdown" )then
                pcall(function(...) e.OnClientEvent :Connect(function(...) X4={}G4= 0
                    end
                    )
                end
                )
            end
        end
    end
    for y,u in ipairs(j:GetDescendants())do
        e(u)
    end
    j.DescendantAdded :Connect(e)
end
)m=function(e,...)
    if not e or not e:IsA( "Tool" )then
        return false
    end
    local r=string.lower (e.Name )
    if string.find (r, "sword" )or string.find (r, "radar" )or string.find (r, "basket" )or string.find (r, "punch" )then
        return false
    end
    if e:GetAttribute( "EggUid" )or e:GetAttribute( "UID" )or string.find (r, "egg" )or e:GetAttribute( "Category" )or e:GetAttribute( "ItemType" )== "Egg" then
        return true
    end
    return false
end
e4=function(...)
    local e=o.Character
    if e then
        for e,y in ipairs(e:GetChildren())do
            if m(y)then
                local e=y:GetAttribute( "UID" )or y:GetAttribute( "EggUid" )
                return y,e or y.Name
            end
        end
    end
    return nil,nil
end
r4=function(...)
    local e=o:FindFirstChild( "Backpack" )
    if e then
        for e,y in ipairs(e:GetChildren())do
            if m(y)then
                local e=y:GetAttribute( "UID" )or y:GetAttribute( "EggUid" )
                return y,e or y.Name
            end
        end
    end
    return nil,nil
end
y4=function(...)
    local e= 0
    local r=o:FindFirstChild( "Backpack" )
    if r then
        for r,y in ipairs(r:GetChildren())do
            if m(y)then
                e=e+ 1
            end
        end
    end
    local y=o.Character
    if y then
        for r,y in ipairs(y:GetChildren())do
            if m(y)then
                e=e+ 1
            end
        end
    end
    return e
end
u4=function(e,...)
    if not e and not((h.pureTweenFarm or h.autoFarmLoop or h.teleporting ))then
        return
    end
    local r=o.Character
    local y=r and r:FindFirstChildOfClass( "Humanoid" )
    local u=o:FindFirstChild( "Backpack" )
    if y then
        pcall(function(...) y:UnequipTools()
        end
        )
    end
    if r and u then
        for e,r in ipairs(r:GetChildren())do
            if r:IsA( "Tool" )then
                pcall(function(...) r.Parent =u
                end
                )
            end
        end
    end
end
w4=function(e,...)
    if((h.pureTweenFarm or h.autoFarmLoop ))and not h.holdingEggForGuard then
        local e=e4()
        if e then
            pcall(u4)
        end
        return false
    end
    local r,y=e4()
    if r then
        if e then
            if y==e or not y then
                return true
            end
        else
            return true
        end
    end
    local u=o.Character
    local w=u and u:FindFirstChild( "HumanoidRootPart" )
    if w and w.Position.X <=(E+ 15 )then
        return false
    end
    if s and s.ReadFieldEggs then
        local r,y=pcall(s.ReadFieldEggs )
        if r and(y and y.Records )then
            for r,y in ipairs(y.Records )do
                if((y.State == "Carried" or y.State == 2 ))and((y.CarrierUserId ==o.UserId or y.Carrier ==o.UserId ))then
                    if e then
                        if y.Uid ==e then
                            return true
                        end
                    else
                        return true
                    end
                end
            end
        end
    end
    return false
end
j4=function(e,...)
    local r,y=e4()
    if r then
        if not e or y==e or not y then
            return true
        end
    end
    local u=o:FindFirstChild( "Backpack" )
    if u then
        for r,y in ipairs(u:GetChildren())do
            if m(y)then
                local r=y:GetAttribute( "UID" )or y:GetAttribute( "EggUid" )
                if not e or r==e or y.Name ==tostring(e)then
                    return true
                end
            end
        end
    end
    if e and(s and s.ReadFieldEggs )then
        local r,y=pcall(s.ReadFieldEggs )
        if r and(y and y.Records )then
            for r,y in ipairs(y.Records )do
                if y.Uid ==e then
                    if(y.State == "Carried" or y.State == 2 )then
                        local e=y.CarrierUserId or y.Carrier
                        if e==o.UserId then
                            return true
                        end
                    end
                end
            end
        end
    end
    return false
end
local m4= false
local function ek(...)
    if m4 then
        return
    end
    local e=R or j:FindFirstChild( "RF/EggWorld/AskFieldEggSnapshot" , true )or j:FindFirstChild( "AskFieldEggSnapshot" , true )or j:FindFirstChild( "Eggs: RequestAreaEggSnapshot" , true )
    if not e or not e:IsA( "RemoteFunction" )then
        return
    end
    m4= true task.spawn (function(...)
        local r,y=pcall(function(...)
            return e:InvokeServer()
        end
        )
        if r and type(y)== "table" then
            local e={}
            local r=y.Records or y
            if type(r)== "table" then
                for r,y in pairs(r)do
                    if type(y)== "table" then
                        if not y.Uid and type(r)== "string" then
                            y.Uid =r
                        end
                        table.insert (e,y)
                    end
                end
            end
            if#e> 0 then
                F4=e G4=os.clock ()
            end
        end
        m4= false
    end
    )
end
task.spawn (function(...)
    while true do
        task.wait ( 1.5 )pcall(ek)
    end
end
)function h4(e,...)
    local y=os.clock ()
    if e or(y-G4>= 1.5 )or not F4 then
        ek()
    end
    local u=((F4 and#F4> 0 ))and F4 or nil
    local w=nil
    if s and s.ReadFieldEggs then
        local e,r=pcall(s.ReadFieldEggs )
        if e and type(r)== "table" then
            local e={}
            local y=r.Records or r
            if type(y)== "table" then
                for r,y in pairs(y)do
                    if type(y)== "table" then
                        if not y.Uid and type(r)== "string" then
                            y.Uid =r
                        end
                        table.insert (e,y)
                    end
                end
            end
            if#e> 0 then
                w=e
            end
        end
    end
    local j={}
    local k={}
    if u then
        for e,r in ipairs(u)do
            if r.Uid then
                k[r.Uid ]= true table.insert (j,r)
            end
        end
    end
    if w then
        for e,r in ipairs(w)do
            if r.Uid and not k[r.Uid ]then
                k[r.Uid ]= true table.insert (j,r)
            end
        end
    end
    local a=r:FindFirstChild( "AreaEggSlotsClient" )
    if a then
        for e,r in ipairs(a:GetChildren())do
            local y=r.Name
            if y and y~= "" then
                local e=r:GetPivot()
                local u=e.Position
                if u.X >= 530 and not string.find (tostring(y), "FirstArea" )then
                    if not k[y]then
                        k[y]= true
                        local u=r:GetAttribute( "Category" )or r:GetAttribute( "AssetCategory" )or r.Name
                        local w=r:GetAttribute( "AreaId" )or r:GetAttribute( "Area" )
                        local a=r:GetAttribute( "Rarity" )or r:GetAttribute( "RarityTier" )
                        local V=r:GetAttribute( "RarityRank" )or r:GetAttribute( "Rank" )
                        local H=r:GetAttribute( "Income" )or r:GetAttribute( "EarningRate" )
                        local t=r:GetAttribute( "Scale" )or r:GetAttribute( "AssetScale" )or 1
                        local s=r:GetAttribute( "Mutations" )or r:GetAttribute( "Mutation" )table.insert (j,{[ "Uid" ]=y,[ "AssetCategory" ]=u,[ "AreaId" ]=w;
                        [ "Rarity" ]=a,[ "Rank" ]=V,[ "Income" ]=H,[ "BoundsCFrame" ]=e;
                        [ "BottomCFrame" ]=e,[ "CFrame" ]=e;
                        [ "State" ]= "Slot" ;
                        [ "AssetScale" ]=t,[ "Mutations" ]=s,[ "PhysicalModel" ]=r})
                    else
                        for u,w in ipairs(j)do
                            if w.Uid ==y then
                                w.PhysicalModel =r
                                if not w.BoundsCFrame then
                                    w.BoundsCFrame =e
                                end
                                if not w.AreaId or w.AreaId == "" or w.AreaId == "Unknown" then
                                    w.AreaId =r:GetAttribute( "AreaId" )or r:GetAttribute( "Area" )
                                end
                                break
                            end
                        end
                    end
                end
            end
        end
    end
    return j
end
k4=function(e,...)
    if not e then
        return false , "NoUid"
    end
    local y=h4( false )
    if y and#y> 0 then
        for r,y in ipairs(y)do
            if y.Uid ==e then
                if(y.State == "Carried" or y.State == 2 )then
                    local e=y.CarrierUserId or y.Carrier
                    if e and e==o.UserId then
                        return true , "CarriedBySelf"
                    else
                        return false , "CarriedByOther"
                    end
                end
                if(y.State == "Slot" or y.State == "Dropped" or y.State == "GuardCarried" or y.State == 1 )then
                    return true , "Available"
                end
                local e=y.CarrierUserId or y.Carrier
                if e then
                    if e==o.UserId then
                        return true , "CarriedBySelf"
                    else
                        return false , "CarriedByOther"
                    end
                end
                return true , "Available"
            end
        end
    end
    local u=r:FindFirstChild( "AreaEggSlotsClient" )
    if u then
        for r,y in ipairs(u:GetChildren())do
            if y.Name ==tostring(e)or y:GetAttribute( "UID" )==e or y:GetAttribute( "Uid" )==e then
                return true , "Available"
            end
        end
    end
    return true , "Unchecked"
end
a4=function(...)
    local e,r=e4()
    if not r then
        local e,y=r4()r=y
    end
    if not r then
        return false
    end
    if s and s.ReadFieldEggs then
        local e,u=pcall(s.ReadFieldEggs )
        if e and(u and u.Records )then
            for e,u in ipairs(u.Records )do
                if u.Uid ==r then
                    local e=tostring(u.AreaId or "" )
                    if e== "Lake" or string.find (string.lower (e), "lake" )~=nil then
                        return true
                    end
                end
            end
        end
    end
    if string.find (string.lower (tostring(r)), "lake" )~=nil then
        return true
    end
    return false
end
o4=function(...)
    local e,r=e4()
    if not r then
        local e,y=r4()r=y
    end
    if not r then
        return h.glideSpeed or 350
    end
    if s and s.ReadFieldEggs then
        local e,u=pcall(s.ReadFieldEggs )
        if e and(u and u.Records )then
            for e,u in ipairs(u.Records )do
                if u.Uid ==r and u.AreaId then
                    return I[u.AreaId ]or h.glideSpeed or 350
                end
            end
        end
    end
    return h.glideSpeed or 350
end
V4=function(e,y,...) y=y or 8
    local u=Instance.new ( "Part" )u.Name = "SafetyFloorPad_AntiVoid" u.Size =Vector3.new ( 28 , 1.5 , 28 )u.Position =e-Vector3.new ( 0 , 3.2 , 0 )u.Anchored = true u.Transparency = 1 u.CanCollide = true u.Parent =r task.delay (y,function(...) pcall(function(...) u:Destroy()
        end
        )
    end
    )
    return u
end
H4=function(e,...)
    if P and e then
        pcall(function(...)
            local r=o.Character
            local y=r and r:FindFirstChild( "HumanoidRootPart" )
            local u=y and(y.CFrame *CFrame.new ( 0 , 0 , -3 ))or CFrame.new ()
            if P:IsA( "RemoteFunction" )then
                P:InvokeServer({[ "EggUid" ]=e,[ "GuardCFrame" ]=u})
            else
                P:FireServer({[ "EggUid" ]=e;
                [ "GuardCFrame" ]=u})
            end
        end
        )
    end
end
if typeof(hookmetamethod)== "function" and not _G._DesyncAntiRagdollHooked then
    _G._DesyncAntiRagdollHooked = true
    local e e=hookmetamethod(game, "__newindex" ,safeNewCClosure(function(r,y,u,...)
        if not executorCheckCaller()and typeof(r)== "Instance" then
            if r:IsA( "Motor6D" )and(y== "Enabled" and u== false )then
                return nil
            end
            if r:IsA( "Humanoid" )then
                if y== "PlatformStand" and u== true then
                    return nil
                end
                if y== "Sit" and(u== true and((h.pureTweenFarm or h.autoFarmLoop or h.isReturning or h.glidingToTarget )))then
                    return nil
                end
            end
        end
        return e(r,y,u)
    end
    ))
end
S4=function(e,...) e=e or o.Character
    if not e then
        return
    end
    local r=e:FindFirstChild( "HumanoidRootPart" )
    local y=e:FindFirstChild( "Torso" )or e:FindFirstChild( "UpperTorso" )or r
    if not y then
        return
    end
    for e,r in ipairs(e:GetDescendants())do
        if r:IsA( "BallSocketConstraint" )or r:IsA( "HingeConstraint" )or r:IsA( "NoCollisionConstraint" )then
            pcall(function(...) r:Destroy()
            end
            )
        end
    end
    for e,r in ipairs(e:GetDescendants())do
        if r:IsA( "Motor6D" )and(r.Part0 and r.Part1 )then
            r.Enabled = true
            local e= "RigidJointWeld_" ..r.Name
            local y=r.Part1 :FindFirstChild(e)
            if not y then
                local y=Instance.new ( "WeldConstraint" )y.Name =e y.Part0 =r.Part0 y.Part1 =r.Part1 y.Parent =r.Part1
            end
        end
    end
end
Z4=function(e,...)
    if h and h.onTreadmill then
        return
    end
    e=e or o.Character
    if not e then
        return
    end
    local r=e:FindFirstChildOfClass( "Humanoid" )
    if r then
        r:SetStateEnabled(Enum.HumanoidStateType.Ragdoll , false )r:SetStateEnabled(Enum.HumanoidStateType.FallingDown , false )r:SetStateEnabled(Enum.HumanoidStateType.Physics , false )r:SetStateEnabled(Enum.HumanoidStateType.PlatformStanding , false )r:SetStateEnabled(Enum.HumanoidStateType.Seated , false )
        if r.PlatformStand then
            r.PlatformStand = false
        end
        if r.Sit then
            r.Sit = false
        end
    end
    for e,r in ipairs(e:GetDescendants())do
        if r:IsA( "LocalScript" )and((string.find (string.lower (r.Name ), "ragdoll" )or string.find (string.lower (r.Name ), "fall" )))then
            r.Disabled = true
        end
    end
    S4(e)
end
z4=function(e,...)
    if not e then
        return
    end
    Z4(e)
    for e,y in ipairs(e:GetDescendants())do
        if y:IsA( "Motor6D" )then
            (y:GetPropertyChangedSignal( "Enabled" )):Connect(function(...)
                if not y.Enabled then
                    y.Enabled = true
                end
            end
            )
        end
    end
    e.DescendantAdded :Connect(function(y,...)
        if y:IsA( "BallSocketConstraint" )or y:IsA( "HingeConstraint" )or y:IsA( "NoCollisionConstraint" )then
            task.defer (function(...) pcall(function(...) y:Destroy()
                end
                )Z4(e)
            end
            )
        elseif y:IsA( "LocalScript" )and((string.find (string.lower (y.Name ), "ragdoll" )or string.find (string.lower (y.Name ), "fall" )))then
            y.Disabled = true
        end
    end
    )e.ChildAdded :Connect(function(e,...)
        if e:IsA( "Tool" )and(((h.pureTweenFarm or h.autoFarmLoop ))and not h.holdingEggForGuard )then
            task.defer (function(...) u4()
            end
            )
        end
    end
    )
end
C4=function(...)
    if h then
        h.onTreadmill = false
    end
    local e=o.Character
    local r=e and e:FindFirstChildOfClass( "Humanoid" )
    local y=e and e:FindFirstChild( "HumanoidRootPart" )
    if U then
        task.spawn (function(...) pcall(function(...) U:InvokeServer()
            end
            )
        end
        )
    end
    if r then
        pcall(function(...)
            for r,y in ipairs(r:GetPlayingAnimationTracks())do
                local u=y.Animation
                local w=u and u.AnimationId or ""
                if string.find (w, "10921259953" )or string.find (string.lower (y.Name ), "treadmill" )or string.find (string.lower (y.Name ), "run" )then
                    y:Stop( 0 )
                end
            end
            r.PlatformStand = false r.Sit = false r:SetStateEnabled(Enum.HumanoidStateType.Running , true )r:SetStateEnabled(Enum.HumanoidStateType.Jumping , true )r:ChangeState(Enum.HumanoidStateType.Running )
        end
        )
    end
    local u=o:FindFirstChild( "PlayerGui" )
    if u then
        local e=u:FindFirstChild( "SpeedGainAnimation" )
        if e then
            pcall(function(...) e:Destroy()
            end
            )
        end
    end
    if y then
        y.AssemblyLinearVelocity =Vector3.zero y.AssemblyAngularVelocity =Vector3.zero
    end
    Z4(e)
end
local rk= 0
local yk= false E4=function(...)
    local e=o:FindFirstChild( "PlayerGui" )
    if not e then
        return false
    end
    local r= false pcall(function(...)
        for e,u in ipairs(e:GetChildren())do
            if u:IsA( "ScreenGui" )and u.Enabled then
                for e,u in ipairs(u:GetDescendants())do
                    if((u:IsA( "TextButton" )or u:IsA( "ImageButton" )))and u.Visible then
                        local e=(u:IsA( "TextButton" )and u.Text )or u.Name
                        local w=string.lower (e or "" )
                        if string.find (w, "get out" )or string.find (w, "treadmill" )or string.find (w, "doff" )or string.find (w, "leave" )or string.find (w, "exit" )then
                            if typeof(firesignal)== "function" and u.Activated then
                                pcall(firesignal,u.Activated )
                            elseif typeof(firesignal)== "function" and u.MouseButton1Click then
                                pcall(firesignal,u.MouseButton1Click )
                            elseif typeof(getconnections)== "function" then
                                local e=getconnections(u.MouseButton1Click )or getconnections(u.Activated )or{}
                                for e,r in ipairs(e)do
                                    pcall(function(...) r:Fire()
                                    end
                                    )
                                    break
                                end
                            end
                            r= true
                            break
                        end
                    end
                end
                if r then
                    break
                end
            end
        end
    end
    )
    return r
end
L4=function(...)
    local e=o.Character
    local r=e and e:FindFirstChild( "HumanoidRootPart" )
    if not r then
        return false
    end
    local y=(typeof(I4)== "function" )and I4()or nil
    if y then
        local e=y.Position +Vector3.new ( 0 , 1.8 , 0 )
        local u=((r.Position -e)).Magnitude
        if u> 6 then
            if h then
                h.onTreadmill = false
            end
            return false
        end
    else
        if r.Position.X > 535 then
            if h then
                h.onTreadmill = false
            end
            return false
        end
    end
    if h and h.onTreadmill then
        return true
    end
    local u=e and e:FindFirstChildOfClass( "Humanoid" )
    if u then
        for e,r in ipairs(u:GetPlayingAnimationTracks())do
            local y=r.Animation
            local u=y and y.AnimationId or ""
            local w=string.lower (r.Name or "" )
            if string.find (u, "10921259953" )or string.find (w, "treadmill" )or string.find (w, "run" )then
                return true
            end
        end
    end
    local w=o:FindFirstChild( "PlayerGui" )
    if w and w:FindFirstChild( "SpeedGainAnimation" )then
        return true
    end
    return false
end
M4=function(...)
    if yk then
        return
    end
    if os.clock ()-rk< 0.8 then
        if h then
            h.onTreadmill = false
        end
        return
    end
    yk= true rk=os.clock ()
    if h then
        h.onTreadmill = false
    end
    E4()
    if U then
        pcall(function(...) U:InvokeServer()
        end
        )
    end
    local e=o.Character
    local r=e and e:FindFirstChildOfClass( "Humanoid" )
    local y=e and e:FindFirstChild( "HumanoidRootPart" )
    if r then
        pcall(function(...)
            for r,y in ipairs(r:GetPlayingAnimationTracks())do
                local u=y.Animation
                local w=u and u.AnimationId or ""
                local j=string.lower (y.Name or "" )
                if string.find (w, "10921259953" )or string.find (j, "treadmill" )or string.find (j, "run" )then
                    y:Stop( 0 )
                end
            end
            r.PlatformStand = false r.Sit = false r:SetStateEnabled(Enum.HumanoidStateType.Running , true )r:SetStateEnabled(Enum.HumanoidStateType.Jumping , true )r:ChangeState(Enum.HumanoidStateType.Running )
        end
        )
    end
    local u=o:FindFirstChild( "PlayerGui" )
    if u then
        local e=u:FindFirstChild( "SpeedGainAnimation" )
        if e then
            pcall(function(...) e:Destroy()
            end
            )
        end
    end
    if y then
        y.AssemblyLinearVelocity =Vector3.zero y.AssemblyAngularVelocity =Vector3.zero
    end
    Z4(e)task.wait ( 0.15 )yk= false
end
q4=M4 n4=function(...) pcall(function(...)
        local e=r:FindFirstChild( "Plots" )
        if e then
            local r=h and h.plot
            if not r and t4 then
                r=select( 1 ,t4())
            end
            for e,u in ipairs(e:GetChildren())do
                local w=(r~=nil and u==r)
                local j=u:FindFirstChild( "TreadmillBottom" )
                if j and j:IsA( "BasePart" )then
                    if w and(h and h.autoTreadmill )then
                        j.CanTouch = true j.CanCollide = true
                    else
                        j.CanTouch = false j.CanCollide = false
                    end
                end
                local k=u:FindFirstChild( "TreadmillUpgrade" )
                if k then
                    for e,r in ipairs(k:GetDescendants())do
                        if r:IsA( "BasePart" )then
                            if w and(h and h.autoTreadmill )then
                                r.CanTouch = true
                            else
                                r.CanTouch = false r.CanCollide = false
                            end
                        end
                    end
                end
            end
        end
    end
    )
end
n4()r.DescendantAdded :Connect(function(e,...) pcall(function(...)
        local r=(e.Name == "TreadmillBottom" and e:IsA( "BasePart" ))
        local y=(e.Name == "TreadmillUpgrade" and e:IsA( "Model" ))
        if r or y then
            local y=h and h.plot
            if not y and t4 then
                y=select( 1 ,t4())
            end
            local w=y and e:IsDescendantOf(y)
            if w and(h and h.autoTreadmill )then
                if r then
                    e.CanTouch = true e.CanCollide = true
                else
                    for e,r in ipairs(e:GetDescendants())do
                        if r:IsA( "BasePart" )then
                            r.CanTouch = true
                        end
                    end
                end
            else
                if r then
                    e.CanTouch = false e.CanCollide = false
                else
                    for e,r in ipairs(e:GetDescendants())do
                        if r:IsA( "BasePart" )then
                            r.CanTouch = false r.CanCollide = false
                        end
                    end
                end
            end
        end
    end
    )
end
)D4=function(...) h.onTreadmill = false h.teleporting = false h.glidingToTarget = false h.securingEgg = false h.isReturning = false h.delivering = false h.holdingEggForGuard = false h.currentTargetModel =nil h.targetPosition =nil h.stateTime =os.clock ()
    local e=o.Character
    local r=e and e:FindFirstChild( "HumanoidRootPart" )
    if r then
        pcall(function(...) r.Anchored = false r.AssemblyLinearVelocity =Vector3.zero r.AssemblyAngularVelocity =Vector3.zero
        end
        )
    end
    pcall(function(...)
        if C4 then
            C4()
        end
    end
    )pcall(function(...)
        if Z4 and e then
            Z4(e)
        end
    end
    )pcall(function(...)
        if u4 and((h.pureTweenFarm or h.autoFarmLoop ))then
            u4()
        end
    end
    )
end
d4=function(e,y,...)
    if e then
        for e,r in ipairs(e:GetDescendants())do
            if r:IsA( "ProximityPrompt" )then
                pcall(function(...) r.RequiresLineOfSight = false r.HoldDuration = 0
                    if typeof(fireproximityprompt)== "function" then
                        fireproximityprompt(r, 0 )fireproximityprompt(r)
                    end
                end
                )
            end
        end
    end
    local u=r:FindFirstChild( "AreaEggSlotsClient" )
    if u and y then
        for e,r in ipairs(u:GetChildren())do
            local u=r:FindFirstChildWhichIsA( "BasePart" )or r.PrimaryPart
            if u and((u.Position -y)).Magnitude <= 18 then
                for e,r in ipairs(r:GetDescendants())do
                    if r:IsA( "ProximityPrompt" )then
                        pcall(function(...) r.RequiresLineOfSight = false r.HoldDuration = 0
                            if typeof(fireproximityprompt)== "function" then
                                fireproximityprompt(r, 0 )fireproximityprompt(r)
                            end
                        end
                        )
                    end
                end
            end
        end
    end
end
b4=function(e,...) h.godmode =e
    local r=o.Character
    if not r then
        return
    end
    local y=r:FindFirstChildOfClass( "Humanoid" )
    if y then
        y:SetStateEnabled(Enum.HumanoidStateType.Dead ,not e)
        if e and y.Health < 100 then
            y.Health = 100
        end
    end
    for r,y in ipairs(r:GetDescendants())do
        if y:IsA( "BasePart" )then
            if e then
                y.CanTouch = false y.CanCollide = false
            end
        end
    end
    Z4(r)
end
local function enableDesyncGodmode()
    b4(true)
end
local function disableDesyncGodmode()
    b4(false)
end

A4=function(...)
    local e=o.Character
    local y=e and e:FindFirstChildOfClass( "Humanoid" )
    if not e or not y then
        return false
    end
    pcall(function(...) y.BreakJointsOnDeath = false
        local w=y:Clone()w.Parent =e y:Destroy()
        local j=w:FindFirstChildOfClass( "Animator" )
        if not j then
            j=Instance.new ( "Animator" )j.Parent =w
        end
        r.CurrentCamera.CameraSubject =w
        local k=e:FindFirstChild( "Animate" )
        if k and k:IsA( "LocalScript" )then
            k.Disabled = true task.defer (function(...) task.wait ( 0.05 )k.Disabled = false
            end
            )
        end
        w:SetStateEnabled(Enum.HumanoidStateType.Jumping , true )w:SetStateEnabled(Enum.HumanoidStateType.Freefall , true )w:SetStateEnabled(Enum.HumanoidStateType.Running , true )w:SetStateEnabled(Enum.HumanoidStateType.Climbing , true )w.JumpPower =math.max ( 50 ,w.JumpPower )w.JumpHeight =math.max ( 7.2 ,w.JumpHeight )w:ChangeState(Enum.HumanoidStateType.Running )
    end
    )h.swapped = true
    if h.godmode then
        b4( true )
    end
    z4(e)
    return true
end
t4=function(...)
    if h.plot and(h.plot.Parent and(h.pen and(h.origin and h.plotVerified )))then
        return h.plot ,h.pen ,h.origin
    end
    local e=r:FindFirstChild( "Plots" )
    if not e then
        return nil,nil,nil
    end
    local y=o.UserId
    local u=o.Name
    local w=o.DisplayName
    local j=nil
    local k= false
    if v then
        local r,w=pcall(function(...)
            return v:InvokeServer()
        end
        )
        if r and(type(w)== "table" and type(w.OwnersBySlot )== "table" )then
            for r,w in pairs(w.OwnersBySlot )do
                if w==y or tostring(w)==tostring(y)or w==u then
                    j=e:FindFirstChild(tostring(r))
                    if j then
                        k= true
                        break
                    end
                end
            end
        end
    end
    if not j and c then
        local r,u=pcall(function(...)
            return c:InvokeServer()
        end
        )
        if r and type(u)== "table" then
            for r,u in pairs(u)do
                if type(u)== "table" and((u.OwnerUserId ==y or tostring(u.OwnerUserId )==tostring(y)))then
                    local y=u.Slot or r j=e:FindFirstChild(tostring(y))or e:FindFirstChild(tostring(r))
                    if j then
                        k= true
                        break
                    end
                end
            end
        end
    end
    if not j then
        for e,r in ipairs(e:GetChildren())do
            local a=r:GetAttribute( "Owner" )or r:GetAttribute( "OwnerUserId" )or r:GetAttribute( "UserId" )or r:GetAttribute( "OwnerId" )or r:GetAttribute( "Player" )
            if a and((a==y or tostring(a)==tostring(y)or a==u or tostring(a)==u or a==w))then
                j=r k= true
                break
            end
            for e,a in ipairs({ "Owner" , "OwnerUserId" , "OwnerId" ;
                "UserId" ;
                "Player" ;
                "PlayerName" })do
                local o=r:FindFirstChild(a)
                if o and((o.Value ==y or tostring(o.Value )==tostring(y)or o.Value ==u or o.Value ==w))then
                    j=r k= true
                    break
                end
            end
            if j then
                break
            end
        end
    end
    if not j then
        for e,r in ipairs(e:GetChildren())do
            for e,y in ipairs(r:GetDescendants())do
                if y:IsA( "TextLabel" )and y.Text ~= "" then
                    local e=string.lower (y.Text )
                    if string.find (e,string.lower (u), 1 , true )or(w and string.find (e,string.lower (w), 1 , true ))then
                        j=r k= true
                        break
                    end
                end
            end
            if j then
                break
            end
        end
    end
    if not j then
        local r=o.Character
        local y=r and r:FindFirstChild( "HumanoidRootPart" )
        if y and y.Position.X <=(E+ 30 )then
            local r=nil
            local u= 999999
            for e,w in ipairs(e:GetChildren())do
                local j=w:FindFirstChild( "CenterPoint" )or w.PrimaryPart or w:FindFirstChildWhichIsA( "BasePart" )
                if j then
                    local e=((y.Position -j.Position )).Magnitude
                    if e<u then
                        u=e r=w
                    end
                end
            end
            if r and u< 160 then
                j=r
            end
        end
    end
    if not j then
        j=e:FindFirstChild( "2" )or e:FindFirstChild( "1" )or(e:GetChildren())[ 1 ]
    end
    if not j then
        return nil,nil,nil
    end
    h.plot =j h.plotVerified =k h.origin =j:FindFirstChild( "CenterPoint" )
    local a=j:FindFirstChild( "ToUpdate" )h.pen =(a and a:FindFirstChild( "PetArea" ))or j:FindFirstChild( "PetArea" )h.tread =j:FindFirstChild( "TreadmillBottom" )
    if not h.pen and a then
        for e,r in ipairs(a:GetChildren())do
            if r:IsA( "BasePart" )and string.find (string.lower (r.Name ), "pet" )then
                h.pen =r
                break
            end
        end
    end
    if not h.origin then
        h.origin =j:FindFirstChild( "CenterPoint" )or h.pen or j.PrimaryPart
    end
    if not h.pen then
        h.pen =h.origin
    end
    return h.plot ,h.pen ,h.origin
end
s4=function(...)
    local e,r,y=t4()
    if r then
        return r.Position +Vector3.new ( 0 , 3.5 , 0 )
    end
    if y then
        return y.Position +Vector3.new ( 0 , 3.5 , 0 )
    end
    return Vector3.new ( 464.7 , 71.7 , -304 )
end
p4=function(e,...)
    local r,y,u=t4()
    if not y then
        return nil
    end
    local w=y.Size
    local j=math.max ( 4 ,w.X / 2 - 5 )
    local k=math.max ( 4 ,w.Z / 2 - 5 )
    for r= 1 , 60 , 1 do
        local u=math.random (-math.floor (j),math.floor (j))
        local o=math.random (-math.floor (k),math.floor (k))
        local V=y.CFrame *CFrame.new (u,w.Y / 2 + 1 ,o)
        local H= true
        for e,r in ipairs(e)do
            if((r-V.Position )).Magnitude < 5.5 then
                H= false
                break
            end
        end
        if H then
            return V
        end
    end
    return y.CFrame *CFrame.new (math.random ( -8 , 8 ),w.Y / 2 + 1 ,math.random ( -8 , 8 ))
end
B4=function(...)
    local e,r,y=t4()
    if not y or not K then
        return 0
    end
    local u= 0
    local w={}
    if c then
        local e,r=pcall(function(...)
            return c:InvokeServer()
        end
        )
        if e and type(r)== "table" then
            local e={}
            for r,y in pairs(r)do
                if type(y)== "table" and y.OwnerUserId ==o.UserId then
                    for r,y in pairs(y.Records or{})do
                        e[r]=y
                    end
                end
            end
            for e,r in pairs(e)do
                if r.Placement and r.Placement.LocalCFrame then
                    w[#w+ 1 ]=((y.CFrame *r.Placement.LocalCFrame )).Position
                else
                    local r=p4(w)
                    if r then
                        local j=y.CFrame :ToObjectSpace(r)
                        local k,a=pcall(function(...)
                            return K:InvokeServer({[ "Uid" ]=e;
                            [ "LocalCFrame" ]=j})
                        end
                        )
                        if k and a then
                            u=u+ 1 w[#w+ 1 ]=r.Position
                        end
                    end
                end
            end
        end
    end
    local j={}
    local k=o.Character
    if k then
        for e,r in ipairs(k:GetChildren())do
            if m(r)then
                table.insert (j,r)
            end
        end
    end
    local a=o:FindFirstChild( "Backpack" )
    if a then
        for e,r in ipairs(a:GetChildren())do
            if m(r)then
                table.insert (j,r)
            end
        end
    end
    for e,r in ipairs(j)do
        if not h.alive then
            break
        end
        local j=r:GetAttribute( "UID" )or r:GetAttribute( "EggUid" )or r.Name
        local k=p4(w)
        if k then
            local e=y.CFrame :ToObjectSpace(k)
            local r,a=pcall(function(...)
                return K:InvokeServer({[ "Uid" ]=j,[ "LocalCFrame" ]=e})
            end
            )
            if r and a~= false then
                u=u+ 1 w[#w+ 1 ]=k.Position H(string.format ( "[PlaceEgg] Placed egg %s from inventory" ,tostring(j)))
            end
            task.wait ( 0.04 )
        end
    end
    return u
end
J4=function(e,...)
    if(not e and not h.autoHatch )or not g or not Q or not c then
        return 0
    end
    if h.isHatching then
        return 0
    end
    h.isHatching = true
    local y,u=pcall(function(...)
        return c:InvokeServer()
    end
    )
    if not y or type(u)~= "table" then
        return 0
    end
    local w={}
    for e,r in pairs(u)do
        if type(r)== "table" and r.OwnerUserId ==o.UserId then
            for e,r in pairs(r.Records or{})do
                w[e]=r
            end
        end
    end
    local j={}
    local k=r:GetServerTimeNow()
    for e,r in pairs(w)do
        if not h.alive then
            break
        end
        if r.Placement then
            local y=nil
            if s then
                local r=s.IsReadyToHatch or s.IsLocalEggReady
                if r then
                    local u,w=pcall(r,e)
                    if u and type(w)== "boolean" then
                        y=w
                    end
                end
            end
            if y==nil then
                local e=r.Placement.PlacedAt or r.Placement.Time or 0
                local u= 30
                if p and(p.Assets and p.Assets [r.AssetCategory ])then
                    local e=p.Assets [r.AssetCategory ]u=(e and(e.Egg and e.Egg.GrowthTime ))or 30
                end
                local w=u/math.max ( 0.01 ,r.GrowthSpeedMultiplier or 1 )y=(k-e)>=w
            end
            if y then
                table.insert (j,{[ "uid" ]=e;
                [ "category" ]=r.AssetCategory or "Egg" })
            end
        end
    end
    if#j== 0 then
        h.isHatching = false
        return 0
    end
    H(string.format ( "[AutoHatch] Found %d eggs ready to hatch! Starting hatch sequence..." ,#j))h.statusText =string.format ( "[Hatch] Hatching %d ready eggs..." ,#j)
    local a= 0
    for e,r in ipairs(j)do
        task.spawn (function(...)
            local e,y=pcall(function(...)
                if g:IsA( "RemoteFunction" )then
                    return g:InvokeServer(r.uid )
                else
                    g:FireServer(r.uid )
                    return true
                end
            end
            )
            if e and y~= false then
                task.wait ( 0.9 )
                local e,y=pcall(function(...)
                    if Q:IsA( "RemoteFunction" )then
                        return Q:InvokeServer(r.uid )
                    else
                        Q:FireServer(r.uid )
                        return true
                    end
                end
                )
                if e and y~= false then
                    a=a+ 1 h.hatched =((h.hatched or 0 ))+ 1 H(string.format ( "[+] [AutoHatch] Hatched %s (UID: %s) -> Total Hatched: %d" ,r.category ,tostring(r.uid ),h.hatched ))
                end
            end
        end
        )task.wait ( 0.04 )
    end
    task.wait ( 0.95 )h.isHatching = false H(string.format ( "[AutoHatch] Finished! Hatched %d eggs." ,a))
    return a
end
i4=function(...)
    local e={}
    local y=r:FindFirstChild( "__DEBRIS" )
    if y then
        for r,y in ipairs(y:GetChildren())do
            local u=y:FindFirstChild( "Hitbox" )
            if u and u:IsA( "BasePart" )then
                table.insert (e,u)
            elseif y:IsA( "BasePart" )and string.find (y.Name :lower(), "hitbox" )then
                table.insert (e,y)
            end
        end
    end
    local u=r:FindFirstChild( "BossArenaTeleport" )
    if u then
        local r=u:FindFirstChild( "Hitbox" )or u:FindFirstChildWhichIsA( "BasePart" )or(u:IsA( "BasePart" )and u)
        if r and r:IsA( "BasePart" )then
            table.insert (e,r)
        end
    end
    return e
end
g4=function(e,r,u,...)
    local w=o.Character
    local j=w and w:FindFirstChild( "HumanoidRootPart" )
    local k=w and w:FindFirstChildOfClass( "Humanoid" )
    if not j then
        return false
    end
    if k then
        k.AutoRotate = false
    end
    local a=s4()e=math.max ( 100 ,e or h.glideSpeed or 600 )
    local V=h.laneZ or L h.isReturning = true h.stateTime =os.clock ()V4(a, 20 )j.AssemblyLinearVelocity =Vector3.zero j.AssemblyAngularVelocity =Vector3.zero
    local H=o4()
    local t=math.max (e,H)
    local s=os.clock ()+ 25
    while h.alive and(h.isReturning and os.clock ()<s)do
        if r and O4~=r then
            if k then
                k.AutoRotate = true
            end
            h.isReturning = false
            return false
        end
        if not u and(not h.pureTweenFarm and not h.autoFarmLoop )then
            if k then
                k.AutoRotate = true
            end
            h.isReturning = false
            return false
        end
        local e=j.Position
        local w=((a-e)).Magnitude
        if(e.X <=(a.X + 3 )and math.abs (e.Z -a.Z )<= 8 )or w<= 6 then
            break
        end
        local o=y.Heartbeat :Wait()e=j.Position
        local H=t
        if e.X <=b and e.X >E then
            local r=math.clamp (((e.X -E))/((b-E)), 0 , 1 )H=A+(((t-A))*r)
        elseif e.X <=E then
            H=A
        end
        local s=a.Z
        if e.X > 540 then
            s=V
        end
        local B=math.sign (a.X -e.X )
        local J=B*math.min (math.abs (a.X -e.X ),H*o)
        local K=e.X +J
        local c=math.sign (a.Y -e.Y )
        local v=c*math.min (math.abs (a.Y -e.Y ),(H*o)* 0.5 )
        local i=e.Y +v
        local R=s-e.Z
        local g=math.sign (R)*math.min (math.abs (R),H*o)
        local Q=e.Z +g
        local P=i4()
        local N= false
        if e.X >E then
            for e,r in ipairs(P)do
                local y=r.Position
                local u=((Vector3.new (K,i,Q)-y)).Magnitude
                local w=math.abs (K-y.X )
                local j=math.abs (Q-y.Z )
                if u< 22 or(w< 18 and j< 14 )then
                    N= true
                    local e=y.Y + 16
                    if i<e then
                        i=math.min (i+((H*o)* 1.5 ),e)
                    end
                    break
                end
            end
        end
        local U=Vector3.new (K,i,Q)
        local l=((U-e)).Magnitude > 0.05 and((U-e)).Unit or j.CFrame.LookVector j.CFrame =CFrame.lookAt (U,U+l)j.AssemblyLinearVelocity =Vector3.zero j.AssemblyAngularVelocity =Vector3.zero
        if N then
            h.statusText =string.format ( "Tweening Home (Z: %.0f) [DODGING TRAP!]" ,Q)
        else
            h.statusText =string.format ( "Tweening Home (%.0f studs | Z: %.0f | Spd: %.0f)" ,w,Q,H)
        end
    end
    j.CFrame =CFrame.new (a)j.AssemblyLinearVelocity =Vector3.zero j.AssemblyAngularVelocity =Vector3.zero
    if k then
        k.AutoRotate = true
    end
    u4()h.isReturning = false h.delivering = false h.statusText = "Arrived at Base PetArea!"
    return true
end
v4=function(e,r,y,...)
    local u=o.Character
    local w=u and u:FindFirstChild( "HumanoidRootPart" )
    local j=u and u:FindFirstChildOfClass( "Humanoid" )
    if not w or not j then
        return
    end
    local k=s4()
    local a=((w.Position -k)).Magnitude
    if a> 8 then
        h.statusText = "[Place] Tweening back to base plot..." g4(e or h.glideSpeed or 600 ,r, true )
    end
    V4(k, 15 )w.CFrame =CFrame.new (k)w.AssemblyLinearVelocity =Vector3.zero h.statusText = "[Place] Placing All Eggs to Stand..."
    local V=os.clock ()+ 3
    while y4()> 0 and(os.clock ()<V and h.alive )do
        B4()task.wait ( 0.06 )
    end
    h.statusText = "[Place] Hatching ready eggs..." J4( true )u4()h.isReturning = false h.delivering = false h.currentTargetModel =nil h.targetPosition =nil
    local H=y4()h.statusText =string.format ( "Placed & Hatched (Left: %d)! Hands Free." ,H)
end
local uk= 5 K4=function(e,...)
    if h.isBatchPlacing then
        return
    end
    h.isBatchPlacing = true H(string.format ( "[AutoPlace] %d steals done! Batch placing (%s mode)..." ,uk,tostring(e)))
    local r=O4 h.pureTweenFarm =(e== "TWEEN" )h.autoFarmLoop =(e== "WARP" )
    local y=o.Character
    local u=y and y:FindFirstChild( "HumanoidRootPart" )
    local w=y and y:FindFirstChildOfClass( "Humanoid" )
    local j=s4()
    local k=u and((u.Position -j)).Magnitude or 999
    if k> 8 then
        h.statusText = "[AutoPlace] Tweening home to base plot..." g4(h.glideSpeed or 600 ,r, true )
    end
    if u then
        V4(j, 20 )u.CFrame =CFrame.new (j)u.AssemblyLinearVelocity =Vector3.zero u.AssemblyAngularVelocity =Vector3.zero
        if w then
            w.AutoRotate = true
        end
    end
    task.spawn (function(...) pcall(B4)pcall(J4, true )
    end
    )u4()h.isReturning = false h.delivering = false h.glidingToTarget = false h.securingEgg = false h.teleporting = false h.currentTargetModel =nil h.targetPosition =nil
    for e= 5 , 1 , -1 do
        if not h.alive then
            break
        end
        h.statusText =string.format ( "[AutoPlace] At Base: Resuming in %ds..." ,e)task.wait ( 1 )
    end
    h.isBatchPlacing = false
    if h.alive and O4==r then
        H(string.format ( "[AutoPlace] Done! Continuing %s farm." ,e))h.statusText =string.format ( "[AutoPlace] Resuming %s farm..." ,e)
        if e== "TWEEN" then
            h.pureTweenFarm = true h.autoFarmLoop = false
        elseif e== "WARP" then
            h.autoFarmLoop = true h.pureTweenFarm = false
        end
        Y4=e
    end
end
c4=function(e,...)
    if not h.autoPlaceEvery5 then
        return false
    end
    h.batchStealCount =((h.batchStealCount or 0 ))+ 1 H(string.format ( "[AutoPlace] Steal trip %d / %d completed successfully." ,h.batchStealCount ,uk))
    if h.batchStealCount >=uk then
        h.batchStealCount = 0 task.spawn (function(...) K4(e)
        end
        )
        return true
    end
    return false
end
local function wk(e,r,u,w,...)
    local j=o.Character
    local k=j and j:FindFirstChild( "HumanoidRootPart" )
    local a=j and j:FindFirstChildOfClass( "Humanoid" )
    if not k then
        return false
    end
    if a then
        a.AutoRotate = false
    end
    r=math.max ( 60 ,r or h.glideSpeed or 350 )
    local V=e.Position V4(V, 14 )pcall(function(...) o:RequestStreamAroundAsync(V)
    end
    )k.AssemblyLinearVelocity =Vector3.zero k.AssemblyAngularVelocity =Vector3.zero
    local H=h.laneZ or L h.glidingToTarget = true h.stateTime =os.clock ()
    local t= 0
    local s=os.clock ()+ 15
    while h.alive and(h.glidingToTarget and os.clock ()<s)do
        if w and O4~=w then
            if a then
                a.AutoRotate = true
            end
            h.glidingToTarget = false
            return false
        end
        if not h.pureTweenFarm and(not h.autoFarmLoop and not h.teleporting )then
            if a then
                a.AutoRotate = true
            end
            h.glidingToTarget = false
            return false
        end
        local e=k.Position
        local j=((V-e)).Magnitude
        local o=((Vector2.new (e.X ,e.Z )-Vector2.new (V.X ,V.Z ))).Magnitude
        local s=math.abs (e.Y -V.Y )
        if j<= 6 or(o<= 3.5 and s<= 6 )then
            break
        end
        local B=y.Heartbeat :Wait()e=k.Position j=((V-e)).Magnitude o=((Vector2.new (e.X ,e.Z )-Vector2.new (V.X ,V.Z ))).Magnitude
        local J=math.abs (e.X -V.X )
        if u and(os.clock ()-t> 0.5 )then
            t=os.clock ()
            local e,r=k4(u)
            if not e and r== "CarriedByOther" then
                if a then
                    a.AutoRotate = true
                end
                h.glidingToTarget = false
                return false
            end
        end
        local K=V.Z
        if J> 40 then
            K=H
        end
        local c=math.sign (V.X -e.X )
        local v=c*math.min (math.abs (V.X -e.X ),r*B)
        local i=e.X +v
        local R=(o<= 25 )and 1.2 or 0.5
        local g=math.sign (V.Y -e.Y )
        local Q=g*math.min (math.abs (V.Y -e.Y ),(r*B)*R)
        local P=e.Y +Q
        local N=K-e.Z
        local U=math.sign (N)*math.min (math.abs (N),r*B)
        local l=e.Z +U
        local D= false
        if o> 25 then
            local e=i4()
            for e,y in ipairs(e)do
                local u=y.Position
                local w=((Vector3.new (i,P,l)-u)).Magnitude
                local j=math.abs (i-u.X )
                local k=math.abs (l-u.Z )
                if w< 22 or(j< 18 and k< 14 )then
                    D= true
                    local e=u.Y + 16
                    if P<e then
                        P=math.min (P+((r*B)* 1.5 ),e)
                    end
                    break
                end
            end
        end
        local C=Vector3.new (i,P,l)
        local q=((C-e)).Magnitude > 0.05 and((C-e)).Unit or k.CFrame.LookVector k.CFrame =CFrame.lookAt (C,C+q)k.AssemblyLinearVelocity =Vector3.zero k.AssemblyAngularVelocity =Vector3.zero
        if D then
            h.statusText =string.format ( "Gliding Out (Z: %.0f) [DODGING TRAP!]" ,l)
        else
            h.statusText =string.format ( "Gliding -> Egg (%.0f studs | H: %.0f)" ,j,o)
        end
    end
    k.CFrame =e*CFrame.new ( 0 , 0.4 , 0 )k.AssemblyLinearVelocity =Vector3.zero k.AssemblyAngularVelocity =Vector3.zero
    if a then
        a.AutoRotate = true
    end
    h.glidingToTarget = false
    return true
end
R4=function(e,r,y,u,...)
    local w=o.Character
    local j=w and w:FindFirstChild( "HumanoidRootPart" )
    if j then
        local w=j.Position.X
        local a=e.Position.X
        if w<= 535 and a> 510 then
            local e=CFrame.new ( 500 , 70 , -364 )
            local a=((j.Position -e.Position )).Magnitude
            if a> 5 then
                h.statusText = "[AutoSteal] Exiting Base -> Waypoint (500, 70, -364)..." H(string.format ( "[AutoSteal] Leaving base (X=%.1f): Gliding to waypoint (500, 70, -364) first (dist=%.1f studs)..." ,w,a))
                local j=wk(e,r,y,u)
                if not j then
                    return false
                end
                task.wait ( 0.04 )
            end
        end
    end
    return wk(e,r,y,u)
end
Q4=function(e,r,...)
    local u=o.Character
    local w=u and u:FindFirstChild( "HumanoidRootPart" )
    local j=u and u:FindFirstChildOfClass( "Humanoid" )
    if not w then
        return false
    end
    if j then
        j.AutoRotate = false
    end
    local k=h.laneZ or L
    local a=Vector3.new (E- 10 , 70 ,k)e=math.max ( 100 ,e or h.glideSpeed or 350 )h.isReturning = true h.stateTime =os.clock ()V4(Vector3.new (E, 70 ,k), 20 )pcall(u4)w.AssemblyLinearVelocity =Vector3.zero w.AssemblyAngularVelocity =Vector3.zero
    local V=o4()
    local H=math.max (e,V)
    local s=os.clock ()+ 15
    while h.alive and(h.isReturning and os.clock ()<s)do
        if r and O4~=r then
            t( "[Return] Aborted by session switch!" )
            if j then
                j.AutoRotate = true
            end
            h.isReturning = false
            return false
        end
        if not h.pureTweenFarm and not h.autoFarmLoop then
            t( "[Return] Aborted (all farms disabled)" )
            if j then
                j.AutoRotate = true
            end
            h.isReturning = false
            return false
        end
        local e=w.Position
        local o=((a-e)).Magnitude
        if e.X <=(E+ 10 )or o<= 6 then
            u4()
            break
        end
        if u then
            for e,r in ipairs(u:GetChildren())do
                if r:IsA( "Tool" )then
                    pcall(u4)
                    break
                end
            end
        end
        local V=y.Heartbeat :Wait()e=w.Position
        local s=H
        if e.X <=b and e.X >E then
            local r=math.clamp (((e.X -E))/((b-E)), 0 , 1 )s=A+(((H-A))*r)
        elseif e.X <=E then
            s=A
        end
        local B=math.sign (a.X -e.X )
        local J=B*math.min (math.abs (a.X -e.X ),s*V)
        local K=e.X +J
        local c=math.sign (a.Y -e.Y )
        local v=c*math.min (math.abs (a.Y -e.Y ),(s*V)* 0.5 )
        local i=e.Y +v
        local R=k-e.Z
        local g=math.sign (R)*math.min (math.abs (R),s*V)
        local Q=e.Z +g
        local P=i4()
        local N= false
        for e,r in ipairs(P)do
            local y=r.Position
            local u=((Vector3.new (K,i,Q)-y)).Magnitude
            local w=math.abs (K-y.X )
            local j=math.abs (Q-y.Z )
            if u< 22 or(w< 18 and j< 14 )then
                N= true
                local e=y.Y + 16
                if i<e then
                    i=math.min (i+((s*V)* 1.5 ),e)
                end
                break
            end
        end
        local U=Vector3.new (K,i,Q)
        local l=((U-e)).Magnitude > 0.05 and((U-e)).Unit or w.CFrame.LookVector w.CFrame =CFrame.lookAt (U,U+l)w.AssemblyLinearVelocity =Vector3.zero w.AssemblyAngularVelocity =Vector3.zero
        if N then
            h.statusText =string.format ( "Tweening Safe Line (Z: %.0f) [DODGING!]" ,Q)
        else
            h.statusText =string.format ( "Tweening to Safe Line (%.0f studs | X: %.0f)" ,o,e.X )
        end
    end
    w.CFrame =CFrame.new (E,math.max ( 68 ,w.Position.Y ),k)w.AssemblyLinearVelocity =Vector3.zero w.AssemblyAngularVelocity =Vector3.zero
    if j then
        j.AutoRotate = true
    end
    u4()h.isReturning = false h.delivering = false
    if h then
        h.onTreadmill = false
    end
    h.statusText = "Arrived at Safe Line (X=525)! Hands Free."
    return true
end
local function jk(e,...)
    if not e then
        return nil
    end
    local r=e:FindFirstChild( "TreadmillBottom" )
    if r and r:IsA( "BasePart" )then
        return r
    end
    r=e:FindFirstChild( "TreadmillBottom" , true )
    if r and r:IsA( "BasePart" )then
        return r
    end
    local y=e:FindFirstChild( "TreadmillUpgrade" , true )
    if y then
        for e,r in ipairs({ "TreadmillBottom" , "Belt" , "RunArea" ;
            "Run" ;
            "Platform" ;
            "Pad" , "Floor" ;
            "Base" })do
            local w=y:FindFirstChild(r, true )
            if w and w:IsA( "BasePart" )then
                return w
            end
        end
        local e=nil
        local r= 999999
        for y,w in ipairs(y:GetDescendants())do
            if w:IsA( "BasePart" )and(w.Size.X >= 1.2 and w.Size.Z >= 1.2 )then
                if w.Position.Y <r then
                    r=w.Position.Y e=w
                end
            end
        end
        if e then
            return e
        end
        if y.PrimaryPart then
            return y.PrimaryPart
        end
        local w=y:FindFirstChildWhichIsA( "BasePart" , true )
        if w then
            return w
        end
    end
    for e,r in ipairs(e:GetDescendants())do
        if r:IsA( "BasePart" )and string.find (string.lower (r.Name ), "treadmill" )then
            return r
        end
    end
    return nil
end
I4=function(...)
    local e=t4()
    if h.tread and h.tread.Parent then
        return h.tread
    end
    local y=nil
    if e then
        y=jk(e)
    end
    if not y then
        local w=r:FindFirstChild( "Plots" )
        if w then
            local r=string.lower (o.Name )
            local j=o.DisplayName and string.lower (o.DisplayName )
            for e,w in ipairs(w:GetChildren())do
                local k=jk(w)
                if k then
                    local e= false
                    for y,w in ipairs(w:GetDescendants())do
                        if w:IsA( "TextLabel" )and w.Text ~= "" then
                            local y=string.lower (w.Text )
                            if string.find (y,r, 1 , true )or(j and string.find (y,j, 1 , true ))then
                                e= true
                                break
                            end
                        end
                    end
                    if e then
                        h.plot =w h.plotVerified = true y=k
                        break
                    end
                end
            end
            if not y and e then
                y=jk(e)
            end
        end
    end
    h.tread =y
    return y
end
f4=function(e,...)
    local r=o.Character
    local u=r and r:FindFirstChild( "HumanoidRootPart" )
    local w=r and r:FindFirstChildOfClass( "Humanoid" )
    if not u or not w then
        return false
    end
    if w.PlatformStand then
        w.PlatformStand = false
    end
    if w.Sit then
        w.Sit = false
    end
    w:ChangeState(Enum.HumanoidStateType.Running )
    local j=t4()
    local k=I4()
    if not k then
        t( "[AutoTreadmill] Treadmill part not found! Retrying next loop..." )
        return false
    end
    pcall(function(...)
        for r,y in ipairs(r:GetChildren())do
            if y:IsA( "BasePart" )and y.Name ~= "HumanoidRootPart" then
                y.CanCollide = false
            end
        end
    end
    )pcall(function(...) k.CanTouch = true k.CanCollide = true
        local e=j and j:FindFirstChild( "TreadmillUpgrade" , true )
        if e then
            for e,y in ipairs(e:GetDescendants())do
                if y:IsA( "BasePart" )then
                    y.CanTouch = true y.CanCollide = true
                end
            end
        end
        if k.Parent and k.Parent :IsA( "Model" )then
            for e,y in ipairs(k.Parent :GetDescendants())do
                if y:IsA( "BasePart" )then
                    y.CanTouch = true y.CanCollide = true
                end
            end
        end
    end
    )
    local a=k.Position +Vector3.new ( 0 , 1.8 , 0 )
    if u.Position.X > 535 then
        h.statusText = "[AutoTreadmill] Returning along highway to base..." Q4(h.glideSpeed ,e)
        if e and O4~=e then
            return false
        end
        if u.Position.X > 535 then
            if u.Position.X <= 560 then
                u.CFrame =CFrame.new (E, 70 ,h.laneZ or L)
            else
                return false
            end
        end
    end
    if e and O4~=e then
        return false
    end
    local V=((Vector2.new (u.Position.X ,u.Position.Z )-Vector2.new (a.X ,a.Z ))).Magnitude
    if V> 4 then
        h.statusText = "[AutoTreadmill] Elevated flyover to base plot..."
        local r=math.max ( 250 ,h.glideSpeed or 400 )
        local j=os.clock ()
        while h.alive and(((Vector2.new (u.Position.X ,u.Position.Z )-Vector2.new (a.X ,a.Z ))).Magnitude > 4 and(os.clock ()-j< 4 ))do
            if e and O4~=e then
                return false
            end
            local j=y.Heartbeat :Wait()
            local k=u.Position
            local o=Vector3.new (a.X , 70 ,a.Z )
            local V=(o-k)
            local H=V.Unit *math.min (V.Magnitude ,r*j)
            local t=k+H u.CFrame =CFrame.lookAt (t,t+((V.Magnitude > 0.05 and V.Unit or u.CFrame.LookVector )))u.AssemblyLinearVelocity =Vector3.zero u.AssemblyAngularVelocity =Vector3.zero
            if w then
                if w.PlatformStand then
                    w.PlatformStand = false
                end
                if w.Sit then
                    w.Sit = false
                end
                w:ChangeState(Enum.HumanoidStateType.Running )
            end
        end
    end
    if e and O4~=e then
        return false
    end
    local H=os.clock ()
    while h.alive and(math.abs (u.Position.Y -a.Y )> 2 and(os.clock ()-H< 1.5 ))do
        if e and O4~=e then
            return false
        end
        local r=y.Heartbeat :Wait()
        local w=u.Position
        local j=a
        local k=(j-w)
        local o=k.Unit *math.min (k.Magnitude , 150 *r)
        local V=w+o u.CFrame =CFrame.new (V)u.AssemblyLinearVelocity =Vector3.zero u.AssemblyAngularVelocity =Vector3.zero
    end
    u.CFrame =CFrame.new (a)u.AssemblyLinearVelocity =Vector3.zero u.AssemblyAngularVelocity =Vector3.zero
    local s=((u.Position -a)).Magnitude
    if s<= 6 then
        pcall(function(...)
            if typeof(firetouchinterest)== "function" then
                firetouchinterest(u,k, 0 )task.wait ( 0.02 )firetouchinterest(u,k, 1 )
            end
        end
        )pcall(function(...)
            for r,y in ipairs(k:GetDescendants())do
                if y:IsA( "ProximityPrompt" )and y.Enabled then
                    if typeof(fireproximityprompt)== "function" then
                        fireproximityprompt(y)
                    end
                end
            end
            if k.Parent then
                for r,y in ipairs(k.Parent :GetDescendants())do
                    if y:IsA( "ProximityPrompt" )and y.Enabled then
                        if typeof(fireproximityprompt)== "function" then
                            fireproximityprompt(y)
                        end
                    end
                end
            end
        end
        )
        if l then
            pcall(function(...) l:InvokeServer()
            end
            )
        end
        h.onTreadmill = true h.lastTreadmillMount =os.clock ()h.statusText = "[AutoTreadmill] Running on treadmill (Waiting for eggs...)"
        return true
    else
        h.onTreadmill = false t(string.format ( "[AutoTreadmill] Not yet at treadmill pad (dist=%.1f studs). Will retry!" ,s))
        return false
    end
end
local function kk(...)
    if not h or not h.hideNotEnoughMoney then
        return
    end
    local e=o:FindFirstChild( "PlayerGui" )
    if not e then
        return
    end
    pcall(function(...)
        for e,y in ipairs(e:GetDescendants())do
            if y:IsA( "TextLabel" )and y.Visible then
                local e=(tostring(y.Text or "" )):lower()
                if e:find( "not enough money" )or e:find( "not enough cash" )or(e:find( "not enough" )and((e:find( "money" )or e:find( "cash" )or e:find( "coin" )or e:find( "fund" ))))then
                    y.Visible = false y.TextTransparency = 1 y.TextStrokeTransparency = 1
                    local e=y.Parent
                    if e and(((e:IsA( "Frame" )or e:IsA( "CanvasGroup" )))and#e:GetChildren()<= 3 )then
                        e.Visible = false
                    end
                end
            end
        end
    end
    )
end
local function ak(...)
    local e=o:FindFirstChild( "PlayerGui" )
    if not e then
        return
    end
    local function r(e,...)
        if e:IsA( "TextLabel" )then
            local function y(...)
                if not h or not h.hideNotEnoughMoney then
                    return
                end
                local y=(tostring(e.Text or "" )):lower()
                if y:find( "not enough money" )or y:find( "not enough cash" )or(y:find( "not enough" )and((y:find( "money" )or y:find( "cash" )or y:find( "coin" )or y:find( "fund" ))))then
                    e.Visible = false e.TextTransparency = 1 e.TextStrokeTransparency = 1
                    local r=e.Parent
                    if r and(((r:IsA( "Frame" )or r:IsA( "CanvasGroup" )))and#r:GetChildren()<= 3 )then
                        r.Visible = false
                    end
                end
            end
            y();
            (e:GetPropertyChangedSignal( "Text" )):Connect(y);
            (e:GetPropertyChangedSignal( "Visible" )):Connect(function(...)
                if e.Visible then
                    y()
                end
            end
            )
        end
    end
    pcall(function(...)
        for e,y in ipairs(e:GetDescendants())do
            task.spawn (r,y)
        end
        e.DescendantAdded :Connect(r)
    end
    )task.spawn (function(...)
        while h and h.alive do
            if h.hideNotEnoughMoney then
                kk()
            end
            task.wait ( 0.25 )
        end
    end
    )
end
task.spawn (ak)
local function ok(e,...)
    if not e then
        return 0
    end
    local r=(((tostring(e)):gsub( "[$,]" , "" )):gsub( "%s+" , "" )):lower()
    local y=r:match( "[%d%.]+" )
    if not y then
        return 0
    end
    local u=tonumber(y)
    if not u then
        return 0
    end
    if r:find( "sp" )then
        return u* 999999999999999983222784
    elseif r:find( "sx" )then
        return u* 1000000000000000000000
    elseif r:find( "qi" )then
        return u* 1000000000000000000
    elseif r:find( "qa" )or r:find( "q" )then
        return u* 1000000000000000
    elseif r:find( "t" )then
        return u* 1000000000000
    elseif r:find( "b" )then
        return u* 1000000000
    elseif r:find( "m" )then
        return u* 1000000
    elseif r:find( "k" )then
        return u* 1000
    end
    return u
end
local function Vk(...)
    local e=o:FindFirstChild( "leaderstats" )
    if e then
        for r,u in ipairs({ "Money" , "Cash" , "Coins" ;
            "Currency" })do
            local w=e:FindFirstChild(u)
            if w then
                local e=tonumber(w.Value )or ok(w.Value )
                if e and e> 0 then
                    return e
                end
            end
        end
    end
    local r=o:FindFirstChild( "PlayerGui" )
    if r then
        local e=r:FindFirstChild( "HUD" )or r:FindFirstChild( "GameHUD" )or r:FindFirstChild( "MainHUD" )or r:FindFirstChild( "Main" )
        if e then
            for e,r in ipairs(e:GetDescendants())do
                if r:IsA( "TextLabel" )and r.Visible then
                    local e=r.Name :lower()
                    if e== "money" or e== "cash" or e== "coins" or e== "currency" or e== "value" then
                        local e=ok(r.Text )
                        if e and e> 0 then
                            return e
                        end
                    end
                end
            end
        end
    end
    return 0
end
local function Hk(...)
    local e=h.plot or(t4 and t4())
    if not e then
        return nil
    end
    local r=e:FindFirstChild( "TreadmillUpgrade" , true )
    if not r then
        return nil
    end
    local y=nil
    for e,r in ipairs(r:GetDescendants())do
        if r:IsA( "TextLabel" )or r:IsA( "TextButton" )then
            local e=tostring(r.Text or "" )
            local w=e:match( "%$([%d%.,]+%s*[kKmMbBtTqQ]?[aA]?)" )
            if w then
                local e=ok(w)
                if e and e> 0 then
                    if not y or e>y then
                        y=e
                    end
                end
            end
        end
    end
    return y
end
local tk= 0
local sk= 10
local function pk(...)
    if not h.autoUpgradeTreadmill then
        return
    end
    if os.clock ()-tk<sk then
        return
    end
    local e=h.plot or(t4 and t4())
    if not e then
        return
    end
    local r=e:FindFirstChild( "TreadmillUpgrade" , true )
    if not r then
        return
    end
    local y=Vk()
    local u=Hk()
    if u and(u> 0 and y<u)then
        return
    end
    tk=os.clock ()
    if D then
        pcall(function(...) D:InvokeServer()
        end
        )
    end
    local w=o.Character
    local j=w and w:FindFirstChild( "HumanoidRootPart" )pcall(function(...)
        for r,y in ipairs(r:GetDescendants())do
            if y:IsA( "ProximityPrompt" )and y.Enabled then
                if typeof(fireproximityprompt)== "function" then
                    fireproximityprompt(y, 0 )fireproximityprompt(y)
                end
            end
            if y:IsA( "GuiButton" )and y.Visible then
                local r=(y:IsA( "TextButton" )and y.Text )or y.Name
                local u=string.lower (r)
                if not string.find (u, "robux" )and(not string.find (u, "r%$" )and((string.find (u, "%$" )or string.find (u, "upgrade" )or string.find (u, "cash" )or(y.BackgroundColor3 and y.BackgroundColor3.G >y.BackgroundColor3.R ))))then
                    if typeof(firesignal)== "function" and y.Activated then
                        firesignal(y.Activated )
                    elseif typeof(firesignal)== "function" and y.MouseButton1Click then
                        firesignal(y.MouseButton1Click )
                    end
                end
            end
            if y:IsA( "BasePart" )and(y.Name :find( "Pad" )and j)then
                if((j.Position -y.Position )).Magnitude < 10 then
                    if typeof(firetouchinterest)== "function" then
                        firetouchinterest(j,y, 0 )task.wait ( 0.02 )firetouchinterest(j,y, 1 )
                    end
                end
            end
        end
    end
    )
end
local Bk={{[ "id" ]= "GreyTrail" ,[ "base" ]= "Grey" ,[ "name" ]= "Grey Trail" ;
[ "price" ]= 100 ;
[ "mult" ]= 1.5 },{[ "id" ]= "GreenTrail" ;
[ "base" ]= "Green" ,[ "name" ]= "Green Trail" ;
[ "price" ]= 5000 ;
[ "mult" ]= 2 },{[ "id" ]= "BlueTrail" ,[ "base" ]= "Blue" ;
[ "name" ]= "Blue Trail" ;
[ "price" ]= 75000 ;
[ "mult" ]= 2.5 };
{[ "id" ]= "PurpleTrail" ,[ "base" ]= "Purple" ;
[ "name" ]= "Purple Trail" ;
[ "price" ]= 1500000 ;
[ "mult" ]= 3 },{[ "id" ]= "GoldenTrail" ,[ "base" ]= "Golden" ;
[ "name" ]= "Golden Trail" ;
[ "price" ]= 1500000 ;
[ "mult" ]= 3.5 };
{[ "id" ]= "RedTrail" ;
[ "base" ]= "Red" ,[ "name" ]= "Red Trail" ;
[ "price" ]= 750000000 ,[ "mult" ]= 4 },{[ "id" ]= "GalaxyTrail" ,[ "base" ]= "Galaxy" ,[ "name" ]= "Galaxy Trail" ;
[ "price" ]= 20000000000 ,[ "mult" ]= 5 },{[ "id" ]= "SecretTrail" ;
[ "base" ]= "Secret" ;
[ "name" ]= "Secret Trail" ,[ "price" ]= 500000000000 ,[ "mult" ]= 6 };
{[ "id" ]= "EternalTrail" ;
[ "base" ]= "Eternal" ,[ "name" ]= "Eternal Trail" ,[ "price" ]= 12500000000000 ;
[ "mult" ]= 10 };
{[ "id" ]= "DivineTrail" ,[ "base" ]= "Divine" ;
[ "name" ]= "Divine Trail" ,[ "price" ]= 300000000000000 ;
[ "mult" ]= 14 };
{[ "id" ]= "MoonbloomTrail" ,[ "base" ]= "Moonbloom" ;
[ "name" ]= "Moonbloom Trail" ,[ "price" ]= 5000000000000000 ,[ "mult" ]= 20 }}
local function Jk(...)
    return Bk
end
local function Kk(...)
    local e={}
    local r=o:FindFirstChild( "PlayerGui" )
    local y=r and((r:FindFirstChild( "TrailShop" )or r:FindFirstChild( "TrailShop" , true )))
    local u=y and y:FindFirstChild( "ScrollingFrame" , true )
    if u then
        pcall(function(...)
            for y,u in ipairs(u:GetChildren())do
                if u:IsA( "GuiObject" )and(not u:IsA( "UIListLayout" )and not u:IsA( "UIPadding" ))then
                    local y=u.Name
                    for u,w in ipairs(u:GetDescendants())do
                        if w:IsA( "GuiButton" )or w:IsA( "TextButton" )then
                            local u=(w:IsA( "TextButton" )and w.Text :lower())or w.Name :lower()
                            if u:find( "unequip" )or(u:find( "equip" )and not u:find( "unequip" ))then
                                e[y]= true e[y:lower()]= true
                                local u=y:gsub( "Trail" , "" )e[u]= true e[u:lower()]= true
                            end
                        end
                    end
                end
            end
        end
        )
    end
    return e
end
local function ck(e,...)
    if not e then
        return false
    end
    pcall(function(...)
        if typeof(firebutton1click)== "function" then
            firebutton1click(e)
        elseif typeof(firesignal)== "function" and e.Activated then
            firesignal(e.Activated )
        elseif typeof(firesignal)== "function" and e.MouseButton1Click then
            firesignal(e.MouseButton1Click )
        end
    end
    )
    return true
end
local function vk(...)
    local e=Jk()
    local r=Kk()
    local y=o:FindFirstChild( "PlayerGui" )
    local u=y and((y:FindFirstChild( "TrailShop" )or y:FindFirstChild( "TrailShop" , true )))
    local w=u and u:FindFirstChild( "ScrollingFrame" , true )
    if w then
        for r=#e, 1 , -1 do
            local y=e[r]
            local u=w:FindFirstChild(y.id )or w:FindFirstChild(y.base )or w:FindFirstChild(y.name )
            if not u then
                for e,r in ipairs(w:GetChildren())do
                    if r:IsA( "GuiObject" )and((r.Name :lower()==y.id :lower()or r.Name :lower()==y.base :lower()or r.Name :lower()==y.name :lower()))then
                        u=r
                        break
                    end
                end
            end
            if u then
                local e= false
                local r=nil
                for y,u in ipairs(u:GetDescendants())do
                    if u:IsA( "GuiButton" )or u:IsA( "TextButton" )then
                        local y=(u:IsA( "TextButton" )and u.Text :lower())or u.Name :lower()
                        if y:find( "unequip" )then
                            e= true
                            break
                        elseif y:find( "equip" )and not y:find( "unequip" )then
                            r=u
                        end
                    end
                end
                if e then
                    return true
                end
                if r then
                    ck(r)
                    if q then
                        pcall(function(...) q:InvokeServer(y.id )
                        end
                        )
                    end
                    task.wait ( 0.2 )
                    return true
                end
            end
        end
    end
    if q then
        for y=#e, 1 , -1 do
            local u=e[y]
            local w=r[u.id ]or r[u.id :lower()]or r[u.base ]or r[u.base :lower()]or r[u.name ]or r[u.name :lower()]
            if w then
                pcall(function(...) q:InvokeServer(u.id )
                end
                )
                return true
            end
        end
    end
    return false
end
local ik= 0
local Rk= 8
local function gk(...)
    if not h.autoBuyTrails then
        return
    end
    vk()
    if os.clock ()-ik<Rk then
        return
    end
    local e=Vk()
    if e<= 0 then
        return
    end
    local r=Jk()
    local y=Kk()
    local u=o:FindFirstChild( "PlayerGui" )
    local w=u and((u:FindFirstChild( "TrailShop" )or u:FindFirstChild( "TrailShop" , true )))
    local j=w and w:FindFirstChild( "ScrollingFrame" , true )
    for u=#r, 1 , -1 do
        local w=r[u]
        local a=y[w.id ]or y[w.id :lower()]or y[w.base ]or y[w.base :lower()]or y[w.name ]or y[w.name :lower()]
        if not a and(w.price > 0 and e>=w.price )then
            ik=os.clock ()
            local e= false
            if j then
                local r=j:FindFirstChild(w.id )or j:FindFirstChild(w.base )or j:FindFirstChild(w.name )
                if not r then
                    for e,y in ipairs(j:GetChildren())do
                        if y:IsA( "GuiObject" )and((y.Name :lower()==w.id :lower()or y.Name :lower()==w.base :lower()or y.Name :lower()==w.name :lower()))then
                            r=y
                            break
                        end
                    end
                end
                if r then
                    for r,y in ipairs(r:GetDescendants())do
                        if y:IsA( "GuiButton" )or y:IsA( "TextButton" )then
                            local r=(y:IsA( "TextButton" )and y.Text :lower())or y.Name :lower()
                            if not r:find( "robux" )and(not r:find( "r%$" )and(not r:find( "unequip" )and not r:find( "equip" )))then
                                if r:find( "%$" )or r:find( "buy" )then
                                    ck(y)e= true
                                    break
                                end
                            end
                        end
                    end
                end
            end
            if C then
                pcall(function(...) C:InvokeServer(w.id )
                end
                )e= true
            end
            if e then
                task.wait ( 0.3 )vk()
                break
            end
        end
    end
end
P4=function(...)
    local e=o.Character
    local y=e and e:FindFirstChild( "HumanoidRootPart" )
    if not y then
        return nil
    end
    local u={}
    local w=r:FindFirstChild( "AreaEggSlotsClient" )
    local j=h4( false )
    if j and#j> 0 then
        for e,r in ipairs(j)do
            local w=(r.State == "Slot" or r.State == "Dropped" or r.State == 1 )
            local j=(r.AreaId == "Lake" )or(string.find (string.lower (tostring(r.AreaId )), "lake" )~=nil)or(string.find (string.lower (tostring(r.Uid )), "lake" )~=nil)
            local k=X4[r.Uid ]and(os.clock ()<X4[r.Uid ])
            if w and(j and(r.BoundsCFrame and not k))then
                local e=r.BoundsCFrame.Position
                local w=((y.Position -e)).Magnitude table.insert (u,{[ "Uid" ]=r.Uid ;
                [ "Model" ]=nil;
                [ "Hitbox" ]=nil;
                [ "CFrame" ]=r.BoundsCFrame ,[ "Position" ]=e,[ "Distance" ]=w;
                [ "Area" ]= "Lake" })
            end
        end
    end
    if#u== 0 and(j and#j> 0 )then
        for e,r in ipairs(j)do
            local w=(r.State == "Slot" or r.State == "Dropped" or r.State == 1 )
            local j=r.BoundsCFrame and r.BoundsCFrame.Position
            local k=j and((j.X >= 545 and j.X < 850 ))
            local o=X4[r.Uid ]and(os.clock ()<X4[r.Uid ])
            if w and(k and not o)then
                table.insert (u,{[ "Uid" ]=r.Uid ,[ "Model" ]=nil;
                [ "Hitbox" ]=nil;
                [ "CFrame" ]=r.BoundsCFrame ;
                [ "Position" ]=j;
                [ "Distance" ]=((y.Position -j)).Magnitude ;
                [ "Area" ]=r.AreaId or "Field" })
            end
        end
    end
    if#u== 0 then
        return nil
    end
    table.sort (u,function(e,r,...)
        return e.Distance <r.Distance
    end
    )
    local k=u[ 1 ]
    if k and w then
        for e,r in ipairs(w:GetChildren())do
            local y=r:FindFirstChildWhichIsA( "BasePart" )or r.PrimaryPart
            if y and((y.Position -k.Position )).Magnitude <= 8 then
                k.Model =r
                break
            end
        end
    end
    return k
end
local Qk=nil
local Pk=nil
local Nk= 350
local function Uk(...)
    local e=r:FindFirstChild( "__OBJECTS" )or r:FindFirstChild( "Objects" )
    local y=e and((e:FindFirstChild( "Areas" )or e:FindFirstChild( "Area" )))
    local u=y and((y:FindFirstChild( "GuardAreas" )or y:FindFirstChild( "Guards" )))
    if u then
        local e=u:FindFirstChild( "Light Dark" )or u:FindFirstChild( "LightDark" )or u:FindFirstChild( "Light_Dark" )or u:FindFirstChild( "Light-Dark" )
        if e then
            return e
        end
        for e,r in ipairs(u:GetChildren())do
            local y=string.lower (r.Name )
            if string.find (y, "light" )and string.find (y, "dark" )then
                return r
            end
        end
    end
    if y then
        local e=y:FindFirstChild( "Light Dark" )or y:FindFirstChild( "LightDark" )or y:FindFirstChild( "Light_Dark" )
        if e then
            return e
        end
        for e,r in ipairs(y:GetChildren())do
            local y=string.lower (r.Name )
            if string.find (y, "light" )and string.find (y, "dark" )then
                return r
            end
        end
    end
    for e,r in ipairs(r:GetChildren())do
        local y=r.Name
        if y== "__OBJECTS" or y== "Objects" or y== "Areas" or y== "Map" then
            for e,r in ipairs(r:GetDescendants())do
                local y=string.lower (r.Name )
                if(y== "light dark" or y== "lightdark" or(string.find (y, "light" )and string.find (y, "dark" )))then
                    if r:IsA( "BasePart" )or r:IsA( "Model" )or r:IsA( "Folder" )then
                        return r
                    end
                end
            end
        end
    end
    return nil
end
local function lk(e,...)
    if not e then
        return false
    end
    if Qk then
        local r=((Vector3.new (e.X , 0 ,e.Z )-Vector3.new (Qk.X , 0 ,Qk.Z ))).Magnitude
        if r<=Nk then
            return true
        end
    end
    local r=Uk()
    if not r then
        if e.X >= 5200 then
            return true
        end
        return false
    end
    local y= false pcall(function(...)
        local u,w=nil,nil
        if r:IsA( "BasePart" )then
            u=r.CFrame w=r.Size
        elseif r:IsA( "Model" )then
            u,w=r:GetBoundingBox()
        else
            local e,y=nil,nil
            for r,u in ipairs(r:GetChildren())do
                if u:IsA( "BasePart" )then
                    local r=u.CFrame
                    local w=u.Size / 2
                    local k=r.Position -w
                    local a=r.Position +w
                    if not e then
                        e=k y=a
                    else
                        e=Vector3.new (math.min (e.X ,k.X ),math.min (e.Y ,k.Y ),math.min (e.Z ,k.Z ))y=Vector3.new (math.max (y.X ,a.X ),math.max (y.Y ,a.Y ),math.max (y.Z ,a.Z ))
                    end
                end
            end
            if e and y then
                u=CFrame.new (((e+y))/ 2 )w=y-e
            end
        end
        if u and w then
            Qk=u.Position Pk=u Nk=math.max ( 350 ,math.max (w.X ,w.Z )/ 2 + 150 )
            local r=((Vector3.new (e.X , 0 ,e.Z )-Vector3.new (u.Position.X , 0 ,u.Position.Z ))).Magnitude
            if r<=Nk then
                y= true
                return
            end
            local k=u:PointToObjectSpace(e)
            local a=w/ 2
            if math.abs (k.X )<=(a.X + 200 )and math.abs (k.Z )<=(a.Z + 200 )then
                y= true
                return
            end
        end
        for r,u in ipairs(r:GetDescendants())do
            if u:IsA( "BasePart" )then
                if((e-u.Position )).Magnitude <= 250 then
                    y= true
                    if not Qk then
                        Qk=u.Position
                    end
                    return
                end
            end
        end
    end
    )
    return y
end
local function Dk(e,r,y,...)
    local u=r and r.X or 0
    local w=string.lower (tostring(e or "" ))
    local j=string.lower (tostring(y or "" ))
    if j~= "" and j~= "egg" then
        if string.find (j, "spideron" )or string.find (j, "crustacia" )or string.find (j, "bladehide" )or string.find (j, "mantaris" )or string.find (j, "rhinotaur" )or string.find (j, "mutantshark" )or string.find (j, "mutant shark" )or string.find (j, "gorillaking" )or string.find (j, "gorilla king" )or string.find (j, "nightflame" )then
            return "Titan Temple"
        end
        if string.find (j, "crane" )or string.find (j, "salamander" )or string.find (j, "redpanda" )or string.find (j, "red panda" )or string.find (j, "snowyowl" )or string.find (j, "snowy owl" )or string.find (j, "koiegg" )or string.find (j, "koi egg" )or string.find (j, "stagegg" )or string.find (j, "stag egg" )or string.find (j, "onitiger" )or string.find (j, "oni tiger" )or string.find (j, "kitsune" )then
            return "Cherry Blossom"
        end
        if string.find (j, "centapede" )or string.find (j, "cosmicgecko" )or string.find (j, "cosmic gecko" )or string.find (j, "cosmicgorilla" )or string.find (j, "cosmic gorilla" )or string.find (j, "saturno" )or string.find (j, "saturnita" )or string.find (j, "vacca" )or string.find (j, "cosmic skeleton" )or string.find (j, "skeletonboss" )or string.find (j, "skeleton boss" )or string.find (j, "cosmicdragon" )or string.find (j, "cosmic dragon" )or string.find (j, "lunardragon" )or string.find (j, "lunar dragon" )or string.find (j, "unicornegg" )or string.find (j, "unicorn egg" )then
            return "Cosmic"
        end
        if string.find (j, "dodo" )or string.find (j, "pterodactyl" )or string.find (j, "ankylosaurus" )or string.find (j, "triceratops" )or string.find (j, "bronto" )or string.find (j, "trex" )or string.find (j, "t-rex" )or string.find (j, "tralaledon" )or string.find (j, "mosasaurus" )then
            return "Prehistoric"
        end
        if string.find (j, "parrotfish" )or string.find (j, "swordfish" )or string.find (j, "whaleshark" )or string.find (j, "whale shark" )or string.find (j, "belugawhale" )or string.find (j, "beluga whale" )or string.find (j, "kraken" )or string.find (j, "elmaja" )or string.find (j, "el maja" )then
            return "Abyss Ocean"
        end
        if string.find (j, "lava gecko" )or string.find (j, "lava frog" )or string.find (j, "flaming bull" )or string.find (j, "lava iguana" )or string.find (j, "chillin chilli" )or string.find (j, "cerberus" )or string.find (j, "phoenix" )or string.find (j, "lava dragon" )then
            return "Volcano"
        end
        if string.find (j, "penguin" )or string.find (j, "walrus" )or string.find (j, "polar bear" )or string.find (j, "polarbear" )or string.find (j, "sabertooth" )or string.find (j, "mammoth" )or string.find (j, "yeti" )or string.find (j, "ice dragon" )or string.find (j, "icedragon" )then
            return "Snow"
        end
        if string.find (j, "sand spider" )or string.find (j, "sandspider" )or string.find (j, "royal sphinx" )or string.find (j, "sphinx" )or string.find (j, "tob tobi" )or string.find (j, "tobtobi" )or string.find (j, "jerboa" )or string.find (j, "fennec" )or string.find (j, "camel" )then
            return "Desert"
        end
        if string.find (j, "chimpanzee" )or string.find (j, "toucan" )or string.find (j, "crocodile" )or string.find (j, "orangutini" )or string.find (j, "ananassini" )or string.find (j, "king snake" )or string.find (j, "kingsnake" )then
            return "Jungle"
        end
        if string.find (j, "duckling" )or string.find (j, "catfish" )or string.find (j, "turtle" )or string.find (j, "trulimero" )or string.find (j, "trulicina" )or string.find (j, "swan" )or string.find (j, "axolotl" )or string.find (j, "leviathan" )then
            return "Lake"
        end
        if string.find (j, "burrowing owl" )or string.find (j, "burrowingowl" )or string.find (j, "brr brr" )or string.find (j, "patapim" )or string.find (j, "chicken" )or string.find (j, "dog" )or string.find (j, "bird" )or string.find (j, "raccoon" )or string.find (j, "fox" )then
            return "Forest"
        end
        if string.find (j, "shark" )then
            return "Abyss Ocean"
        end
        if string.find (j, "snake" )then
            return "Desert"
        end
        if string.find (j, "spider" )then
            return "Jungle"
        end
        if string.find (j, "gorilla" )then
            return "Jungle"
        end
        if string.find (j, "tiger" )then
            return "Jungle"
        end
        if string.find (j, "frog" )then
            return "Lake"
        end
        if string.find (j, "bear" )then
            return "Forest"
        end
    end
    if(string.find (w, "light" )and string.find (w, "dark" ))or w== "lightdark" then
        return "Light Dark"
    elseif string.find (w, "titan" )then
        return "Titan Temple"
    elseif string.find (w, "cherry" )then
        return "Cherry Blossom"
    elseif string.find (w, "cosmic" )then
        return "Cosmic"
    elseif string.find (w, "prehistoric" )or string.find (w, "dino" )then
        return "Prehistoric"
    elseif string.find (w, "abyss" )or string.find (w, "ocean" )then
        return "Abyss Ocean"
    elseif string.find (w, "volcano" )or string.find (w, "lava" )then
        return "Volcano"
    elseif string.find (w, "snow" )or string.find (w, "ice" )or string.find (w, "winter" )then
        return "Snow"
    elseif string.find (w, "jungle" )then
        return "Jungle"
    elseif string.find (w, "desert" )or string.find (w, "sand" )then
        return "Desert"
    elseif string.find (w, "lake" )or string.find (w, "water" )then
        return "Lake"
    elseif string.find (w, "forest" )then
        return "Forest"
    end
    if u> 0 then
        if u>= 5200 then
            return "Light Dark"
        elseif u>= 4750 then
            return "Titan Temple"
        elseif u>= 4000 then
            return "Cherry Blossom"
        elseif u>= 3350 then
            return "Cosmic"
        elseif u>= 2780 then
            return "Prehistoric"
        elseif u>= 2250 then
            return "Abyss Ocean"
        elseif u>= 1850 then
            return "Volcano"
        elseif u>= 1450 then
            return "Snow"
        elseif u>= 1150 then
            return "Jungle"
        elseif u>= 920 then
            return "Desert"
        elseif u>= 720 then
            return "Lake"
        else
            return "Forest"
        end
    end
    return "Forest"
end
N4=function(...)
    local e=h4( false )
    if not e or#e== 0 then
        e=h4( true )
    end
    if not e or#e== 0 then
        return nil
    end
    local y=o.Character
    local u=y and y:FindFirstChild( "HumanoidRootPart" )
    local w=u and u.Position or Vector3.new ( 525 , 70 , -360 )
    local function j(e,...) e=tonumber(e)or 0
        if e>= 1000000000000 then
            return string.format ( "%.1fT" ,e/ 1000000000000 )
        end
        if e>= 1000000000 then
            return string.format ( "%.1fB" ,e/ 1000000000 )
        end
        if e>= 1000000 then
            return string.format ( "%.1fM" ,e/ 1000000 )
        end
        if e>= 1000 then
            return string.format ( "%.1fK" ,e/ 1000 )
        end
        return string.format ( "%.0f" ,e)
    end
    local function k(e,r,y,u,...)
        if e and e.PhysicalModel then
            local u=e.PhysicalModel
            local w=u:GetAttribute( "Rarity" )or u:GetAttribute( "RarityTier" )or u:GetAttribute( "Tier" )
            if w and(tostring(w)~= "" and tostring(w)~= "Unknown" )then
                y=tostring(w)
            end
            if not r or r== "Egg" or r== "" then
                r=u:GetAttribute( "Category" )or u:GetAttribute( "AssetCategory" )or u.Name
            end
        end
        local w=string.lower (tostring(e.Rarity or "" ))
        local j=string.lower (tostring(y or "" ))
        for e,r in ipairs({w,j})do
            if r~= "" and(r~= "unknown" and r~= "nil" )then
                if string.find (r, "divine" )then
                    return 6 , "Divine"
                end
                if string.find (r, "eternal" )then
                    return 5 , "Eternal"
                end
                if string.find (r, "secret" )then
                    return 4 , "Secret"
                end
                if string.find (r, "cosmic" )then
                    return 3 , "Cosmic"
                end
                if string.find (r, "mythic" )then
                    return 2 , "Mythic"
                end
                if string.find (r, "legendary" )then
                    return 1 , "Legendary"
                end
                if string.find (r, "epic" )then
                    return 0.5 , "Epic"
                end
                if string.find (r, "rare" )then
                    return 0.3 , "Rare"
                end
                if string.find (r, "uncommon" )then
                    return 0.1 , "Uncommon"
                end
                if string.find (r, "common" )then
                    return 0 , "Common"
                end
            end
        end
        if u and u>= 10 then
            return 6 , "Divine"
        elseif u and u>= 9 then
            return 5 , "Eternal"
        elseif u and u>= 8 then
            return 4 , "Secret"
        elseif u and u>= 7 then
            return 3 , "Cosmic"
        elseif u and u>= 6 then
            return 2 , "Mythic"
        elseif u and u>= 5 then
            return 1 , "Legendary"
        elseif u and u>= 4 then
            return 0.5 , "Epic"
        elseif u and u>= 3 then
            return 0.3 , "Rare"
        elseif u and u>= 2 then
            return 0.1 , "Uncommon"
        elseif u and u>= 1 then
            return 0 , "Common"
        end
        local k=string.lower (string.format ( "%s %s %s %s %s" ,tostring(r or "" ),tostring(e.Uid or "" ),tostring(e.Name or "" ),tostring(e.DisplayName or "" ),tostring(e.EggName or "" )))
        if string.find (k, "nightflame" )or string.find (k, "unicornegg" )or string.find (k, "unicorn egg" )or string.find (k, "shatteredcolossus" )or string.find (k, "kitsune" )or string.find (k, "elmaja" )or string.find (k, "el maja" )then
            return 6 , "Divine"
        end
        if string.find (k, "gorillaking" )or string.find (k, "gorilla king" )or string.find (k, "lunardragon" )or string.find (k, "lunar dragon" )or string.find (k, "onitiger" )or string.find (k, "oni tiger" )or string.find (k, "mosasaurus" )then
            return 5 , "Eternal"
        end
        if string.find (k, "mutantshark" )or string.find (k, "mutant shark" )or string.find (k, "skeletonboss" )or string.find (k, "skeleton boss" )or string.find (k, "stagegg" )or string.find (k, "stag egg" )or string.find (k, "cosmicdragon" )or string.find (k, "cosmic dragon" )or string.find (k, "trex" )or string.find (k, "t-rex" )or string.find (k, "tralaledon" )or string.find (k, "kraken" )then
            return 4 , "Secret"
        end
        if string.find (k, "saturnita" )or string.find (k, "saturno" )or string.find (k, "mantaris" )or string.find (k, "rhinotaur" )or string.find (k, "snowyowl" )or string.find (k, "snowy owl" )or string.find (k, "koiegg" )or string.find (k, "koi egg" )or string.find (k, "triceratops" )or string.find (k, "bronto" )or string.find (k, "whaleshark" )or string.find (k, "whale shark" )or string.find (k, "belugawhale" )or string.find (k, "beluga whale" )then
            return 3 , "Cosmic"
        end
        if string.find (k, "bladehide" )or string.find (k, "redpanda" )or string.find (k, "red panda" )or string.find (k, "cosmicgorilla" )or string.find (k, "cosmic gorilla" )or string.find (k, "ankylosaurus" )or string.find (k, "orca" )then
            return 2 , "Mythic"
        end
        if string.find (k, "spideron" )or string.find (k, "crustacia" )or string.find (k, "salamander" )or string.find (k, "cosmicgecko" )or string.find (k, "cosmic gecko" )or string.find (k, "pterodactyl" )or string.find (k, "sharkegg" )or string.find (k, "shark egg" )then
            return 1 , "Legendary"
        end
        if string.find (k, "crane" )or string.find (k, "centapede" )or string.find (k, "swordfish" )then
            return 0.5 , "Epic"
        end
        if string.find (k, "dodo" )or string.find (k, "parrotfish" )then
            return 0.3 , "Rare"
        end
        local a=tonumber(e.EarningRate or e.Income or 0 )
        if a and a>= 150000000 then
            return 4 , "Secret"
        end
        local o=(y and(y~= "Unknown" and y))or "Common"
        local V=F[o]or 0
        return V,o
    end
    local function a(r,y,...)
        local u={}
        for e,r in ipairs(e)do
            local j=(r.State == "Slot" or r.State == "Dropped" or r.State == "GuardCarried" or r.State == 1 )
            local a=(r.BoundsCFrame and r.BoundsCFrame.Position .X < 530 )or string.find (tostring(r.Uid ), "FirstArea" )
            local o=X4[r.Uid ]and(os.clock ()<X4[r.Uid ])
            if j and(not a and(((y or not o))and r.BoundsCFrame ))then
                local e=r.AssetCategory or "Egg"
                local y= 0
                local j= 0
                local a= 0
                local o= "Unknown"
                if p then
                    pcall(function(...)
                        if p.RarityRankForCategory then
                            y=p.RarityRankForCategory (e)or 0
                        end
                        if p.ProfileIncomePerSecond then
                            j=p.ProfileIncomePerSecond (e)or 0
                        end
                        if p.SalePrice then
                            a=p.SalePrice (e)or 0
                        end
                        if p.Assets and p.Assets [e]then
                            local y=p.Assets [e]o=y.Rarity or(y.Egg and y.Egg.Rarity )or "Unknown"
                            if not j or j== 0 then
                                j=y.EarningRate or(y.Egg and y.Egg.EarningRate )or 0
                            end
                        end
                    end
                    )
                end
                local V=r.BoundsCFrame.Position .X
                local H=r.BoundsCFrame.Position
                local t=r.AreaId
                if((not t or t== "" or t== "Unknown" ))and r.PhysicalModel then
                    t=r.PhysicalModel :GetAttribute( "AreaId" )or r.PhysicalModel :GetAttribute( "Area" )
                end
                local B=string.format ( "%s %s %s %s" ,tostring(e or "" ),tostring(r.Uid or "" ),tostring(r.Name or "" ),(r.PhysicalModel and r.PhysicalModel.Name )or "" )
                local J=Dk(t,H,B)
                local K,c=k(r,e,o,y)
                local v=(K>= 4 or c== "Secret" or c== "Eternal" or c== "Divine" )
                local i=(h.selectedZones and h.selectedZones [J]== true )
                local R=(h.selectedRarities and h.selectedRarities [c]== true )
                local g= false
                if v then
                    g= true
                else
                    if i and R then
                        g= true
                    end
                end
                if g then
                    local k=tonumber(r.AssetScale or r.Scale )or 1
                    local a= 1
                    if r.Mutations and type(r.Mutations )== "table" then
                        for e,r in pairs(r.Mutations )do
                            local y=(type(r)== "table" and tonumber(r.Multiplier or r.Value ))or tonumber(r)or 1.5 a=a*y
                        end
                    elseif r.Mutation then
                        a= 1.5
                    end
                    local o=(j*k)*a
                    local V=f[J]or 50
                    if o<= 0 then
                        o=(((V^ 2 )*k)*a)* 10
                    end
                    local H=((w-r.BoundsCFrame.Position )).Magnitude table.insert (u,{[ "Uid" ]=r.Uid ,[ "Category" ]=tostring(e),[ "Area" ]=tostring(J),[ "ZoneWeight" ]=V,[ "Rarity" ]=tostring(c);
                    [ "RarityTier" ]=K;
                    [ "Rank" ]=y;
                    [ "Income" ]=j,[ "RealIncome" ]=o;
                    [ "Scale" ]=k,[ "MutMultiplier" ]=a,[ "CFrame" ]=r.BoundsCFrame ;
                    [ "Position" ]=r.BoundsCFrame.Position ,[ "Distance" ]=H,[ "Model" ]=r.PhysicalModel })
                end
            end
        end
        if#u== 0 then
            return nil
        end
        local function a(e,...)
            local r=e.RarityTier or 0
            local y=e.ZoneWeight or 50
            if r>= 4 then
                return( 400000 +(r* 10000 ))+y
            else
                return(y* 11 )+(r* 1000 )
            end
        end
        table.sort (u,function(e,r,...)
            local y=a(e)
            local u=a(r)
            if y~=u then
                return y>u
            end
            if e.ZoneWeight ~=r.ZoneWeight then
                return e.ZoneWeight >r.ZoneWeight
            end
            if math.abs (e.RealIncome -r.RealIncome )> 1 then
                return e.RealIncome >r.RealIncome
            end
            if math.abs (e.Scale -r.Scale )> 0.05 then
                return e.Scale >r.Scale
            end
            return e.Distance <r.Distance
        end
        )
        local o=u[ 1 ]
        local V={}
        for e= 1 ,math.min ( 3 ,#u), 1 do
            local r=u[e]table.insert (V,string.format ( "#%d %s[%s|%s] Score:%d $%s/s (%.1fx) dist=%dm" ,e,tostring(r.Category ),tostring(r.Rarity ),tostring(r.Area ),a(r),j(r.RealIncome ),tonumber(r.Scale )or 1 ,math.floor (tonumber(r.Distance )or 0 )))
        end
        if#V> 0 then
            H( "[AutoSteal v42.44] " ..table.concat (V, " | " ))
        end
        return o
    end
    local V=a( false , false )
    if not V then
        X4={}V=a( false , true )
    end
    if not V then
        e=h4( true )V=a( false , true )
    end
    if V and r:FindFirstChild( "AreaEggSlotsClient" )then
        for e,r in ipairs(r.AreaEggSlotsClient :GetChildren())do
            local y=r:FindFirstChildWhichIsA( "BasePart" )or r.PrimaryPart
            if y and((y.Position -V.Position )).Magnitude <= 12 then
                V.Model =r
                break
            end
        end
    end
    return V
end
U4=function(e,u,w,j,...)
    local k=o.Character
    local a=k and k:FindFirstChild( "HumanoidRootPart" )
    local V=k and k:FindFirstChildOfClass( "Humanoid" )
    if not a or not V then
        return false
    end
    h.securingEgg = true h.isReturning = false h.stateTime =os.clock ()h.holdingEggForGuard = true
    local s=u.Position V4(s, 14 )h.currentTargetModel =w h.targetPosition =s a.AssemblyLinearVelocity =Vector3.zero a.AssemblyAngularVelocity =Vector3.zero Z4(k)pcall(function(...) o:RequestStreamAroundAsync(s)
    end
    )
    if not w and r:FindFirstChild( "AreaEggSlotsClient" )then
        for e,r in ipairs(r.AreaEggSlotsClient :GetChildren())do
            local y=r:FindFirstChildWhichIsA( "BasePart" )or r.PrimaryPart
            if y and((y.Position -s)).Magnitude <= 16 then
                w=r h.currentTargetModel =r
                break
            end
        end
    end
    if w then
        pcall(function(...)
            for r,y in ipairs(w:GetDescendants())do
                if y:IsA( "BasePart" )and(y.Transparency > 0.8 and(y.Name ~= "Hitbox" and(y.Name ~= "Root" and not y.Name :find( "Pad" ))))then
                    y.Transparency = 0
                end
            end
        end
        )
    end
    h.statusText = "[1/4] Lifting Egg to Trigger Guard..." H(string.format ( "[GuardStrike] Step 1: Lifting target egg (%s)..." ,tostring(e)))
    local p=os.clock ()+ 3.5
    local B= 0
    while not w4()and(os.clock ()<p and(h.alive and h.securingEgg ))do
        if j and O4~=j then
            t( "[GuardStrike] Cancelled by session switch in Step 1" )
            break
        end
        if not h.pureTweenFarm and(not h.autoFarmLoop and not h.teleporting )then
            break
        end
        if e and(os.clock ()-B> 0.4 )then
            B=os.clock ()
            local r,y=k4(e)
            if not r and y== "CarriedByOther" then
                t(string.format ( "[GuardStrike] Target egg %s was snatched by another player! Aborting pickup..." ,tostring(e)))
                break
            end
        end
        k:PivotTo(u*CFrame.new ( 0 , 0.4 , 0 ))d4(w,s)
        if e and i then
            task.spawn (function(...) pcall(function(...)
                    if i:IsA( "RemoteFunction" )then
                        i:InvokeServer({[ "Uid" ]=e})i:InvokeServer(e)
                    else
                        i:FireServer({[ "Uid" ]=e})i:FireServer(e)
                    end
                end
                )
            end
            )
        end
        y.Heartbeat :Wait()
    end
    if not w4()then
        t( "[GuardStrike] Initial egg pickup timed out or egg was stolen" )
        if e then
            X4[e]=os.clock ()+ 2
        end
        h.currentTargetModel =nil h.targetPosition =nil h.securingEgg = false h.holdingEggForGuard = false
        return false
    end
    h.statusText = "[2/4] Waiting for Guard Strike..." H( "[GuardStrike] Step 2: Egg lifted! Triggering guard strike..." )
    local J=os.clock ()
    local K=J+ 4.5
    local c= false
    while w4()and(os.clock ()<K and(h.alive and h.securingEgg ))do
        if j and O4~=j then
            t( "[GuardStrike] Cancelled by session switch in Step 2" )
            break
        end
        if not h.pureTweenFarm and(not h.autoFarmLoop and not h.teleporting )then
            break
        end
        k:PivotTo(u*CFrame.new ( 0 , 0.4 , 0 ))V4(s, 14 )
        if P and not c then
            task.spawn (function(...) pcall(function(...)
                    if P:IsA( "RemoteFunction" )then
                        P:InvokeServer()
                    else
                        P:FireServer()
                    end
                end
                )
            end
            )c= true
        end
        y.Heartbeat :Wait()
    end
    h.statusText = "[3/4] Re-grabbing Egg..." H( "[GuardStrike] Step 3: Guard struck! Re-grabbing egg..." )
    local v=os.clock ()+ 3
    while not w4()and(os.clock ()<v and(h.alive and h.securingEgg ))do
        if j and O4~=j then
            t( "[GuardStrike] Cancelled by session switch in Step 3" )
            break
        end
        if not h.pureTweenFarm and(not h.autoFarmLoop and not h.teleporting )then
            break
        end
        k:PivotTo(u*CFrame.new ( 0 , 0.4 , 0 ))d4(w,s)
        if e and i then
            task.spawn (function(...) pcall(function(...)
                    if i:IsA( "RemoteFunction" )then
                        i:InvokeServer({[ "Uid" ]=e})i:InvokeServer(e)
                    else
                        i:FireServer({[ "Uid" ]=e})i:FireServer(e)
                    end
                end
                )
            end
            )
        end
        y.Heartbeat :Wait()
    end
    local R=j4(e)
    if not R then
        task.wait ( 0.12 )R=j4(e)
    end
    h.currentTargetModel =nil h.targetPosition =nil h.securingEgg = false h.holdingEggForGuard = false
    if j and O4~=j then
        return false
    end
    if R then
        pcall(u4)H( "[GuardStrike] Egg successfully secured after guard strike! Stashed in backpack." )h.statusText = "Egg Secured! Tweening along Z=-360..."
    else
        t( "[-] Failed to re-grab egg after guard strike (stolen or despawned)" )h.statusText = "[-] Failed to re-grab egg"
        if e then
            X4[e]=os.clock ()+ 2
        end
    end
    return R
end
l4=function(e,u,...)
    if h.teleporting or h.glidingToTarget or h.delivering or h.securingEgg then
        return false
    end
    h.teleporting = true h.isReturning = false h.stateTime =os.clock ()
    local w=o.Character
    local j=w and w:FindFirstChild( "HumanoidRootPart" )
    local k=w and w:FindFirstChildOfClass( "Humanoid" )
    if not j or not k then
        D4()
        return false
    end
    if k then
        k:UnequipTools()
    end
    h.statusText = "[1/7] Pre-Flight Desync..."
    if not h.swapped then
        A4()
    end
    if not h.godmode then
        b4( true )
    end
    Z4(w)
    if not e then
        e=N4()
    end
    local a=e and e.CFrame or S
    local V=e and e.Uid
    local H=a.Position
    if V then
        local e,r=k4(V)
        if not e and r~= "CarriedBySelf" then
            t(string.format ( "[Snipe] Target egg %s is already taken (%s)! Selecting next target..." ,tostring(V),tostring(r)))h.statusText = "Target taken by another player!" X4[V]=os.clock ()+ 5 D4()
            return false
        end
    end
    local s=select( 2 ,e4())
    if not s then
        local e=P4()
        if not e then
            t( "[-] Lake egg not found" )h.statusText = "[-] No Lake egg found" D4()
            return false
        end
        h.currentTargetModel =e.Model h.targetPosition =e.Position
        local r=((j.Position -e.Position )).Magnitude
        local w=e.CFrame *CFrame.new ( 0 , 0.4 , 0 )pcall(function(...) o:RequestStreamAroundAsync(e.Position )
        end
        )V4(e.Position , 8 )
        if r> 60 then
            h.statusText =string.format ( "[2/7] Gliding to Lake Egg (%.0f studs)..." ,r)h.glidingToTarget = true
            local y=R4(w,h.glideSpeed ,e.Uid ,u)h.glidingToTarget = false
            if not y then
                t( "[-] Lake starter egg was taken during flight" )X4[e.Uid ]=os.clock ()+ 5 D4()
                return false
            end
        else
            h.statusText = "[2/7] Aligning with Lake Egg..." j.CFrame =w j.AssemblyLinearVelocity =Vector3.zero task.wait ( 0.04 )
        end
        j.Anchored = true task.wait ( 0.06 )j.Anchored = false h.holdingEggForGuard = true
        local k=os.clock ()+ 3
        while not w4()and(os.clock ()<k and(h.alive and h.teleporting ))do
            if u and O4~=u then
                t( "[Snipe] Cancelled by session switch during Lake egg pickup" )D4()
                return false
            end
            if not h.autoFarmLoop and not h.teleporting then
                D4()
                return false
            end
            d4(e.Model ,e.Position )
            if e.Uid and i then
                task.spawn (function(...) pcall(function(...)
                        if i:IsA( "RemoteFunction" )then
                            i:InvokeServer({[ "Uid" ]=e.Uid })
                        else
                            i:FireServer({[ "Uid" ]=e.Uid })
                        end
                    end
                    )
                end
                )
            end
            y.Heartbeat :Wait()
        end
        s=select( 2 ,e4())
        if not w4()then
            t( "[-] Lake egg pickup failed" )h.statusText = "[-] Lake pickup failed" D4()
            return false
        end
    end
    h.statusText = "[3/7] Pre-streaming Target..." pcall(function(...) o:RequestStreamAroundAsync(H)
    end
    )V4(H, 12 )h.statusText = "[4/7] Waiting for physical bounce..." j.Anchored = false k:ChangeState(Enum.HumanoidStateType.Running )
    local p=(k.WalkSpeed > 0 )and k.WalkSpeed or 16 k.WalkSpeed = 0 k:Move(Vector3.zero , false )j.AssemblyLinearVelocity =Vector3.zero j.AssemblyAngularVelocity =Vector3.zero task.wait ( 0.04 )
    local B=j.Position
    local J=B.Y
    local K=select( 2 ,e4())or s
    local c= false
    local v=nil
    if N and N:IsA( "RemoteEvent" )then
        v=N.OnClientEvent :Connect(function(...) c= true
            if v then
                v:Disconnect()
            end
        end
        )
    end
    h.holdingEggForGuard = true H4(K)
    local R=os.clock ()
    local g= false
    local Q=os.clock ()+ 2.5
    local P= false
    while os.clock ()<Q and(h.alive and h.teleporting )do
        if u and O4~=u then
            t( "[Snipe] Cancelled by session switch during strike bounce" )
            if v then
                v:Disconnect()
            end
            k.WalkSpeed =p D4()
            return false
        end
        local e=os.clock ()-R
        local r=j.AssemblyLinearVelocity
        local w=j.Position
        local a=w.Y -J
        local o=((w-B)).Magnitude
        if e>= 0.08 then
            local e=c or(r.Y >= 10 )or(a>= 1.5 and r.Magnitude >= 16 )or(o>= 2 )or(r.Magnitude >= 20 )
            if e then
                g= true
                break
            end
        end
        if e>= 0.5 and not P then
            P= true H4(K)
        end
        y.Heartbeat :Wait()
    end
    if v then
        v:Disconnect()
    end
    k.WalkSpeed =p h.holdingEggForGuard = false
    if not g then
        t( "[-] No bounce detected, aborting" )h.statusText = "[-] Aborted (No bounce detected)" D4()pcall(u4)
        return false
    end
    task.wait ( 0.05 )
    if V then
        local e,r=k4(V)
        if not e and r== "CarriedByOther" then
            t(string.format ( "[Snipe] Target egg %s was snatched while bouncing (%s)! Aborting warp..." ,tostring(V),tostring(r)))h.statusText = "Target taken! Aborting warp..." X4[V]=os.clock ()+ 5 D4()
            return false
        end
    end
    h.currentTargetModel =e and e.Model h.targetPosition =H h.statusText = "[5/7] Warping to Target Egg..." V4(H, 8 )w:PivotTo(a*CFrame.new ( 0 , 0.4 , 0 ))j.Anchored = true
    for e,r in ipairs(w:GetDescendants())do
        if r:IsA( "BasePart" )then
            r.AssemblyLinearVelocity =Vector3.zero r.AssemblyAngularVelocity =Vector3.zero
        end
    end
    h.statusText = "[6/7] Picking up Target Egg..."
    local U=o:FindFirstChild( "Backpack" )
    for e,y in ipairs(w:GetChildren())do
        if y:IsA( "Tool" )then
            pcall(function(...)
                if U then
                    y.Parent =U
                else
                    y.Parent =r
                end
            end
            )
        end
    end
    task.wait ( 0.06 )j.Anchored = false k:ChangeState(Enum.HumanoidStateType.Running )
    local l=U4(V,a,e and e.Model ,u)j.Anchored = false k:ChangeState(Enum.HumanoidStateType.Running )
    for e,r in ipairs(w:GetDescendants())do
        if r:IsA( "BasePart" )then
            r.AssemblyLinearVelocity =Vector3.zero r.AssemblyAngularVelocity =Vector3.zero
        end
    end
    if not l then
        t( "[-] Guard Strike criteria not met" )h.statusText = "[-] Guard Strike criteria failed" D4()
        return false
    else
        h.statusText = "[7/7] Target Secured! Stashing into Backpack..." h.teleporting = false pcall(u4)
        return true
    end
end
T4=function(e,...)
    if Y4==e then
        return
    end
    O4=O4+ 1
    local r=O4 Y4= "SWITCHING" h.pureTweenFarm = false h.autoFarmLoop = false pcall(D4)pcall(u4)
    if e== "TWEEN" then
        if W4 then
            W4( false , true )
        end
        if x4 then
            x4( true , true )
        end
    elseif e== "WARP" then
        if x4 then
            x4( false , true )
        end
        if W4 then
            W4( true , true )
        end
    else
        if x4 then
            x4( false , true )
        end
        if W4 then
            W4( false , true )
        end
    end
    task.delay ( 0.06 ,function(...)
        if O4==r then
            Y4=e
            if e== "TWEEN" then
                h.pureTweenFarm = true h.autoFarmLoop = false pcall(u4)H( "[FarmController] Pure Auto Steal (Tween) ACTIVATED exclusively." )
            elseif e== "WARP" then
                h.autoFarmLoop = true h.pureTweenFarm = false pcall(u4)H( "[FarmController] Snipe Auto Loop (Warp) ACTIVATED exclusively." )
            else
                h.pureTweenFarm = false h.autoFarmLoop = false
                if not h.isBatchPlacing then
                    h.batchStealCount = 0
                end
                H( "[FarmController] All farms DEACTIVATED. Bot idle." )
            end
        end
    end
    )
end
local Ck=os.clock ()task.spawn (function(...)
    while h.alive do
        local r,y=pcall(function(...)
            if h.pureTweenFarm and(not h.autoFarmLoop and(Y4== "TWEEN" and(not h.isBatchPlacing and(not h.teleporting and(not h.glidingToTarget and(not h.securingEgg and(not h.delivering and not h.isReturning )))))))then
                local r=o.Character
                local y=r and r:FindFirstChild( "HumanoidRootPart" )
                local u=r and r:FindFirstChildOfClass( "Humanoid" )
                if y and u then
                    pcall(u4)
                    local u=w4()
                    if not u then
                        local u=O4
                        local w=N4()
                        if w and(h.pureTweenFarm and(Y4== "TWEEN" and O4==u))then
                            if h.onTreadmill or L4()then
                                h.statusText = "[AutoSteal] Target found! Getting off treadmill..." M4()task.wait ( 0.08 )
                            end
                            local j,k=k4(w.Uid )
                            if not j and k~= "CarriedBySelf" then
                                H(string.format ( "[AutoSteal] Egg %s already taken (%s). Switching to next target..." ,tostring(w.Uid ),tostring(k)))X4[w.Uid ]=os.clock ()+ 5 task.wait ( 0.12 )
                                return
                            end
                            h.currentTargetModel =w.Model h.targetPosition =w.Position h.glidingToTarget = true h.stateTime =os.clock ()
                            local a=((w.Scale and w.Scale > 1.05 ))and string.format ( " | %.1fx" ,w.Scale )or "" h.statusText =string.format ( "[AutoSteal] Flying to %s (%s%s)..." ,tostring(w.Category or "Egg" ),tostring(w.Area or "Field" ),a)H(string.format ( "[AutoSteal] Flying to %s | Zone: %s%s | Rank: %d (Corridor Z=-360)" ,tostring(w.Category or "Egg" ),tostring(w.Area or "Field" ),a,tonumber(w.Rank )or 1 ))
                            if not h.swapped then
                                A4()
                            end
                            if not h.godmode then
                                b4( true )
                            end
                            Z4(r)pcall(function(...) o:RequestStreamAroundAsync(w.Position )
                            end
                            )
                            local V=w.CFrame *CFrame.new ( 0 , 0.4 , 0 )
                            local s=R4(V,h.glideSpeed ,w.Uid ,u)h.glidingToTarget = false
                            if O4~=u or not h.pureTweenFarm or Y4~= "TWEEN" then
                                return
                            end
                            if not s then
                                t( "[AutoSteal] Egg was taken during flight. Switching to next target..." )X4[w.Uid ]=os.clock ()+ 5 D4()
                                return
                            end
                            if h.pureTweenFarm and(Y4== "TWEEN" and((y.Position -w.Position )).Magnitude <= 22 )then
                                local r=U4(w.Uid ,V,w.Model ,u)
                                if not r and w4()then
                                    r= true
                                end
                                if O4~=u or not h.pureTweenFarm or Y4~= "TWEEN" then
                                    return
                                end
                                if r then
                                    pcall(u4)
                                    if h.autoGlide then
                                        h.statusText = "[AutoSteal] Secured! Tweening to Safe Line X=525..." H( "[AutoSteal] Egg secured after Guard Strike! Returning smoothly to Safe Line X=525 along Z=-360..." )Q4(h.glideSpeed ,u)pcall(u4)
                                        local r=y4()h.statusText =string.format ( "Stashed in Bag (%d Eggs). Next steal..." ,r)H(string.format ( "[AutoSteal] Egg stashed in bag (%d total eggs). Hands-Free ready for next steal..." ,r))
                                    else
                                        h.statusText = "[AutoSteal] Secured! (Auto Return is OFF)" H( "[AutoSteal] Egg secured! Staying at target (Auto Return is OFF)." )
                                    end
                                    pcall(u4)h.isReturning = false h.delivering = false h.glidingToTarget = false h.securingEgg = false h.currentTargetModel =nil h.targetPosition =nil
                                    if c4( "TWEEN" )then
                                        return
                                    end
                                else
                                    if O4==u and(h.pureTweenFarm and Y4== "TWEEN" )then
                                        t( "[AutoSteal] Guard Strike or Re-grab failed. Retrying with next egg..." )X4[w.Uid ]=os.clock ()+ 5 D4()
                                    end
                                end
                            else
                                h.currentTargetModel =nil h.targetPosition =nil h.glidingToTarget = false
                            end
                        else
                            if os.clock ()-Ck> 5 then
                                X4={}Ck=os.clock ()
                            end
                            if h.autoTreadmill and(not h.isBatchPlacing and not h.isHatching )then
                                if not h.onTreadmill and not L4()then
                                    h.statusText = "[AutoTreadmill] No targets. Mounting treadmill..." f4(u)
                                else
                                    h.statusText = "[AutoTreadmill] Running on treadmill (Waiting for eggs...)"
                                end
                            else
                                h.statusText = "[AutoSteal] Scanning for targets..."
                            end
                        end
                    end
                end
            end
        end
        )
        if not r then
            t( "[AutoSteal Loop Recovered]:" ,tostring(y))pcall(D4)
        end
        task.wait ( 0.08 )
    end
end
)
local qk=os.clock ()task.spawn (function(...)
    while h.alive do
        local r,y=pcall(function(...)
            if h.autoFarmLoop and(not h.pureTweenFarm and(Y4== "WARP" and(not h.isBatchPlacing and(not h.teleporting and(not h.glidingToTarget and(not h.securingEgg and(not h.delivering and not h.isReturning )))))))then
                local r=o.Character
                local y=r and r:FindFirstChild( "HumanoidRootPart" )
                local u=r and r:FindFirstChildOfClass( "Humanoid" )
                if y and u then
                    pcall(u4)
                    local r=w4()
                    if not r then
                        local r=O4
                        local y=N4()
                        if y and(h.autoFarmLoop and(Y4== "WARP" and O4==r))then
                            if h.onTreadmill or L4()then
                                h.statusText = "[SnipeLoop] Target found! Getting off treadmill..." M4()task.wait ( 0.08 )
                            end
                            local u=((y.Scale and y.Scale > 1.05 ))and string.format ( " | %.1fx" ,y.Scale )or "" H(string.format ( "[SnipeLoop] Starting Warp Snipe: %s | Zone: %s%s (Rank %d)" ,tostring(y.Category or "Egg" ),tostring(y.Area or "Field" ),u,tonumber(y.Rank )or 1 ))h.statusText =string.format ( "[SnipeLoop] Warping for %s%s..." ,tostring(y.Category or "Egg" ),u)
                            local w=l4(y,r)
                            if O4~=r or not h.autoFarmLoop or Y4~= "WARP" then
                                return
                            end
                            if w then
                                pcall(u4)
                                if h.autoGlide then
                                    h.statusText = "[SnipeLoop] Target secured! Tweening to Safe Line X=525..." Q4(h.glideSpeed ,r)pcall(u4)
                                    local y=y4()h.statusText =string.format ( "Stashed in Bag (%d Eggs). Next snipe..." ,y)H(string.format ( "[SnipeLoop] Egg stashed in bag (%d total eggs). Hands-Free ready for next snipe..." ,y))
                                else
                                    h.statusText = "[SnipeLoop] Target secured! (Auto Return is OFF)" H( "[SnipeLoop] Snipe successful! Staying at target (Auto Return is OFF)." )
                                end
                                pcall(u4)h.isReturning = false h.delivering = false
                                if c4( "WARP" )then
                                    return
                                end
                            else
                                if O4==r and(h.autoFarmLoop and Y4== "WARP" )then
                                    t( "[SnipeLoop] Snipe cycle failed. Resetting for next target..." )
                                    if y and y.Uid then
                                        X4[y.Uid ]=os.clock ()+ 5
                                    end
                                    pcall(D4)
                                end
                            end
                        else
                            if os.clock ()-qk> 5 then
                                X4={}qk=os.clock ()
                            end
                            if h.autoTreadmill and(not h.isBatchPlacing and not h.isHatching )then
                                if not h.onTreadmill and not L4()then
                                    h.statusText = "[AutoTreadmill] No targets. Mounting treadmill..." f4(r)
                                else
                                    h.statusText = "[AutoTreadmill] Running on treadmill (Waiting for eggs...)"
                                end
                            else
                                h.statusText = "[SnipeLoop] Searching for targets..."
                            end
                        end
                    end
                end
            end
        end
        )
        if not r then
            t( "[SnipeLoop Loop Recovered]:" ,tostring(y))pcall(D4)
        end
        task.wait ( 0.08 )
    end
end
)task.spawn (function(...)
    while h.alive do
        local r,y=pcall(function(...)
            if h.autoTreadmill and(not h.pureTweenFarm and(not h.autoFarmLoop and(not h.isBatchPlacing and(not h.isHatching and(not h.teleporting and(not h.glidingToTarget and(not h.securingEgg and(not h.delivering and not h.isReturning ))))))))then
                local e=o.Character
                local y=e and e:FindFirstChild( "HumanoidRootPart" )
                if y and not w4()then
                    if not h.onTreadmill and not L4()then
                        h.statusText = "[AutoTreadmill] Idle without farm. Mounting treadmill..." f4()
                    end
                end
            end
        end
        )task.wait ( 0.5 )
    end
end
)task.spawn (function(...)
    while h.alive do
        pcall(function(...)
            if h.autoUpgradeTreadmill then
                pk()
            end
        end
        )task.wait ( 5 )pcall(function(...)
            if h.autoBuyTrails then
                gk()
            end
        end
        )task.wait ( 5 )
    end
end
)task.spawn (function(...)
    while h.alive do
        if h.autoHatch and(not h.securingEgg and(not h.teleporting and not h.isHatching ))then
            pcall(function(...) J4( false )
            end
            )
        end
        task.wait ( 4 )
    end
end
)
local nk=nil
local function fk(e,...) pcall(function(...)
        if e:IsA( "BasePart" )then
            e.Material =Enum.Material.SmoothPlastic e.Reflectance = 0 e.CastShadow = false
            if e:IsA( "MeshPart" )then
                e.TextureID = "" pcall(function(...) e.RenderFidelity =Enum.RenderFidelity.Performance
                end
                )pcall(function(...) e.CollisionFidelity =Enum.CollisionFidelity.Box
                end
                )
            end
        elseif e:IsA( "SpecialMesh" )then
            e.TextureId = ""
        elseif e:IsA( "Decal" )or e:IsA( "Texture" )or e:IsA( "SurfaceAppearance" )then
            e.Transparency = 1
        elseif e:IsA( "ParticleEmitter" )or e:IsA( "Trail" )or e:IsA( "Smoke" )or e:IsA( "Fire" )or e:IsA( "Sparkles" )then
            e.Enabled = false
        elseif e:IsA( "Beam" )then
            e.Enabled = false
        elseif e:IsA( "Explosion" )then
            e.Visible = false
        elseif e:IsA( "Light" )or e:IsA( "PointLight" )or e:IsA( "SpotLight" )or e:IsA( "SurfaceLight" )then
            e.Enabled = false
        elseif e:IsA( "Highlight" )and e.Name ~= "EggESP_Highlight" then
            e.Enabled = false
        end
    end
    )
end
local function Mk(...) h.performanceMode = true pcall(function(...)
        local e=r:FindFirstChild( "KenHub_EggESP" )
        if e then
            e:Destroy()
        end
        local y=game:GetService( "Lighting" )y.GlobalShadows = false y.FogEnd = 9000000000 y.Brightness = 1 y.ClockTime = 14 y.OutdoorAmbient =Color3.fromRGB ( 128 , 128 , 128 )
        for e,r in ipairs(y:GetChildren())do
            if r:IsA( "PostEffect" )or r:IsA( "BloomEffect" )or r:IsA( "BlurEffect" )or r:IsA( "ColorCorrectionEffect" )or r:IsA( "SunRaysEffect" )or r:IsA( "DepthOfFieldEffect" )or r:IsA( "Atmosphere" )then
                pcall(function(...) r.Enabled = false
                end
                )
            elseif r:IsA( "Sky" )then
                pcall(function(...) r.Parent =nil
                end
                )
            end
        end
        local u=workspace:FindFirstChildOfClass( "Terrain" )
        if u then
            pcall(function(...) u.Decoration = false u.WaterWaveSize = 0 u.WaterWaveSpeed = 0 u.WaterReflectance = 0 u.WaterTransparency = 0
            end
            )
        end
        for e,r in ipairs(workspace:GetDescendants())do
            fk(r)
        end
        if not nk then
            nk=workspace.DescendantAdded :Connect(function(e,...)
                if h.performanceMode then
                    fk(e)
                end
            end
            )
        end
        pcall(function(...)
            if settings and(settings()).Rendering then
                (settings()).Rendering.QualityLevel = 1
            end
        end
        )
    end
    )
end
local function Ik(...) h.performanceMode = false
    if nk then
        pcall(function(...) nk:Disconnect()
        end
        )nk=nil
    end
    pcall(function(...)
        local e=game:GetService( "Lighting" )e.GlobalShadows = true
        for e,r in ipairs(e:GetChildren())do
            if r:IsA( "PostEffect" )or r:IsA( "BloomEffect" )or r:IsA( "BlurEffect" )or r:IsA( "ColorCorrectionEffect" )or r:IsA( "SunRaysEffect" )or r:IsA( "DepthOfFieldEffect" )or r:IsA( "Atmosphere" )then
                pcall(function(...) r.Enabled = true
                end
                )
            end
        end
        local r=workspace:FindFirstChildOfClass( "Terrain" )
        if r then
            pcall(function(...) r.Decoration = true
            end
            )
        end
    end
    )
end
local Lk= false
local function Ek(...) pcall(function(...)
        local e=game:GetService( "VirtualInputManager" )
        if e then
            e:SendKeyEvent( true ,Enum.KeyCode.Escape , false ,game)task.wait ( 0.12 )e:SendKeyEvent( false ,Enum.KeyCode.Escape , false ,game)task.wait ( 0.35 )e:SendKeyEvent( true ,Enum.KeyCode.Escape , false ,game)task.wait ( 0.12 )e:SendKeyEvent( false ,Enum.KeyCode.Escape , false ,game)pcall(function(...)
                if typeof(e.SendTouchEvent )== "function" then
                    e:SendTouchEvent( 99999 , 0 , 15 , 15 )task.wait ( 0.04 )e:SendTouchEvent( 99999 , 2 , 15 , 15 )
                end
            end
            )
        end
    end
    )pcall(function(...)
        if typeof(mousemoverel)== "function" then
            mousemoverel( 1 , 0 )task.wait ( 0.05 )mousemoverel( -1 , 0 )
        end
    end
    )
end
local function bk(...)
    if Lk then
        return
    end
    Lk= true task.spawn (function(...)
        while h and(h.alive and h.antiAFK )do
            local r= 0
            while r< 600 and(h and(h.alive and(h.antiAFK and Lk)))do
                task.wait ( 5 )r=r+ 5
            end
            if not h.antiAFK or not Lk then
                break
            end
            Ek()
        end
        Lk= false
    end
    )
end
local function Ak(...) Lk= false
end
y.Heartbeat :Connect(function(...)
    local e=o.Character
    local r=e and e:FindFirstChild( "HumanoidRootPart" )
    local y=e and e:FindFirstChildOfClass( "Humanoid" )
    if not r then
        return
    end
    if y and not((h and h.onTreadmill ))then
        if y.PlatformStand then
            y.PlatformStand = false y:ChangeState(Enum.HumanoidStateType.Running )
        end
        if y.Sit and((h.pureTweenFarm or h.autoFarmLoop or h.isReturning or h.glidingToTarget ))then
            y.Sit = false y:ChangeState(Enum.HumanoidStateType.Running )
        end
    end
    local u=r.Position
    local w=w4()
    if u.Y < 45 then
        r.CFrame =CFrame.new (u.X , 72 ,u.Z )r.AssemblyLinearVelocity =Vector3.zero
        return
    end
    if((h.pureTweenFarm or h.autoFarmLoop ))and not h.holdingEggForGuard then
        local r= false
        for e,y in ipairs(e:GetChildren())do
            if y:IsA( "Tool" )then
                r= true
                break
            end
        end
        if r then
            u4()
        end
    end
    if h.pureTweenFarm or h.autoFarmLoop or h.teleporting or h.glidingToTarget or h.delivering or h.securingEgg or h.isReturning then
        return
    end
    if h.alive and(h.autoGlide and(w and(not a4()and u.X >E)))then
        task.spawn (function(...) Q4(h.glideSpeed )u4()h.isReturning = false h.delivering = false
        end
        )
    end
end
)
local Sk= "iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAedEVYdFNvZnR3YXJlAFBhaW50Lk5FVCB2My41LjEw/7R3GwAAA6BJREFUeN7tW01oE1EQnk0qih4sevCiF/Wg4kEPgqeCHsSDhyIeVIoHDx48KIKHIh48ePAgePBiPRQ8eBA8COJBD4L4B8WD4kHxov7cm2yT3WzeZjdps7t58CG72bebzPfevPlmdg3DMFwul8vlcv13qampWSKi82S2kxgiVpLZZ2T2G5lDZHaRmU9mDxEViOgqEZ1Np9N3V1ZWLlutFh1vNJvN5+12+4bf77+s/p5zIuKCiAgiGhcRLkRkCRkH+rYikYjlOE7G87w/wWBwLxKJbIeDk8mky3q31xG/37/FwR1Fq9V6Q0SX1N9tIuKNiKgiIo/bbrfb+zwez44qchRzHMcioh2Xy6Xb7fYDIsrqu5WIeBDRoohwJ2VlZaWRSCS2VNEdzZTL5ctEdF1V5Yj4QUQ8EXG73e51j8ejiojOa/V6/ZaI7tDfvUS0SUQJEXFeRNRUVVW5mZmZe/R7kZ2cTCZ1vV4/yXfO/4eQeC4iWqpQKJRkZWWl9XrdISJDRMKIyKqqqjIjI2Pj4uLiGef8lMvlYg4eE9E1VVVP9ff/c5z4n04Gg0F3PB7/TkR5dF6k4/F4v9frdc3NzbV1XW/R/2lEVBER91RVVV1TU8OHr1gsVpP198lkct5xnM/q73kiOq+O37G6uvrVdV2u1+vv6XkRkS8UCr3xeDybyuVydWVlZZlOp9v0/y/O+X41538j1b+/qKurW1bVjYg4b0xMTKyqPZ8gIs7pYx7e1/V6/bKa1xEi6k9OTnZVVVW/IqI7RLRJRHkikVhyHGdBVff9+/cf6LpOU1NTD/T3NBFxRkR00Xm1Xq/fV0U+JqK/RETJ7OzsM7vdzhw81nW9RURDRHSpWCze13Wd6/X6bVV0u6qq6mUkEtnSdV3S10z9vUtE3InpdPrB8vLybSLiTk5OTg1tQ7eP8+jo6Jqqwscikcj2wsLCGuf8FBFxJycnJ7sNDQ1rV1dXWzQ4JCKHqnK6XC5bVfS06rp+k6ry8ZWVFR4eHl4jIs4jIyN9hmF81HX9B1Xl9MTERD8RcfN4PDupVOq+67pP1H1bJpPpvb6+7hPRfVVVV0ZGRtiVlRWWSCReZ7PZX36//6Cvr48PDQ09y2azVzwez7Kqqk8556fdbvdnItpVVdUaGRmZoKqaoP6sUjKZ3B8YGGBd122qyu3j/Ojo6F1N034MDAyw6elpW1VVLhQKzH1HRkZ6m4qKiicikajlOI7ler3e9y6X643L5dqi/+NyuZ6rqvpOVdV/Kysr51wu17fW3w8AAAD//wMAe7/lQy8mR0AAAAAElFTkSuQmCC"
local function Zk(e,...)
    if crypt and crypt.base64decode then
        return crypt.base64decode (e)
    end
    if base64_decode then
        return base64_decode(e)
    end
    if syn and(syn.crypt and(syn.crypt.base64 and syn.crypt.base64 .decode ))then
        return syn.crypt.base64 .decode (e)
    end
    local r= "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"
    local y={}
    for e= 1 ,#r, 1 do
        y[r:sub(e,e)]=e- 1
    end
    e=(e:gsub( "[^" ..(r.. "=]" ), "" )):gsub( "=" , "" )
    local u={}
    for r= 1 ,#e, 4 do
        local j=y[e:sub(r,r)]or 0
        local k=y[e:sub(r+ 1 ,r+ 1 )]or 0
        local a=y[e:sub(r+ 2 ,r+ 2 )]
        local o=y[e:sub(r+ 3 ,r+ 3 )]table.insert (u,string.char (bit32.bor (bit32.lshift (j, 2 ),bit32.rshift (k, 4 ))))
        if a then
            table.insert (u,string.char (bit32.bor (bit32.lshift (bit32.band (k, 15 ), 4 ),bit32.rshift (a, 2 ))))
            if o then
                table.insert (u,string.char (bit32.bor (bit32.lshift (bit32.band (a, 3 ), 6 ),o)))
            end
        end
    end
    return table.concat (u)
end
local zk= "Ken_Hub_Icon.png"
local dk= "rbxassetid://10734950309" pcall(function(...)
    if writefile and((getcustomasset or getsynasset))then
        local e=getcustomasset or getsynasset
        if not((isfile and isfile(zk)))then
            writefile(zk,Zk(Sk))
        end
        dk=e(zk)
    end
end
)
local Xk=currentLang or "EN"
local Gk={[ "EN" ]={[ "StatusTagReady" ]= "Status: Ready" ,[ "Tabs" ]={[ "Farm" ]= "Auto Farm" ;
[ "EggSelect" ]= "Egg Selection" ;
[ "Character" ]= "Character" ,[ "Settings" ]= "Settings" },[ "EggSelect" ]={[ "SecZones" ]= "Target Zones" ;
[ "SecZonesDesc" ]= "Select zones to steal regular eggs from (Secret+ bypasses this filter)" ,[ "DropZonesTitle" ]= "Selected Zones" ,[ "DropZonesDesc" ]= "Click to choose which zones to farm eggs from" ;
[ "SecRarities" ]= "Target Rarities" ;
[ "SecRaritiesDesc" ]= "Select egg rarities to target" ;
[ "DropRaritiesTitle" ]= "Selected Rarities" ;
[ "DropRaritiesDesc" ]= "Click to choose which rarities to collect" ,[ "AlwaysSecretPlus" ]= "Always Steal Secret+ Eggs" ;
[ "AlwaysSecretPlusDesc" ]= "Collect Secret, Eternal, Divine eggs from any zone automatically" },[ "Farm" ]={[ "SecModes" ]= "Auto Steal Modes" ,[ "TweenTitle" ]= "Auto Steal (Tween)" ,[ "TweenDesc" ]= "Smoothly fly to steal eggs continuously along the high-speed highway corridor" ;
[ "TeleportTitle" ]= "Auto Steal (Teleport)" ;
[ "TeleportDesc" ]= "Instantly warp to steal eggs in a rapid continuous loop" ,[ "SingleTitle" ]= "Single Steal (Teleport)" ,[ "SingleDesc" ]= "Teleport to steal 1 target egg and return to base" ;
[ "SecPlace" ]= "Place & Hatch" ;
[ "PlaceTitle" ]= "Place Eggs" ,[ "PlaceDesc" ]= "Fly home, place stashed eggs into open incubator stands and request hatch" ,[ "AutoPlaceTitle" ]= "Auto Place (Every 5)" ;
[ "AutoPlaceDesc" ]= "Return home every 5 steals to deposit eggs" ;
[ "HatchTitle" ]= "Auto Hatch" ,[ "HatchDesc" ]= "Continuously hatch ready eggs automatically from anywhere" ,[ "ReturnTitle" ]= "Auto Return" ,[ "ReturnDesc" ]= "Automatically fly back to safe area after stealing" ;
[ "AutoTreadmillTitle" ]= "Auto Treadmill" ,[ "AutoTreadmillDesc" ]= "Run on base treadmill when no target eggs are spawned" ,[ "UpgradeTreadmillTitle" ]= "Auto Upgrade Treadmill" ;
[ "UpgradeTreadmillDesc" ]= "Automatically upgrade base treadmill tier when you have enough cash" ;
[ "BuyTrailsTitle" ]= "Auto Buy & Equip Trails" ,[ "BuyTrailsDesc" ]= "Automatically purchase and equip the best speed trail available" ,[ "HideNotEnoughMoneyTitle" ]= "Hide 'Not Enough Money' UI" ,[ "HideNotEnoughMoneyDesc" ]= "Automatically suppress and hide the red 'Not enough money' game alert" };
[ "Character" ]={[ "SecSafety" ]= "Character & Safety" ,[ "GodmodeTitle" ]= "Godmode" ,[ "GodmodeDesc" ]= "Full immunity against map obstacles, traps, and hazards" ,[ "UnstickTitle" ]= "Get Unstuck" ;
[ "UnstickDesc" ]= "Instantly break free from treadmills, seats, or map geometry" ,[ "SecFlight" ]= "Flight Settings" ;
[ "SpeedTitle" ]= "Flight Speed" ,[ "SpeedDesc" ]= "Adjust cruise flight speed (studs/second)" };
[ "Settings" ]={[ "SecDashboard" ]= "Live Dashboard" ;
[ "DashTitle" ]= "Live Dashboard" ;
[ "DashDesc" ]= "Status: %s\nFarm Mode: %s\nCarried Eggs: %d\nFlight Speed: %d studs/s" ;
[ "SecBlacklist" ]= "Zone Preferences" ,[ "BlacklistToggleTitle" ]= "Target Zone: %s" ;
[ "BlacklistToggleDesc" ]= "Enable egg stealing in %s (Secret+ always collected)" ;
[ "SecUI" ]= "UI Customization" ,[ "TranspTitle" ]= "Window Transparency" ;
[ "TranspDesc" ]= "Adjust background transparency of the UI window (0% - 90%)" ;
[ "ThemeTitle" ]= "Select Theme" ;
[ "SecPerformance" ]= "Performance & Graphics" ,[ "PerformanceTitle" ]= "Ultra Potato Mode (Maximum FPS Boost)" ,[ "PerformanceDesc" ]= "Disables textures, meshes, lights, shadows, effects and particles for maximum FPS" ;
[ "Disable3DTitle" ]= "Disable 3D Rendering (GPU Saver 95%)" ,[ "Disable3DDesc" ]= "Freezes 3D viewport rendering to drop GPU usage to ~1%. Perfect for overnight farming!" ,[ "LangTitle" ]= "Language" ,[ "BtnTranslate" ]= "Switch to Thai" ;
[ "DescTranslate" ]= "Switch interface language to Thai" ,[ "SecSystem" ]= "System Controls" ;
[ "AntiAFKTitle" ]= "Anti-AFK (Double-Esc 10m / Mobile)" ,[ "AntiAFKDesc" ]= "Double-Esc menu pulse every 10m + Mobile touch + PC jitter resets idle timer safely without Idled" ,[ "ResetTitle" ]= "Reset Character State" ,[ "ResetDesc" ]= "Clear internal states and unlock character movement" ;
[ "RejoinTitle" ]= "Rejoin Server" ,[ "RejoinDesc" ]= "Reconnect to the same server automatically" ;
[ "UnloadTitle" ]= "Unload Script" ,[ "UnloadDesc" ]= "Completely terminate all loops and close the interface" };
[ "Notifications" ]={[ "PlaceStarted" ]= "Flying back to base to place eggs..." ;
[ "PlaceDone" ]= "Eggs placed on stands and hatch requested!" ,[ "AutoPlaceStarted" ]= "Auto Place (Every 5) enabled" ;
[ "AutoPlaceStopped" ]= "Auto Place (Every 5) disabled" ,[ "NoEggFound" ]= "No eligible eggs found matching your filter" ,[ "UnstickDone" ]= "Unstick request sent successfully!" ;
[ "TweenStarted" ]= "Auto Steal (Tween) activated" ,[ "TweenStopped" ]= "Auto Steal (Tween) deactivated" ;
[ "TeleportStarted" ]= "Auto Steal (Teleport) activated" ;
[ "TeleportStopped" ]= "Auto Steal (Teleport) deactivated" ;
[ "HatchStarted" ]= "Auto Hatch enabled" ;
[ "HatchStopped" ]= "Auto Hatch disabled" ;
[ "ReturnStarted" ]= "Auto Return enabled" ,[ "ReturnStopped" ]= "Auto Return disabled" ;
[ "AutoTreadmillStarted" ]= "Auto Treadmill enabled (Runs when idle)" ,[ "AutoTreadmillStopped" ]= "Auto Treadmill disabled" ,[ "UpgradeTreadmillStarted" ]= "Auto Upgrade Treadmill enabled" ;
[ "UpgradeTreadmillStopped" ]= "Auto Upgrade Treadmill disabled" ;
[ "BuyTrailsStarted" ]= "Auto Buy Trails enabled" ;
[ "BuyTrailsStopped" ]= "Auto Buy Trails disabled" ;
[ "HideNotEnoughMoneyStarted" ]= "Hide 'Not Enough Money' alert enabled" ,[ "HideNotEnoughMoneyStopped" ]= "Hide 'Not Enough Money' alert disabled" ,[ "GodmodeStarted" ]= "Godmode enabled" ,[ "GodmodeStopped" ]= "Godmode disabled" ,[ "PerformanceStarted" ]= "Ultra Potato Mode enabled (Textures & effects removed)" ;
[ "PerformanceStopped" ]= "Ultra Potato Mode disabled" ;
[ "Disable3DStarted" ]= "3D Rendering disabled (GPU Saver Active)" ,[ "Disable3DStopped" ]= "3D Rendering restored" ,[ "AntiAFKStarted" ]= "Anti-AFK enabled (Double-Esc 10m & Mobile support)" ,[ "AntiAFKStopped" ]= "Anti-AFK disabled" ,[ "LangSwitched" ]= "Language switched to English successfully!" }},[ "TH" ]={[ "StatusTagReady" ]= "สถานะ: พร้อมทำงาน" ,[ "Tabs" ]={[ "Farm" ]= "ระบบฟาร์ม" ;
[ "EggSelect" ]= "เลือกประเภทไข่" ,[ "Character" ]= "ตัวละคร" ;
[ "Settings" ]= "ตั้งค่า" },[ "EggSelect" ]={[ "SecZones" ]= "เลือกโซนเป้าหมาย" ,[ "SecZonesDesc" ]= "เลือกโซนที่ต้องการไปขโมยไข่ (ไข่ระดับ Secret ขึ้นไปจะไม่สนโซน)" ,[ "DropZonesTitle" ]= "โซนเป้าหมายที่เลือก" ,[ "DropZonesDesc" ]= "คลิกเพื่อเลือกโซนที่ต้องการขโมยไข่" ,[ "SecRarities" ]= "เลือกระดับความหายาก" ,[ "SecRaritiesDesc" ]= "เลือกระดับความหายากของไข่ที่ต้องการขโมย" ,[ "DropRaritiesTitle" ]= "ระดับความหายากที่เลือก" ;
[ "DropRaritiesDesc" ]= "คลิกเพื่อเลือกระดับความหายากที่ต้องการขโมย" ;
[ "AlwaysSecretPlus" ]= "เก็บไข่ Secret+ ทุกโซนเสมอ" ;
[ "AlwaysSecretPlusDesc" ]= "ขโมยไข่ระดับ Secret, Eternal, Divine ทันทีไม่ว่าจะเกิดที่โซนใด" };
[ "Farm" ]={[ "SecModes" ]= "โหมดขโมยไข่อัตโนมัติ" ,[ "TweenTitle" ]= "ขโมยไข่อัตโนมัติ (บินเร็ว)" ,[ "TweenDesc" ]= "บินไปขโมยไข่และเก็บใส่กระเป๋าอย่างต่อเนื่องตามทางด่วนความเร็วสูง" ,[ "TeleportTitle" ]= "ขโมยไข่อัตโนมัติ (วาร์ป)" ;
[ "TeleportDesc" ]= "วาร์ปไปขโมยไข่อย่างรวดเร็วและต่อเนื่อง" ,[ "SingleTitle" ]= "ขโมยไข่ใบเดียว" ,[ "SingleDesc" ]= "วาร์ปไปขโมยไข่เป้าหมาย 1 ใบแล้วกลับมาที่ฐานทันที" ;
[ "SecPlace" ]= "นำส่งและฟักไข่" ;
[ "PlaceTitle" ]= "วางไข่ในรัง" ;
[ "PlaceDesc" ]= "บินกลับบ้านและนำไข่ในตัวไปวางบนแท่นฟักที่ว่างแล้วเริ่มฟักทันที" ,[ "AutoPlaceTitle" ]= "วางไข่อัตโนมัติ (ทุก 5 ฟอง)" ,[ "AutoPlaceDesc" ]= "กลับบ้านทุกครั้งที่ขโมยครบ 5 ฟองเพื่อนำไข่ไปวาง" ;
[ "HatchTitle" ]= "ฟักไข่อัตโนมัติ" ,[ "HatchDesc" ]= "สั่งฟักไข่ที่พร้อมฟักอย่างต่อเนื่องจากทุกที่" ;
[ "ReturnTitle" ]= "บินกลับพื้นที่ปลอดภัย" ,[ "ReturnDesc" ]= "บินกลับเข้าพื้นที่ปลอดภัยอัตโนมัติหลังขโมยไข่เสร็จ" ;
[ "AutoTreadmillTitle" ]= "วิ่งลู่วิ่งอัตโนมัติ" ;
[ "AutoTreadmillDesc" ]= "ไปวิ่งบนลู่วิ่งที่บ้านอัตโนมัติเมื่อไม่มีไข่ตามที่เลือกเกิด" ;
[ "UpgradeTreadmillTitle" ]= "อัปเกรดลู่วิ่งอัตโนมัติ" ;
[ "UpgradeTreadmillDesc" ]= "อัปเกรดระดับลู่วิ่งที่บ้านอัตโนมัติทันทีที่มีเงินพอ" ;
[ "BuyTrailsTitle" ]= "ซื้อและใส่ Trail อัตโนมัติ" ,[ "BuyTrailsDesc" ]= "ซื้อเส้นทางเพิ่มความเร็วและสวมใส่อันที่ดีที่สุดอัตโนมัติเมื่อเงินพอ" ;
[ "HideNotEnoughMoneyTitle" ]= "ซ่อนแจ้งเตือนเงินไม่พอ" ;
[ "HideNotEnoughMoneyDesc" ]= "บล็อกและซ่อนข้อความสีแดง 'Not enough money' จากตัวเกมอัตโนมัติ" };
[ "Character" ]={[ "SecSafety" ]= "ความปลอดภัยและตัวละคร" ;
[ "GodmodeTitle" ]= "โหมดอมตะ" ;
[ "GodmodeDesc" ]= "ป้องกันดาเมจจากสิ่งกีดขวางและกับดัก 100%" ;
[ "UnstickTitle" ]= "แก้ตัวติด / ลงจากลู่วิ่ง" ,[ "UnstickDesc" ]= "หลุดออกจากสิ่งกีดขวางหรืออุปกรณ์ทันที" ,[ "SecFlight" ]= "การตั้งค่าการบิน" ,[ "SpeedTitle" ]= "ความเร็วการบิน" ;
[ "SpeedDesc" ]= "ปรับความเร็วในการบิน (Studs/วินาที)" };
[ "Settings" ]={[ "SecDashboard" ]= "แดชบอร์ดสถานะสด" ;
[ "DashTitle" ]= "แดชบอร์ดสถานะสด" ;
[ "DashDesc" ]= "สถานะ: %s\nโหมดฟาร์ม: %s\nจำนวนไข่ในตัว: %d ฟอง\nความเร็วการบิน: %d Studs/วิ" ;
[ "SecBlacklist" ]= "ตัวเลือกโซนที่ต้องการ" ;
[ "BlacklistToggleTitle" ]= "ขโมยในโซน: %s" ,[ "BlacklistToggleDesc" ]= "เปิด/ปิด การขโมยไข่ทั่วไปในโซน %s (ระดับ Secret+ จะเก็บเสมอ)" ;
[ "SecUI" ]= "ปรับแต่งหน้าต่าง" ;
[ "TranspTitle" ]= "ความโปร่งใสของหน้าต่าง" ,[ "TranspDesc" ]= "ปรับความโปร่งแสงของพื้นหลังหน้าต่าง (0% - 90%)" ;
[ "ThemeTitle" ]= "เลือกธีมหน้าต่าง" ;
[ "SecPerformance" ]= "ประสิทธิภาพและกราฟิก" ;
[ "PerformanceTitle" ]= "โหมดภาพกากขั้นสุด (Ultra Potato Mode)" ;
[ "PerformanceDesc" ]= "ลดกราฟิก ลบ Texture ของโมเดล ปิดเงา ปิดแสงไฟ และปิดเอฟเฟกต์ทั้งหมดเพื่อความลื่นขั้นสุด" ;
[ "Disable3DTitle" ]= "ปิดเรนเดอร์ 3D / จอดำ (ประหยัด GPU 95%)" ,[ "Disable3DDesc" ]= "หยุดประมวลผลภาพ 3D ลดภาระการ์ดจอเหลือ 1% เหมาะสำหรับเปิดฟาร์มทิ้งไว้ข้ามคืน (หน้าต่าง UI ยังทำงานปกติ)" ,[ "LangTitle" ]= "ภาษา" ;
[ "BtnTranslate" ]= "เปลี่ยนเป็นภาษาอังกฤษ" ;
[ "DescTranslate" ]= "เปลี่ยนภาษาของหน้าต่างทั้งหมดเป็นภาษาอังกฤษ" ,[ "SecSystem" ]= "จัดการระบบ" ;
[ "AntiAFKTitle" ]= "ป้องกัน AFK เตะ (กด Esc 2 ที / รองรับมือถือ)" ;
[ "AntiAFKDesc" ]= "กด Esc เปิด-ปิดเมนูอัตโนมัติทุก 10 นาที + สัญญาณ Touch มือถือ รีเซ็ตตัวนับ 20 นาที ปลอดภัยไม่แตะเกม" ;
[ "ResetTitle" ]= "รีเซ็ตสถานะตัวละคร" ;
[ "ResetDesc" ]= "ล้างสถานะภายในทั้งหมดและปลดล็อกการเคลื่อนที่ทันที" ;
[ "RejoinTitle" ]= "เข้าเซิร์ฟเวอร์ใหม่" ,[ "RejoinDesc" ]= "เชื่อมต่อกลับเข้าเซิร์ฟเวอร์เดิมใหม่อัตโนมัติ" ,[ "UnloadTitle" ]= "ปิดสคริปต์สมบูรณ์" ;
[ "UnloadDesc" ]= "หยุดการทำงานของลูปทั้งหมดและปิดหน้าต่างอย่างปลอดภัย" };
[ "Notifications" ]={[ "PlaceStarted" ]= "กำลังบินกลับบ้านเพื่อนำไข่ไปวาง..." ;
[ "PlaceDone" ]= "วางไข่บนแท่นฟักและเริ่มฟักเรียบร้อย!" ;
[ "AutoPlaceStarted" ]= "เปิดใช้งาน วางไข่อัตโนมัติ (ทุก 5 ฟอง)" ,[ "AutoPlaceStopped" ]= "ปิดใช้งาน วางไข่อัตโนมัติ" ,[ "NoEggFound" ]= "ไม่พบไข่ที่ตรงตามเงื่อนไขในขณะนี้" ;
[ "UnstickDone" ]= "ส่งคำสั่งแก้ตัวติดเรียบร้อย!" ,[ "TweenStarted" ]= "เปิดใช้งาน ขโมยไข่อัตโนมัติ (บินเร็ว)" ,[ "TweenStopped" ]= "ปิดใช้งาน ขโมยไข่อัตโนมัติ (บินเร็ว)" ;
[ "TeleportStarted" ]= "เปิดใช้งาน ขโมยไข่อัตโนมัติ (วาร์ป)" ,[ "TeleportStopped" ]= "ปิดใช้งาน ขโมยไข่อัตโนมัติ (วาร์ป)" ,[ "HatchStarted" ]= "เปิดใช้งาน ฟักไข่อัตโนมัติ" ;
[ "HatchStopped" ]= "ปิดใช้งาน ฟักไข่อัตโนมัติ" ,[ "ReturnStarted" ]= "เปิดใช้งาน บินกลับพื้นที่ปลอดภัย" ,[ "ReturnStopped" ]= "ปิดใช้งาน บินกลับพื้นที่ปลอดภัย" ;
[ "AutoTreadmillStarted" ]= "เปิดใช้งาน วิ่งลู่วิ่งอัตโนมัติ (ทำงานเมื่อว่าง)" ;
[ "AutoTreadmillStopped" ]= "ปิดใช้งาน วิ่งลู่วิ่งอัตโนมัติ" ,[ "UpgradeTreadmillStarted" ]= "เปิดใช้งาน อัปเกรดลู่วิ่งอัตโนมัติ" ,[ "UpgradeTreadmillStopped" ]= "ปิดใช้งาน อัปเกรดลู่วิ่งอัตโนมัติ" ;
[ "BuyTrailsStarted" ]= "เปิดใช้งาน ซื้อและใส่ Trail อัตโนมัติ" ;
[ "BuyTrailsStopped" ]= "ปิดใช้งาน ซื้อและใส่ Trail อัตโนมัติ" ;
[ "HideNotEnoughMoneyStarted" ]= "เปิดใช้งาน ซ่อนแจ้งเตือนเงินไม่พอ" ,[ "HideNotEnoughMoneyStopped" ]= "ปิดใช้งาน ซ่อนแจ้งเตือนเงินไม่พอ" ,[ "GodmodeStarted" ]= "เปิดใช้งาน โหมดอมตะ" ;
[ "GodmodeStopped" ]= "ปิดใช้งาน โหมดอมตะ" ,[ "PerformanceStarted" ]= "เปิดใช้งาน โหมดภาพกากขั้นสุด (ลบ Texture และแสงเงา)" ;
[ "PerformanceStopped" ]= "ปิดใช้งาน โหมดภาพกากขั้นสุด" ,[ "Disable3DStarted" ]= "เปิดใช้งาน โหมดประหยัด GPU (ปิดเรนเดอร์ 3D)" ;
[ "Disable3DStopped" ]= "คืนค่าการแสดงผล 3D ตามปกติแล้ว" ;
[ "AntiAFKStarted" ]= "เปิดใช้งาน ป้องกัน AFK (กด Esc 2 ที ทุก 10 นาที + รองรับมือถือ)" ;
[ "AntiAFKStopped" ]= "ปิดใช้งาน ป้องกัน AFK" ;
[ "LangSwitched" ]= "เปลี่ยนภาษาเป็นภาษาไทยเรียบร้อยแล้ว!" }}}
local Fk={}
local hk,Ok,Yk,Tk
local xk={ "Farm" ;
"EggSelect" ;
"Character" , "Settings" }
local function Wk(e,...)
    local r=(e== "TH" )
    if h.delivering then
        return r and "กำลังวางไข่" or "Placing Egg"
    elseif h.securingEgg or h.holdingEggForGuard then
        return r and "กำลังหยิบไข่" or "Securing Egg"
    elseif h.teleporting then
        return r and "กำลังวาร์ป" or "Teleporting"
    elseif h.isReturning then
        return r and "กำลังบินกลับ" or "Returning"
    elseif h.glidingToTarget then
        return r and "กำลังบินไปขโมย" or "Stealing"
    elseif h.onTreadmill or(L4 and L4())then
        return r and "อยู่บนลู่วิ่ง" or "On Treadmill"
    elseif Y4== "TWEEN" and not h.isReturning then
        return r and "กำลังหาไข่" or "Searching"
    elseif Y4== "WARP" and not h.isReturning then
        return r and "กำลังหาไข่" or "Searching"
    else
        return r and "พร้อมทำงาน" or "Ready"
    end
end
local function mk(e,...) pcall(function(...)
        if e:IsA( "TextLabel" )or e:IsA( "TextButton" )or e:IsA( "TextBox" )then
            e.AutoLocalize = false
        end
        for e,y in ipairs(e:GetDescendants())do
            if y:IsA( "TextLabel" )or y:IsA( "TextButton" )or y:IsA( "TextBox" )then
                y.AutoLocalize = false
            end
        end
    end
    )
end
local function eM(e,r,y,...)
    if not e then
        return
    end
    pcall(function(...)
        if r and e.SetTitle then
            e:SetTitle(r)
        end
        if y and e.SetDesc then
            e:SetDesc(y)
        end
    end
    )pcall(function(...)
        if e.UIElements then
            if r and(e.UIElements.Title and e.UIElements.Title :IsA( "TextLabel" ))then
                e.UIElements.Title .AutoLocalize = false e.UIElements.Title .Text =r
            end
            if y and(e.UIElements.Desc and e.UIElements.Desc :IsA( "TextLabel" ))then
                e.UIElements.Desc .AutoLocalize = false e.UIElements.Desc .Text =y
            end
        end
    end
    )
end
local function rM(e,r,y,...) pcall(function(...)
        if not e then
            return
        end
        if e.UIElements and(e.UIElements.Title and e.UIElements.Title :IsA( "TextLabel" ))then
            e.UIElements.Title .TextColor3 =r
        end
        if e.UIElements and e.UIElements.ButtonIcon then
            local y=e.UIElements.ButtonIcon :FindFirstChildOfClass( "ImageLabel" )or e.UIElements.ButtonIcon
            if y and y:IsA( "ImageLabel" )then
                y.ImageColor3 =r
            end
        end
        local u=nil
        if e.ButtonFrame and(e.ButtonFrame.UIElements and e.ButtonFrame.UIElements .Main )then
            u=e.ButtonFrame.UIElements .Main
        elseif e.ToggleFrame and(e.ToggleFrame.UIElements and e.ToggleFrame.UIElements .Main )then
            u=e.ToggleFrame.UIElements .Main
        elseif e.ElementFrame then
            u=e.ElementFrame
        elseif e.UIElements and e.UIElements.Main then
            u=e.UIElements.Main
        end
        if u and u:IsA( "GuiObject" )then
            local e=u:FindFirstChild( "AccentCorner" )or u:FindFirstChildOfClass( "UICorner" )
            if e then
                e:Destroy()
            end
            local j=u:FindFirstChild( "DiceAccentStroke" )or u:FindFirstChildOfClass( "UIStroke" )
            if j then
                j:Destroy()
            end
            local k=u:FindFirstChild( "AccentSquircleOutline" )
            if k then
                k:Destroy()
            end
            for e,r in ipairs(u:GetDescendants())do
                if r:IsA( "ImageLabel" )and((string.find (tostring(r.Image ), "117817408534198" )or string.find (r.Name :lower(), "outline" )))then
                    r.Visible = false r.ImageTransparency = 1
                end
            end
            local a=y
            if not a then
                local e,y,u=r:ToHSV()a=Color3.fromHSV (e,math.clamp (y* 0.4 , 0.18 , 0.45 ), 0.18 )
            end
            u.ThemeTag =nil u.ImageColor3 =a u.ImageTransparency = 0.08
        end
    end
    )
end
local function yM(...) rM(Fk.togTween ,Color3.fromRGB ( 0 , 195 , 255 ),Color3.fromRGB ( 24 , 40 , 46 ))rM(Fk.togTeleport ,Color3.fromRGB ( 168 , 85 , 247 ),Color3.fromRGB ( 36 , 24 , 46 ))rM(Fk.btnPlaceEgg ,Color3.fromRGB ( 16 , 215 , 130 ),Color3.fromRGB ( 24 , 45 , 36 ))rM(Fk.togAutoPlaceEvery5 ,Color3.fromRGB ( 14 , 165 , 233 ),Color3.fromRGB ( 24 , 38 , 46 ))rM(Fk.togGodmode ,Color3.fromRGB ( 244 , 63 , 94 ),Color3.fromRGB ( 46 , 24 , 28 ))rM(Fk.btnUnstick ,Color3.fromRGB ( 249 , 115 , 22 ),Color3.fromRGB ( 46 , 32 , 24 ))rM(Fk.btnReset ,Color3.fromRGB ( 99 , 102 , 241 ),Color3.fromRGB ( 25 , 26 , 46 ))rM(Fk.btnLangSettings ,Color3.fromRGB ( 245 , 180 , 30 ),Color3.fromRGB ( 46 , 38 , 24 ))
end
local function uM(e,...)
    local r=e or Xk or "EN"
    local y=Gk[r]or Gk.EN
    local u={hk,Ok;
    Yk;
    Tk}
    local w={ "Farm" ;
    "EggSelect" , "Character" ;
    "Settings" }
    for e,r in ipairs(u)do
        local u=w[e]
        local k=y.Tabs [u]or u
        if r then
            r.Title =k pcall(function(...)
                if r.SetTitle then
                    r:SetTitle(k)
                end
            end
            )pcall(function(...)
                if r.UIElements and r.UIElements.Main then
                    for r,y in ipairs(r.UIElements.Main :GetDescendants())do
                        if y:IsA( "TextLabel" )then
                            y.AutoLocalize = false y.Text =k
                        end
                    end
                end
                if r.UIElements and r.UIElements.TabItem then
                    for r,y in ipairs(r.UIElements.TabItem :GetDescendants())do
                        if y:IsA( "TextLabel" )then
                            y.AutoLocalize = false y.Text =k
                        end
                    end
                end
            end
            )
        end
    end
    pcall(function(...)
        if Window and(Window.TabModule and Window.TabModule.Tabs )then
            for r= 1 ,#xk, 1 do
                local u=Window.TabModule.Tabs [r]
                local w=xk[r]
                local j=y.Tabs [w]or w
                if u and j then
                    u.Title =j
                    if u.UIElements and u.UIElements.Main then
                        for r,y in ipairs(u.UIElements.Main :GetDescendants())do
                            if y:IsA( "TextLabel" )then
                                y.AutoLocalize = false y.Text =j
                            end
                        end
                    end
                    if u.UIElements and u.UIElements.TabItem then
                        for r,y in ipairs(u.UIElements.TabItem :GetDescendants())do
                            if y:IsA( "TextLabel" )then
                                y.AutoLocalize = false y.Text =j
                            end
                        end
                    end
                end
            end
        end
    end
    )
end
local function wM(e,...)
    local r=Gk[e]or Gk.EN uM(e)eM(Fk.secModes ,r.Farm.SecModes )eM(Fk.togTween ,r.Farm.TweenTitle ,r.Farm.TweenDesc )eM(Fk.togTeleport ,r.Farm.TeleportTitle ,r.Farm.TeleportDesc )eM(Fk.secPlace ,r.Farm.SecPlace )eM(Fk.btnPlaceEgg ,r.Farm.PlaceTitle ,r.Farm.PlaceDesc )eM(Fk.togAutoPlaceEvery5 ,r.Farm.AutoPlaceTitle ,r.Farm.AutoPlaceDesc )eM(Fk.togAutoHatch ,r.Farm.HatchTitle ,r.Farm.HatchDesc )eM(Fk.togAutoReturn ,r.Farm.ReturnTitle ,r.Farm.ReturnDesc )eM(Fk.togAutoTreadmill ,r.Farm.AutoTreadmillTitle ,r.Farm.AutoTreadmillDesc )eM(Fk.togAutoUpgradeTreadmill ,r.Farm.UpgradeTreadmillTitle ,r.Farm.UpgradeTreadmillDesc )eM(Fk.togAutoBuyTrails ,r.Farm.BuyTrailsTitle ,r.Farm.BuyTrailsDesc )
    if r.EggSelect then
        eM(Fk.secEggZones ,r.EggSelect.SecZones ,r.EggSelect.SecZonesDesc )eM(Fk.dropTargetZones ,r.EggSelect.DropZonesTitle ,r.EggSelect.DropZonesDesc )eM(Fk.secEggRarity ,r.EggSelect.SecRarities ,r.EggSelect.SecRaritiesDesc )eM(Fk.secEggRarities ,r.EggSelect.SecRarities ,r.EggSelect.SecRaritiesDesc )eM(Fk.dropTargetRarities ,r.EggSelect.DropRaritiesTitle ,r.EggSelect.DropRaritiesDesc )eM(Fk.togAlwaysSecret ,r.EggSelect.AlwaysSecretPlus ,r.EggSelect.AlwaysSecretPlusDesc )
    end
    eM(Fk.secSafety ,r.Character.SecSafety )eM(Fk.togGodmode ,r.Character.GodmodeTitle ,r.Character.GodmodeDesc )eM(Fk.btnUnstick ,r.Character.UnstickTitle ,r.Character.UnstickDesc )eM(Fk.secFlight ,r.Character.SecFlight )eM(Fk.sliderSpeed ,r.Character.SpeedTitle ,r.Character.SpeedDesc )eM(Fk.secDashboard ,r.Settings.SecDashboard )eM(Fk.paraLiveDash ,r.Settings.DashTitle )eM(Fk.secBlacklist ,r.Settings.SecBlacklist )eM(Fk.secUI ,r.Settings.SecUI )eM(Fk.dropLang ,r.Settings.LangTitle )eM(Fk.sliderTransp ,r.Settings.TranspTitle ,r.Settings.TranspDesc )eM(Fk.dropTheme ,r.Settings.ThemeTitle )eM(Fk.secPerformance ,r.Settings.SecPerformance )eM(Fk.togPerformance ,r.Settings.PerformanceTitle ,r.Settings.PerformanceDesc )eM(Fk.togDisable3D ,r.Settings.Disable3DTitle ,r.Settings.Disable3DDesc )eM(Fk.secSystem ,r.Settings.SecSystem )eM(Fk.togAntiAFK ,r.Settings.AntiAFKTitle ,r.Settings.AntiAFKDesc )eM(Fk.btnReset ,r.Settings.ResetTitle ,r.Settings.ResetDesc )eM(Fk.btnRejoin ,r.Settings.RejoinTitle ,r.Settings.RejoinDesc )eM(Fk.btnUnload ,r.Settings.UnloadTitle ,r.Settings.UnloadDesc )yM()
end
local function jM(...)
    local e=Instance.new ( "ScreenGui" )e.Name = "Dice_LOADER_SCREEN" e.ResetOnSpawn = false e.DisplayOrder = 9999999 e.ZIndexBehavior =Enum.ZIndexBehavior.Sibling e.AutoLocalize = false pcall(function(...)
        if syn and syn.protect_gui then
            syn.protect_gui (e)e.Parent =game:GetService( "CoreGui" )
        else
            e.Parent =o:FindFirstChild( "PlayerGui" )or game:GetService( "CoreGui" )
        end
    end
    )
    if not e.Parent then
        e.Parent =game:GetService( "CoreGui" )
    end
    local r=Instance.new ( "Frame" )r.Name = "Card" r.Size =UDim2.fromOffset ( 336 , 140 )r.Position =UDim2.new ( 0.5 , -168 , 0.5 , -70 )r.BackgroundColor3 =Color3.fromRGB ( 16 , 16 , 22 )r.BorderSizePixel = 0 r.Parent =e;
    (Instance.new ( "UICorner" ,r)).CornerRadius =UDim.new ( 0 , 14 )
    local y=Instance.new ( "UIStroke" ,r)y.Color =Color3.fromRGB ( 0 , 185 , 255 )y.Thickness = 1.4 y.ApplyStrokeMode =Enum.ApplyStrokeMode.Border
    local w=Instance.new ( "TextLabel" )w.Size =UDim2.new ( 1 , -28 , 0 , 24 )w.Position =UDim2.new ( 0 , 14 , 0 , 14 )w.BackgroundTransparency = 1 w.Text = "Ken Hub" w.TextColor3 =Color3.fromRGB ( 245 , 248 , 255 )w.TextSize = 18 w.Font =Enum.Font.GothamBold w.TextXAlignment =Enum.TextXAlignment.Left w.AutoLocalize = false w.Parent =r
    local j=Instance.new ( "TextLabel" )j.Size =UDim2.new ( 1 , -28 , 0 , 16 )j.Position =UDim2.new ( 0 , 14 , 0 , 38 )j.BackgroundTransparency = 1 j.Text = "Steal an Egg Suite v42.64" j.TextColor3 =Color3.fromRGB ( 140 , 150 , 175 )j.TextSize = 12 j.Font =Enum.Font.Gotham j.TextXAlignment =Enum.TextXAlignment.Left j.AutoLocalize = false j.Parent =r
    local k=Instance.new ( "TextLabel" )k.Size =UDim2.new ( 0 , 50 , 0 , 24 )k.Position =UDim2.new ( 1 , -64 , 0 , 14 )k.BackgroundTransparency = 1 k.Text = "0%" k.TextColor3 =Color3.fromRGB ( 0 , 255 , 160 )k.TextSize = 14 k.Font =Enum.Font.GothamBold k.TextXAlignment =Enum.TextXAlignment.Right k.AutoLocalize = false k.Parent =r
    local a=Instance.new ( "Frame" )a.Size =UDim2.new ( 1 , -28 , 0 , 10 )a.Position =UDim2.new ( 0 , 14 , 0 , 74 )a.BackgroundColor3 =Color3.fromRGB ( 25 , 27 , 38 )a.BorderSizePixel = 0 a.Parent =r;
    (Instance.new ( "UICorner" ,a)).CornerRadius =UDim.new ( 0 , 5 )
    local V=Instance.new ( "Frame" )V.Size =UDim2.new ( 0 , 0 , 1 , 0 )V.BackgroundColor3 =Color3.fromRGB ( 0 , 185 , 255 )V.BorderSizePixel = 0 V.Parent =a;
    (Instance.new ( "UICorner" ,V)).CornerRadius =UDim.new ( 0 , 5 )
    local H=Instance.new ( "UIGradient" ,V)H.Color =ColorSequence.new ({ColorSequenceKeypoint.new ( 0 ,Color3.fromRGB ( 0 , 185 , 255 )),ColorSequenceKeypoint.new ( 1 ,Color3.fromRGB ( 0 , 255 , 160 ))})
    local t=Instance.new ( "TextLabel" )t.Size =UDim2.new ( 1 , -28 , 0 , 16 )t.Position =UDim2.new ( 0 , 14 , 0 , 94 )t.BackgroundTransparency = 1 t.Text = "Initializing Ken Hub..." t.TextColor3 =Color3.fromRGB ( 130 , 140 , 165 )t.TextSize = 11 t.Font =Enum.Font.Gotham t.TextXAlignment =Enum.TextXAlignment.Left t.AutoLocalize = false t.Parent =r task.spawn (function(...)
        for y= 1 , 100 , 1 do
            if not e.Parent then
                break
            end
            k.Text =tostring(y).. "%" V.Size =UDim2.new (y/ 100 , 0 , 1 , 0 )
            if y== 25 then
                t.Text = "Loading interface modules..."
            elseif y== 60 then
                t.Text = "Setting up auto-steal controllers..."
            elseif y== 85 then
                t.Text = "Syncing server telemetry..."
            elseif y== 100 then
                t.Text = "Ready!"
            end
            task.wait ( 0.008 )
        end
    end
    )
    local function s(o,...) task.spawn (function(...) task.wait ( 0.9 )
            local H=TweenInfo.new ( 0.35 ,Enum.EasingStyle.Quart ,Enum.EasingDirection.Out );
            (u:Create(r,H,{[ "BackgroundTransparency" ]= 1 })):Play();
            (u:Create(y,H,{[ "Transparency" ]= 1 })):Play();
            (u:Create(w,H,{[ "TextTransparency" ]= 1 })):Play();
            (u:Create(j,H,{[ "TextTransparency" ]= 1 })):Play();
            (u:Create(k,H,{[ "TextTransparency" ]= 1 })):Play();
            (u:Create(a,H,{[ "BackgroundTransparency" ]= 1 })):Play();
            (u:Create(V,H,{[ "BackgroundTransparency" ]= 1 })):Play();
            (u:Create(t,H,{[ "TextTransparency" ]= 1 })):Play()task.wait ( 0.4 )pcall(function(...) e:Destroy()
            end
            )
            if o then
                o()
            end
        end
        )
    end
    return s
end
local kM={}kM.Gui =Instance.new ( "ScreenGui" )kM.Gui.Name = "Dice_RESTORE_BAR" kM.Gui.ResetOnSpawn = false kM.Gui.DisplayOrder = 999999 kM.Gui.ZIndexBehavior =Enum.ZIndexBehavior.Sibling kM.Gui.AutoLocalize = false pcall(function(...)
    if syn and syn.protect_gui then
        syn.protect_gui (kM.Gui )kM.Gui.Parent =game:GetService( "CoreGui" )
    else
        kM.Gui.Parent =o:FindFirstChild( "PlayerGui" )or game:GetService( "CoreGui" )
    end
end
)
if not kM.Gui.Parent then
    kM.Gui.Parent =game:GetService( "CoreGui" )
end
kM.Btn =Instance.new ( "ImageButton" )kM.Btn.Name = "Dice_SquareLogoButton" kM.Btn.Size =UDim2.fromOffset ( 46 , 46 )kM.Btn.Position =UDim2.new ( 0 , 20 , 0 , 20 )kM.Btn.BackgroundColor3 =Color3.fromRGB ( 18 , 18 , 24 )kM.Btn.Active = true kM.Btn.Selectable = true kM.Btn.Visible = false kM.Btn.ZIndex = 999999 kM.Btn.AutoLocalize = false kM.Btn.Parent =kM.Gui ;
(Instance.new ( "UICorner" ,kM.Btn )).CornerRadius =UDim.new ( 0 , 10 )kM.Stroke =Instance.new ( "UIStroke" ,kM.Btn )kM.Stroke.Color =Color3.fromRGB ( 0 , 185 , 255 )kM.Stroke.Thickness = 1.6 kM.Stroke.ApplyStrokeMode =Enum.ApplyStrokeMode.Border kM.Logo =Instance.new ( "ImageLabel" ,kM.Btn )kM.Logo.Name = "LogoIcon" kM.Logo.Size =UDim2.fromOffset ( 36 , 36 )kM.Logo.Position =UDim2.new ( 0.5 , 0 , 0.5 , 0 )kM.Logo.AnchorPoint =Vector2.new ( 0.5 , 0.5 )kM.Logo.BackgroundTransparency = 1 kM.Logo.Image =dk kM.Logo.ImageColor3 =Color3.fromRGB ( 255 , 255 , 255 )kM.Logo.ZIndex = 1000000 ;
(Instance.new ( "UICorner" ,kM.Logo )).CornerRadius =UDim.new ( 0 , 8 )kM.isDragging = false kM.dragStart =nil kM.startPos =nil kM.Btn.InputBegan :Connect(function(e,...)
    if e.UserInputType ==Enum.UserInputType.MouseButton1 or e.UserInputType ==Enum.UserInputType.Touch then
        kM.isDragging = true kM.dragStart =e.Position kM.startPos =kM.Btn.Position
    end
end
)w.InputEnded :Connect(function(e,...)
    if e.UserInputType ==Enum.UserInputType.MouseButton1 or e.UserInputType ==Enum.UserInputType.Touch then
        kM.isDragging = false
    end
end
)w.InputChanged :Connect(function(e,...)
    if kM.isDragging and((e.UserInputType ==Enum.UserInputType.MouseMovement or e.UserInputType ==Enum.UserInputType.Touch ))then
        local y=e.Position -kM.dragStart kM.Btn.Position =UDim2.new (kM.startPos.X .Scale ,kM.startPos.X .Offset +y.X ,kM.startPos.Y .Scale ,kM.startPos.Y .Offset +y.Y )
    end
end
)
local function aM(...) h.alive = false pcall(Ik)pcall(Ak)pcall(function(...) y:Set3dRenderingEnabled( true )
    end
    )pcall(function(...)
        local y=r:FindFirstChild( "KenHub_EggESP" )
        if y then
            y:Destroy()
        end
    end
    )pcall(D4)pcall(u4)
    if kM and kM.Gui then
        pcall(function(...) kM.Gui :Destroy()
        end
        )
    end
    if h.gui then
        pcall(function(...) h.gui :Destroy()
        end
        )
    end
    pcall(function(...)
        for r,y in ipairs(game.CoreGui :GetChildren())do
            if y.Name :find( "Dice_" )or y.Name :find( "DesyncSniperUI" )or y.Name :find( "WindUI" )then
                y:Destroy()
            end
        end
    end
    )
end
local function oM(...)
    local e=jM()
    local r=nil pcall(function(...) r=(loadstring(game:HttpGet( "https://raw.githubusercontent.com/Footagesus/WindUI/main/dist/main.lua" )))()
    end
    )
    local function j(e,...)
        if not e then
            return
        end
        local y= false
        if r and r.Notify then
            local u=pcall(function(...) r:Notify(e)y= true
            end
            )
        end
        if not y then
            pcall(function(...)
                (game:GetService( "StarterGui" )):SetCore( "SendNotification" ,{[ "Title" ]=tostring(e.Title or "Ken Hub" ),[ "Text" ]=tostring(e.Content or "" );
                [ "Duration" ]= 3 })
            end
            )
        end
    end
    if r then
        pcall(function(...)
            local e=r.Notify
            if e then
                r.Notify =function(r,y,...)
                    local u=pcall(function(...) e(r,y)
                    end
                    )
                    if not u then
                        pcall(function(...)
                            (game:GetService( "StarterGui" )):SetCore( "SendNotification" ,{[ "Title" ]=tostring(y and y.Title or "Ken Hub" );
                            [ "Text" ]=tostring(y and y.Content or "" ),[ "Duration" ]= 3 })
                        end
                        )
                    end
                end
            end
        end
        )
        local k=workspace.CurrentCamera
        local a=k and k.ViewportSize or Vector2.new ( 1280 , 720 )
        local V=w.TouchEnabled and not w.KeyboardEnabled
        local H=V and math.clamp (a.X * 0.7 , 440 , 500 )or 500
        local t=V and math.clamp (a.Y * 0.72 , 280 , 340 )or 340
        local s=UDim2.fromOffset (H,t)
        local p=r:CreateWindow({[ "Title" ]= "Ken Hub" ;
        [ "Author" ]= "Steal An Egg V1" ;
        [ "Folder" ]= "Dice_StealAnEgg" ;
        [ "Icon" ]=dk;
        [ "Theme" ]= "Dark" ,[ "IconSize" ]= 28 ,[ "Size" ]=s,[ "MinSize" ]=Vector2.new ( 400 , 240 );
        [ "MaxSize" ]=Vector2.new ( 900 , 600 ),[ "Resizable" ]= true ,[ "SideBarWidth" ]=V and 140 or 160 ,[ "ToggleKey" ]=Enum.KeyCode.RightShift ;
        [ "IgnoreAlerts" ]= true ,[ "Topbar" ]={[ "Height" ]= 44 ,[ "ButtonsType" ]= "Default" }})
        Window=p
        p.IgnoreAlerts = true pcall(function(...)
            if p.UIElements and p.UIElements.Main then
                p.UIElements.Main .Visible = false
            end
        end
        )
        local B=p:Tag({[ "Title" ]= "Status: Ready" ;
        [ "Color" ]=Color3.fromRGB ( 0 , 255 , 160 ),[ "Border" ]= true })
        local J= 44
        local K= false
        local c= false
        local v=t task.spawn (function(...) task.wait ( 0.1 )
            local e=p.UIElements and p.UIElements.Main
            if e then
                if e.AnchorPoint.Y ~= 0 then
                    local y=e.Size.Y .Offset > 0 and e.Size.Y .Offset or t e.Position =UDim2.new (e.Position.X .Scale ,e.Position.X .Offset ,e.Position.Y .Scale ,e.Position.Y .Offset -(y*e.AnchorPoint.Y ))e.AnchorPoint =Vector2.new ( 0.5 , 0 )
                end
                e.ClipsDescendants = false mk(e)
            end
        end
        )
        local function i(...)
            local e=p.UIElements and p.UIElements.Main
            if not e or c then
                return
            end
            c= true K=not K
            local r=p.UIElements.SideBarContainer
            local y=p.UIElements.MainBar
            local w=e:FindFirstChild( "Background" )
            local j=e:FindFirstChild( "Main" )
            if e.AnchorPoint.Y ~= 0 then
                local r=e.Size.Y .Offset > 0 and e.Size.Y .Offset or v e.Position =UDim2.new (e.Position.X .Scale ,e.Position.X .Offset ,e.Position.Y .Scale ,e.Position.Y .Offset -(r*e.AnchorPoint.Y ))e.AnchorPoint =Vector2.new ( 0.5 , 0 )
            end
            local k=e.Size.X .Scale
            local a=e.Size.X .Offset
            if K then
                if e.Size.Y .Offset >J then
                    v=e.Size.Y .Offset
                end
                e.ClipsDescendants = true
                if w then
                    w.ClipsDescendants = true
                end
                if j then
                    j.ClipsDescendants = true
                end
                if r then
                    r.Visible = false
                end
                if y then
                    y.Visible = false
                end
                e.Visible = true
                if j then
                    j.Visible = true
                end
                local V=u:Create(e,TweenInfo.new ( 0.24 ,Enum.EasingStyle.Quart ,Enum.EasingDirection.Out ),{[ "Size" ]=UDim2.new (k,a, 0 ,J)})V:Play()task.delay ( 0.25 ,function(...) c= false
                end
                )
            else
                e.Visible = true
                if j then
                    j.Visible = true
                end
                local V=v or t
                if r then
                    r.Visible = true
                end
                if y then
                    y.Visible = true
                end
                if p.TabModule and p.TabModule.SelectedTab then
                    pcall(function(...) p.TabModule :SelectTab(p.TabModule.SelectedTab )
                    end
                    )
                end
                local H=u:Create(e,TweenInfo.new ( 0.24 ,Enum.EasingStyle.Quart ,Enum.EasingDirection.Out ),{[ "Size" ]=UDim2.new (k,a, 0 ,V)})H:Play()task.delay ( 0.25 ,function(...)
                    if not K then
                        e.ClipsDescendants = false
                        if w then
                            w.ClipsDescendants = false
                        end
                        if j then
                            j.ClipsDescendants = false
                        end
                        if r then
                            r.Visible = true
                        end
                        if y then
                            y.Visible = true
                        end
                        if p.TabModule and p.TabModule.SelectedTab then
                            pcall(function(...) p.TabModule :SelectTab(p.TabModule.SelectedTab )
                            end
                            )
                        end
                    end
                    c= false
                end
                )
            end
        end
        p.Close =function(e,...) i()
            local r={}function r.Destroy(e,...) aM()
            end
            return r
        end
        local function R(...)
            if p.UIElements and p.UIElements.Main then
                (u:Create(kM.Btn ,TweenInfo.new ( 0.12 ,Enum.EasingStyle.Quart ),{[ "Size" ]=UDim2.fromOffset ( 42 , 42 )})):Play()task.wait ( 0.08 )kM.Btn.Size =UDim2.fromOffset ( 46 , 46 )p.UIElements.Main .Visible = true kM.Btn.Visible = false
                if p.TabModule and p.TabModule.SelectedTab then
                    pcall(function(...) p.TabModule :SelectTab(p.TabModule.SelectedTab )
                    end
                    )
                end
            end
        end
        local function g(...)
            if p.UIElements and p.UIElements.Main then
                p.UIElements.Main .Visible = false kM.Btn.Visible = true
            end
        end
        kM.Btn.MouseButton1Click :Connect(R)p.Destroy =function(e,...) g()
        end
        w.InputBegan :Connect(function(e,r,...)
            if not r and e.KeyCode ==Enum.KeyCode.RightShift then
                if p.UIElements and p.UIElements.Main then
                    if p.UIElements.Main .Visible then
                        g()
                    else
                        R()
                    end
                end
            end
        end
        )
        local function Q(e,...)
            local r=math.clamp (tonumber(e)or 0 , 0 , 90 )
            local y=r/ 100 pcall(function(...)
                local e=p.UIElements and p.UIElements.Main
                if not e then
                    return
                end
                if p.AcrylicPaint and p.AcrylicPaint.Frame then
                    p.AcrylicPaint.Frame .Visible =(r== 0 )
                end
                local u=e:FindFirstChild( "Background" )
                if u then
                    if u:IsA( "ImageLabel" )then
                        u.ImageTransparency =y
                    elseif u:IsA( "Frame" )then
                        u.BackgroundTransparency =y
                    end
                end
            end
            )
        end
        local P=Gk[Xk]or Gk.EN hk=p:Tab({[ "Title" ]=P.Tabs.Farm ;
        [ "Icon" ]= "solar:box-minimalistic-bold" })Ok=p:Tab({[ "Title" ]=P.Tabs.EggSelect or "Egg Selection" ;
        [ "Icon" ]= "lucide:egg" })Yk=p:Tab({[ "Title" ]=P.Tabs.Character ;
        [ "Icon" ]= "solar:user-bold" })Tk=p:Tab({[ "Title" ]=P.Tabs.Settings ;
        [ "Icon" ]= "solar:settings-bold" })Fk.secModes =hk:Section({[ "Title" ]=P.Farm.SecModes })
        local N= false
        local U=nil
        local l=nil Fk.togTween =hk:Toggle({[ "Title" ]=P.Farm.TweenTitle ,[ "Desc" ]=P.Farm.TweenDesc ,[ "Icon" ]= "solar:compass-bold" ;
        [ "Value" ]=h.pureTweenFarm ;
        [ "Callback" ]=function(e,...)
            if N then
                return
            end
            if e then
                T4( "TWEEN" )
            else
                if Y4== "TWEEN" or h.pureTweenFarm then
                    T4( "NONE" )
                end
            end
        end
        })U=Fk.togTween Fk.togTeleport =hk:Toggle({[ "Title" ]=P.Farm.TeleportTitle ;
        [ "Desc" ]=P.Farm.TeleportDesc ,[ "Icon" ]= "solar:magic-stick-3-bold" ,[ "Value" ]=h.autoFarmLoop ,[ "Callback" ]=function(e,...)
            if N then
                return
            end
            if e then
                T4( "WARP" )
            else
                if Y4== "WARP" or h.autoFarmLoop then
                    T4( "NONE" )
                end
            end
        end
        })l=Fk.togTeleport x4=function(e,...) pcall(function(...)
                if U and U.Set then
                    N= true U:Set(e)N= false
                end
            end
            )
        end
        W4=function(e,...) pcall(function(...)
                if l and l.Set then
                    N= true l:Set(e)N= false
                end
            end
            )
        end
        Fk.secPlace =hk:Section({[ "Title" ]=P.Farm.SecPlace })Fk.btnPlaceEgg =hk:Button({[ "Title" ]=P.Farm.PlaceTitle ,[ "Desc" ]=P.Farm.PlaceDesc ,[ "Icon" ]= "solar:box-bold" ;
        [ "Callback" ]=function(...) task.spawn (function(...) j({[ "Title" ]= "Steal An Egg V1" ,[ "Content" ]=Gk[Xk].Notifications.PlaceStarted ,[ "Icon" ]= "loader" })h.statusText = "[Manual] Tweening to base..." v4(h.glideSpeed ,nil, true )j({[ "Title" ]= "Steal An Egg V1" ,[ "Content" ]=Gk[Xk].Notifications.PlaceDone ,[ "Icon" ]= "check-circle" })
            end
            )
        end
        })Fk.togAutoPlaceEvery5 =hk:Toggle({[ "Title" ]=P.Farm.AutoPlaceTitle or "Auto Place (Every 5)" ;
        [ "Desc" ]=P.Farm.AutoPlaceDesc or "Return home every 5 steals, place & wait 5s" ;
        [ "Icon" ]= "solar:box-minimalistic-bold" ;
        [ "Value" ]=h.autoPlaceEvery5 ;
        [ "Callback" ]=function(e,...) h.autoPlaceEvery5 =e
            if not e then
                h.batchStealCount = 0
            end
            local r=Gk[Xk]or Gk.EN j({[ "Title" ]= "Auto Place (Every 5)" ,[ "Content" ]=e and((r.Notifications.AutoPlaceStarted or "Auto Place (Every 5) enabled" ))or(r.Notifications.AutoPlaceStopped or "Auto Place (Every 5) disabled" ),[ "Icon" ]=e and "check-circle" or "x-circle" })
        end
        })Fk.togAutoHatch =hk:Toggle({[ "Title" ]=P.Farm.HatchTitle ;
        [ "Desc" ]=P.Farm.HatchDesc ,[ "Icon" ]= "solar:star-bold" ;
        [ "Value" ]=h.autoHatch ,[ "Callback" ]=function(e,...) h.autoHatch =e j({[ "Title" ]= "Auto Hatch" ,[ "Content" ]=e and Gk[Xk].Notifications.HatchStarted or Gk[Xk].Notifications.HatchStopped ,[ "Icon" ]=e and "check-circle" or "x-circle" })
        end
        })Fk.togAutoReturn =hk:Toggle({[ "Title" ]=P.Farm.ReturnTitle ;
        [ "Desc" ]=P.Farm.ReturnDesc ;
        [ "Icon" ]= "solar:undo-left-round-bold" ,[ "Value" ]=h.autoGlide ;
        [ "Callback" ]=function(e,...) h.autoGlide =e j({[ "Title" ]= "Auto Return" ;
            [ "Content" ]=e and Gk[Xk].Notifications.ReturnStarted or Gk[Xk].Notifications.ReturnStopped ;
            [ "Icon" ]=e and "check-circle" or "x-circle" })
        end
        })Fk.togAutoTreadmill =hk:Toggle({[ "Title" ]=P.Farm.AutoTreadmillTitle or "Auto Treadmill" ;
        [ "Desc" ]=P.Farm.AutoTreadmillDesc or "Run on base treadmill when no target eggs are spawned" ;
        [ "Icon" ]= "solar:running-bold" ;
        [ "Value" ]=h.autoTreadmill ;
        [ "Callback" ]=function(e,...) h.autoTreadmill =e x()n4()
            if not e and((h.onTreadmill or L4()))then
                M4()
            end
            local r=Gk[Xk]or Gk.EN j({[ "Title" ]= "Auto Treadmill" ;
            [ "Content" ]=e and((r.Notifications.AutoTreadmillStarted or "Auto Treadmill enabled (Runs when idle)" ))or(r.Notifications.AutoTreadmillStopped or "Auto Treadmill disabled" );
            [ "Icon" ]=e and "check-circle" or "x-circle" })
        end
        })Fk.togAutoUpgradeTreadmill =hk:Toggle({[ "Title" ]=P.Farm.UpgradeTreadmillTitle or "Auto Upgrade Treadmill" ;
        [ "Desc" ]=P.Farm.UpgradeTreadmillDesc or "Automatically upgrade base treadmill tier when you have enough cash" ;
        [ "Icon" ]= "solar:double-alt-arrow-up-bold" ;
        [ "Value" ]=h.autoUpgradeTreadmill ,[ "Callback" ]=function(e,...) h.autoUpgradeTreadmill =e x()
            local r=Gk[Xk]or Gk.EN j({[ "Title" ]=(Xk== "TH" )and "อัปเกรดลู่วิ่ง" or "Upgrade Treadmill" ,[ "Content" ]=e and((r.Notifications.UpgradeTreadmillStarted or "Auto Upgrade Treadmill enabled" ))or(r.Notifications.UpgradeTreadmillStopped or "Auto Upgrade Treadmill disabled" ),[ "Icon" ]=e and "check-circle" or "x-circle" })
        end
        })Fk.togAutoBuyTrails =hk:Toggle({[ "Title" ]=P.Farm.BuyTrailsTitle or "Auto Buy & Equip Trails" ;
        [ "Desc" ]=P.Farm.BuyTrailsDesc or "Automatically purchase and equip the best speed trail available" ;
        [ "Icon" ]= "solar:fire-bold" ;
        [ "Value" ]=h.autoBuyTrails ;
        [ "Callback" ]=function(e,...) h.autoBuyTrails =e x()
            local r=Gk[Xk]or Gk.EN j({[ "Title" ]=(Xk== "TH" )and "ซื้อ Trail" or "Buy Trails" ,[ "Content" ]=e and((r.Notifications.BuyTrailsStarted or "Auto Buy Trails enabled" ))or(r.Notifications.BuyTrailsStopped or "Auto Buy Trails disabled" );
            [ "Icon" ]=e and "check-circle" or "x-circle" })
        end
        })Fk.secEggZones =Ok:Section({[ "Title" ]=(P.EggSelect and P.EggSelect.SecZones )or "Target Zones" })
        local D={ "🟣 Light Dark" ;
        "🟡 Titan Temple" , "🌸 Cherry Blossom" ;
        "🌌 Cosmic" ;
        "🦖 Prehistoric" , "🌊 Abyss Ocean" , "🌋 Volcano" ;
        "❄️ Snow" ;
        "🌴 Jungle" ;
        "🏜️ Desert" , "💧 Lake" ;
        "🌲 Forest" }
        local C={[ "🟣 Light Dark" ]= "Light Dark" ,[ "🟡 Titan Temple" ]= "Titan Temple" ,[ "🌸 Cherry Blossom" ]= "Cherry Blossom" ,[ "🌌 Cosmic" ]= "Cosmic" ;
        [ "🦖 Prehistoric" ]= "Prehistoric" ,[ "🌊 Abyss Ocean" ]= "Abyss Ocean" ;
        [ "🌋 Volcano" ]= "Volcano" ;
        [ "❄️ Snow" ]= "Snow" ;
        [ "🌴 Jungle" ]= "Jungle" ,[ "🏜️ Desert" ]= "Desert" ,[ "💧 Lake" ]= "Lake" ,[ "🌲 Forest" ]= "Forest" }
        local q={[ "Light Dark" ]= "🟣 Light Dark" ,[ "Titan Temple" ]= "🟡 Titan Temple" ;
        [ "Cherry Blossom" ]= "🌸 Cherry Blossom" ;
        [ "Cosmic" ]= "🌌 Cosmic" ,[ "Prehistoric" ]= "🦖 Prehistoric" ;
        [ "Abyss Ocean" ]= "🌊 Abyss Ocean" ;
        [ "Volcano" ]= "🌋 Volcano" ;
        [ "Snow" ]= "❄️ Snow" ,[ "Jungle" ]= "🌴 Jungle" ,[ "Desert" ]= "🏜️ Desert" ;
        [ "Lake" ]= "💧 Lake" ,[ "Forest" ]= "🌲 Forest" }
        local n={}
        for e,r in pairs(h.selectedZones or{})do
            if r and q[e]then
                table.insert (n,q[e])
            end
        end
        Fk.dropTargetZones =Ok:Dropdown({[ "Title" ]=(P.EggSelect and P.EggSelect.DropZonesTitle )or "Selected Zones" ,[ "Desc" ]=(P.EggSelect and P.EggSelect.DropZonesDesc )or "Click to choose which zones to farm eggs from" ,[ "Values" ]=D,[ "Value" ]=n,[ "Multi" ]= true ;
        [ "Callback" ]=function(e,...)
            local r={}
            local function y(e,...)
                if type(e)== "table" then
                    e=e.Title or e.Name or e[ 1 ]or ""
                end
                local y=tostring(e or "" )
                local w=C[y]
                if not w and(y~= "" and(y~= "true" and y~= "false" ))then
                    for e,r in ipairs(M)do
                        if string.find (string.lower (y),string.lower (r))then
                            w=r
                            break
                        end
                    end
                end
                if w and f[w]then
                    r[w]= true
                end
            end
            if type(e)== "table" then
                for e,r in pairs(e)do
                    if type(r)== "string" or type(r)== "table" then
                        y(r)
                    elseif type(e)== "string" and r== true then
                        y(e)
                    end
                end
            elseif type(e)== "string" then
                y(e)
            end
            h.selectedZones =r x()
        end
        })Fk.secEggRarity =Ok:Section({[ "Title" ]=(P.EggSelect and P.EggSelect.SecRarities )or "Target Rarities" })
        local I={ "👑 Divine (Tier 6)" ;
        "⚡ Eternal (Tier 5)" , "🔥 Secret (Tier 4)" , "✨ Cosmic (Tier 3)" , "🔮 Mythic (Tier 2)" ;
        "⭐ Legendary (Tier 1)" ;
        "💜 Epic" ;
        "🔷 Rare" ;
        "🟢 Uncommon" , "⚪ Common" }
        local L={[ "👑 Divine (Tier 6)" ]= "Divine" ,[ "⚡ Eternal (Tier 5)" ]= "Eternal" ,[ "🔥 Secret (Tier 4)" ]= "Secret" ;
        [ "✨ Cosmic (Tier 3)" ]= "Cosmic" ;
        [ "🔮 Mythic (Tier 2)" ]= "Mythic" ;
        [ "⭐ Legendary (Tier 1)" ]= "Legendary" ,[ "💜 Epic" ]= "Epic" ,[ "🔷 Rare" ]= "Rare" ,[ "🟢 Uncommon" ]= "Uncommon" ,[ "⚪ Common" ]= "Common" }
        local E={[ "Divine" ]= "👑 Divine (Tier 6)" ,[ "Eternal" ]= "⚡ Eternal (Tier 5)" ;
        [ "Secret" ]= "🔥 Secret (Tier 4)" ;
        [ "Cosmic" ]= "✨ Cosmic (Tier 3)" ,[ "Mythic" ]= "🔮 Mythic (Tier 2)" ,[ "Legendary" ]= "⭐ Legendary (Tier 1)" ,[ "Epic" ]= "💜 Epic" ,[ "Rare" ]= "🔷 Rare" ;
        [ "Uncommon" ]= "🟢 Uncommon" ;
        [ "Common" ]= "⚪ Common" }
        local b={}
        for e,r in pairs(h.selectedRarities or{})do
            if r and E[e]then
                table.insert (b,E[e])
            end
        end
        Fk.dropTargetRarities =Ok:Dropdown({[ "Title" ]=(P.EggSelect and P.EggSelect.DropRaritiesTitle )or "Selected Rarities" ;
        [ "Desc" ]=(P.EggSelect and P.EggSelect.DropRaritiesDesc )or "Click to choose which rarities to collect" ,[ "Values" ]=I;
        [ "Value" ]=b,[ "Multi" ]= true ;
        [ "Callback" ]=function(e,...)
            local r={}
            local function y(e,...)
                if type(e)== "table" then
                    e=e.Title or e.Name or e[ 1 ]or ""
                end
                local y=string.lower (tostring(e or "" ))
                for e,u in ipairs(X)do
                    if string.find (y,string.lower (u))then
                        r[u]= true
                        break
                    end
                end
            end
            if type(e)== "table" then
                for e,r in pairs(e)do
                    if type(r)== "string" or type(r)== "table" then
                        y(r)
                    elseif type(e)== "string" and r== true then
                        y(e)
                    end
                end
            elseif type(e)== "string" then
                y(e)
            end
            h.selectedRarities =r x()
        end
        })Fk.secSafety =Yk:Section({[ "Title" ]=P.Character.SecSafety })Fk.togGodmode =Yk:Toggle({[ "Title" ]=P.Character.GodmodeTitle ;
        [ "Desc" ]=P.Character.GodmodeDesc ,[ "Icon" ]= "solar:shield-check-bold" ,[ "Value" ]= false ;
        [ "Callback" ]=function(e,...)
            if e then
                enableDesyncGodmode()j({[ "Title" ]= "Godmode" ,[ "Content" ]=Gk[Xk].Notifications.GodmodeStarted ,[ "Icon" ]= "shield-check" })
            else
                disableDesyncGodmode()j({[ "Title" ]= "Godmode" ,[ "Content" ]=Gk[Xk].Notifications.GodmodeStopped ,[ "Icon" ]= "shield-off" })
            end
        end
        })Fk.btnUnstick =Yk:Button({[ "Title" ]=P.Character.UnstickTitle ,[ "Desc" ]=P.Character.UnstickDesc ,[ "Icon" ]= "solar:exit-bold" ;
        [ "Callback" ]=function(...) pcall(M4)pcall(C4)pcall(D4)j({[ "Title" ]= "Unstick" ;
            [ "Content" ]=Gk[Xk].Notifications.UnstickDone ,[ "Icon" ]= "check" })
        end
        })Fk.secFlight =Yk:Section({[ "Title" ]=P.Character.SecFlight })Fk.sliderSpeed =Yk:Slider({[ "Title" ]=P.Character.SpeedTitle ,[ "Desc" ]=P.Character.SpeedDesc ,[ "Step" ]= 25 ,[ "Value" ]={[ "Min" ]= 100 ;
        [ "Max" ]= 1000 ;
        [ "Default" ]=h.glideSpeed or 600 },[ "Callback" ]=function(e,...) h.glideSpeed =e Y(e)
        end
        })Fk.secDashboard =Tk:Section({[ "Title" ]=P.Settings.SecDashboard })Fk.paraLiveDash =Tk:Paragraph({[ "Title" ]=P.Settings.DashTitle ;
        [ "Desc" ]=string.format ( "Status: Ready\nFarm Mode: Idle\nCarried Eggs: 0\nFlight Speed: %d Studs/s" ,h.glideSpeed or 600 )})Fk.secUI =Tk:Section({[ "Title" ]=P.Settings.SecUI })Fk.dropLang =Tk:Dropdown({[ "Title" ]=P.Settings.LangTitle ,[ "Values" ]={ "English" , "ไทย" },[ "Value" ]=(Xk== "EN" and "English" or "ไทย" ),[ "Callback" ]=function(e,...)
            local r=(e== "ไทย" )and "TH" or "EN"
            if r~=Xk then
                Xk=r wM(Xk)pcall(x)j({[ "Title" ]=(Xk== "TH" )and "ภาษา" or "Language" ,[ "Content" ]=Gk[Xk].Notifications.LangSwitched ,[ "Icon" ]= "check-circle" })
            end
        end
        })Fk.sliderTransp =Tk:Slider({[ "Title" ]=P.Settings.TranspTitle ;
        [ "Desc" ]=P.Settings.TranspDesc ;
        [ "Step" ]= 5 ;
        [ "Value" ]={[ "Min" ]= 0 ;
        [ "Max" ]= 90 ,[ "Default" ]= 0 },[ "Callback" ]=function(e,...) Q(e)
        end
        })Fk.dropTheme =Tk:Dropdown({[ "Title" ]=P.Settings.ThemeTitle ;
        [ "Values" ]={ "Dark" ;
        "Rose" , "Plant" ;
        "Red" , "Sky" , "Purple" },[ "Value" ]= "Dark" ;
        [ "Callback" ]=function(e,...) pcall(function(...) r:SetTheme(e)
            end
            )
        end
        })Fk.secPerformance =Tk:Section({[ "Title" ]=(P.Settings and P.Settings.SecPerformance )or "Performance & Graphics" })Fk.togPerformance =Tk:Toggle({[ "Title" ]=(P.Settings and P.Settings.PerformanceTitle )or "Ultra Potato Mode (Maximum FPS Boost)" ;
        [ "Desc" ]=(P.Settings and P.Settings.PerformanceDesc )or "Disables shadows, textures, particles, and shaders for maximum FPS smoothness" ,[ "Icon" ]= "solar:bolt-bold" ,[ "Value" ]=h.performanceMode ,[ "Callback" ]=function(e,...) h.performanceMode =e x()
            if e then
                Mk()
            else
                Ik()
            end
            local r=Gk[Xk]or Gk.EN j({[ "Title" ]= "Performance Mode" ,[ "Content" ]=e and((r.Notifications.PerformanceStarted or "Performance Mode enabled" ))or(r.Notifications.PerformanceStopped or "Performance Mode disabled" ),[ "Icon" ]=e and "check-circle" or "x-circle" })
        end
        })Fk.togDisable3D =Tk:Toggle({[ "Title" ]=(P.Settings and P.Settings.Disable3DTitle )or "Disable 3D Rendering (GPU Saver 95%)" ;
        [ "Desc" ]=(P.Settings and P.Settings.Disable3DDesc )or "Freezes 3D viewport rendering to drop GPU usage to ~1%. Perfect for overnight farming!" ;
        [ "Icon" ]= "solar:monitor-camera-bold" ;
        [ "Value" ]=h.disable3D ,[ "Callback" ]=function(e,...) h.disable3D =e x()pcall(function(...) y:Set3dRenderingEnabled(not e)
            end
            )
            local r=Gk[Xk]or Gk.EN j({[ "Title" ]= "3D Rendering" ,[ "Content" ]=e and((r.Notifications.Disable3DStarted or "3D Rendering disabled (GPU Saver)" ))or(r.Notifications.Disable3DStopped or "3D Rendering restored" ),[ "Icon" ]=e and "check-circle" or "x-circle" })
        end
        })Fk.secSystem =Tk:Section({[ "Title" ]=P.Settings.SecSystem })Fk.togAntiAFK =Tk:Toggle({[ "Title" ]=(P.Settings and P.Settings.AntiAFKTitle )or "Anti-AFK (Double-Esc 10m / Mobile)" ,[ "Desc" ]=(P.Settings and P.Settings.AntiAFKDesc )or "Double-Esc menu pulse every 10m + Mobile touch + PC jitter resets idle timer safely without Idled" ;
        [ "Icon" ]= "solar:shield-check-bold" ;
        [ "Value" ]=h.antiAFK ,[ "Callback" ]=function(e,...) h.antiAFK =e x()
            if e then
                bk()
            else
                Ak()
            end
            local r=Gk[Xk]or Gk.EN j({[ "Title" ]= "Anti-AFK" ,[ "Content" ]=e and((r.Notifications.AntiAFKStarted or "Safe Anti-AFK enabled" ))or(r.Notifications.AntiAFKStopped or "Safe Anti-AFK disabled" ),[ "Icon" ]=e and "check-circle" or "x-circle" })
        end
        })Fk.btnReset =Tk:Button({[ "Title" ]=P.Settings.ResetTitle ;
        [ "Desc" ]=P.Settings.ResetDesc ,[ "Icon" ]= "solar:restart-bold" ;
        [ "Callback" ]=function(...) pcall(D4)pcall(u4)j({[ "Title" ]= "Reset State" ;
            [ "Content" ]= "Character state reset successfully" ,[ "Icon" ]= "check-circle" })
        end
        })Fk.btnRejoin =Tk:Button({[ "Title" ]=P.Settings.RejoinTitle ;
        [ "Desc" ]=P.Settings.RejoinDesc ;
        [ "Icon" ]= "solar:logout-2-bold" ,[ "Callback" ]=function(...) pcall(function(...) TeleportService:TeleportToPlaceInstance(game.PlaceId,game.JobId,o)
            end
            )
        end
        })Fk.btnUnload =Tk:Button({[ "Title" ]=P.Settings.UnloadTitle ,[ "Desc" ]=P.Settings.UnloadDesc ;
        [ "Icon" ]= "solar:trash-bin-trash-bold" ,[ "Callback" ]=function(...) aM()
        end
        })yM()task.spawn (function(...)
            while h.alive do
                pcall(function(...)
                    local r=y4()
                    local y=(Xk== "TH" )
                    local u=Wk(Xk)
                    if B then
                        local e=Color3.fromRGB ( 0 , 255 , 160 )
                        if h.securingEgg or h.teleporting then
                            e=Color3.fromRGB ( 249 , 115 , 22 )
                        elseif h.isReturning or h.glidingToTarget then
                            e=Color3.fromRGB ( 59 , 130 , 246 )
                        elseif h.delivering then
                            e=Color3.fromRGB ( 16 , 185 , 129 )
                        end
                        pcall(function(...)
                            if B.SetTitle then
                                B:SetTitle(((y and "สถานะ: " or "Status: " ))..u)
                            end
                            if B.SetColor then
                                B:SetColor(e)
                            end
                        end
                        )
                    end
                    if Fk.paraLiveDash and Fk.paraLiveDash.SetDesc then
                        local e=y and "หยุดพัก" or "Idle"
                        if Y4== "TWEEN" then
                            e=y and "ขโมยไข่ (บินเร็ว)" or "Auto Steal (Tween)"
                        elseif Y4== "WARP" then
                            e=y and "ขโมยไข่ (วาร์ป)" or "Auto Steal (Teleport)"
                        end
                        local j=y and "สถานะ: %s\nโหมดฟาร์ม: %s\nจำนวนไข่ในตัว: %d ฟอง\nความเร็วบิน: %d Studs/s" or "Status: %s\nFarm Mode: %s\nCarried Eggs: %d\nFlight Speed: %d Studs/s"
                        local k=string.format (j,u,e,r,h.glideSpeed or 600 )pcall(function(...) Fk.paraLiveDash :SetDesc(k)
                        end
                        )
                    end
                end
                )task.wait ( 0.5 )
            end
        end
        )e(R)
        return
    end
    if h.gui then
        pcall(function(...) h.gui :Destroy()
        end
        )h.gui =nil
    end
    local k=Instance.new ( "ScreenGui" )k.Name = "DesyncSniperUI_v41_5" k.ResetOnSpawn = false k.DisplayOrder = 99999 k.ZIndexBehavior =Enum.ZIndexBehavior.Sibling k.AutoLocalize = false
    local a=o:FindFirstChild( "PlayerGui" )or game:GetService( "CoreGui" )pcall(function(...)
        if syn and syn.protect_gui then
            syn.protect_gui (k)k.Parent =game:GetService( "CoreGui" )
        else
            k.Parent =a
        end
    end
    )
    if not k.Parent then
        k.Parent =a
    end
    h.gui =k
    local V=Color3.fromRGB ( 15 , 17 , 24 )
    local H=Color3.fromRGB ( 20 , 24 , 34 )
    local t=Color3.fromRGB ( 22 , 26 , 38 )
    local s=Color3.fromRGB ( 28 , 33 , 48 )
    local p=Color3.fromRGB ( 45 , 52 , 75 )
    local B=Color3.fromRGB ( 240 , 243 , 255 )
    local J=Color3.fromRGB ( 140 , 148 , 170 )
    local K=Color3.fromRGB ( 38 , 43 , 60 )
    local c=Color3.fromRGB ( 150 , 158 , 180 )
    local v=Color3.fromRGB ( 255 , 255 , 255 )
    local i= 475
    local R= 46
    local g= false
    local Q=Instance.new ( "Frame" )Q.Name = "MainFrame" Q.Size =UDim2.new ( 0 , 360 , 0 ,i)Q.Position =UDim2.new ( 0.5 , -180 , 0.18 , 0 )Q.BackgroundColor3 =V Q.BorderSizePixel = 0 Q.Active = true Q.Draggable = true Q.ClipsDescendants = true Q.Parent =k
    local P=Instance.new ( "UICorner" )P.CornerRadius =UDim.new ( 0 , 16 )P.Parent =Q
    local N=Instance.new ( "UIStroke" )N.Color =Color3.fromRGB ( 0 , 185 , 255 )N.Transparency = 0.35 N.Thickness = 1.5 N.Parent =Q
    local Z=Instance.new ( "UIGradient" )Z.Rotation = 90 Z.Color =ColorSequence.new ({ColorSequenceKeypoint.new ( 0 ,Color3.fromRGB ( 18 , 22 , 32 )),ColorSequenceKeypoint.new ( 1 ,Color3.fromRGB ( 10 , 12 , 18 ))})Z.Parent =Q
    local U=Instance.new ( "Frame" )U.Name = "Header" U.Size =UDim2.new ( 1 , 0 , 0 , 54 )U.BackgroundColor3 =Color3.fromRGB(37, 25, 62) U.BorderSizePixel = 0 U.Parent =Q;
    (Instance.new ( "UICorner" ,U)).CornerRadius =UDim.new ( 0 , 16 )
    local UG=Instance.new ( "UIGradient" )UG.Rotation = 0 UG.Color =ColorSequence.new ({ColorSequenceKeypoint.new ( 0 ,Color3.fromRGB ( 62 , 35 , 92 )),ColorSequenceKeypoint.new ( 0.55 ,Color3.fromRGB ( 28 , 48 , 78 )),ColorSequenceKeypoint.new ( 1 ,Color3.fromRGB ( 17 , 25 , 48 ))})UG.Parent =U
    local Accent=Instance.new ( "Frame" )Accent.Size =UDim2.new ( 1 , 0 , 0 , 2 )Accent.Position =UDim2.new ( 0 , 0 , 1 , -2 )Accent.BackgroundColor3 =Color3.fromRGB ( 78 , 220 , 255 )Accent.BorderSizePixel = 0 Accent.Parent =U
    local l=Instance.new ( "TextLabel" )l.Size =UDim2.new ( 1 , -105 , 0 , 22 )l.Position =UDim2.new ( 0 , 14 , 0 , 7 )l.BackgroundTransparency = 1 l.Text = "Ken Hub (Fallback)" l.TextColor3 =B l.TextSize = 14 l.Font =Enum.Font.GothamBold l.TextXAlignment =Enum.TextXAlignment.Left l.AutoLocalize = false l.Parent =U
    local D=Instance.new ( "TextLabel" )D.Size =UDim2.new ( 1 , -105 , 0 , 14 )D.Position =UDim2.new ( 0 , 14 , 0 , 31 )D.BackgroundTransparency = 1 D.Text = "Steal an Egg v42.64" D.TextColor3 =Color3.fromRGB ( 80 , 235 , 190 )D.TextSize = 11 D.Font =Enum.Font.Gotham D.TextXAlignment =Enum.TextXAlignment.Left D.AutoLocalize = false D.Parent =U
    
    -- Easy drag: click/touch anywhere on the colored header and move the hub.
    -- The close/minimize buttons still consume their own clicks.
    local dragging = false
    local dragStart = nil
    local startPos = nil

    U.InputBegan:Connect(function(input)
        if input.UserInputType == Enum.UserInputType.MouseButton1
            or input.UserInputType == Enum.UserInputType.Touch then
            local localX = input.Position.X - U.AbsolutePosition.X
            local localY = input.Position.Y - U.AbsolutePosition.Y

            -- Keep the two right-side buttons clickable.
            if localX < U.AbsoluteSize.X - 105 then
                dragging = true
                dragStart = input.Position
                startPos = Q.Position

                input.Changed:Connect(function()
                    if input.UserInputState == Enum.UserInputState.End then
                        dragging = false
                    end
                end)
            end
        end
    end)

    w.InputChanged:Connect(function(input)
        if not dragging then return end
        if input.UserInputType ~= Enum.UserInputType.MouseMovement
            and input.UserInputType ~= Enum.UserInputType.Touch then
            return
        end

        local delta = input.Position - dragStart
        Q.Position = UDim2.new(
            startPos.X.Scale,
            startPos.X.Offset + delta.X,
            startPos.Y.Scale,
            startPos.Y.Offset + delta.Y
        )
    end)

    local C=Instance.new ( "TextButton" )C.Size =UDim2.new ( 0 , 30 , 0 , 30 )C.Position =UDim2.new ( 1 , -72 , 0 , 12 )C.BackgroundColor3 =t C.Text = "-" C.TextColor3 =B C.TextSize = 16 C.Font =Enum.Font.GothamBold C.AutoButtonColor = false C.Parent =U;
    (Instance.new ( "UICorner" ,C)).CornerRadius =UDim.new ( 0 , 8 )
    C.MouseEnter:Connect(function(...) (u:Create(C,TweenInfo.new(0.12,Enum.EasingStyle.Quart,Enum.EasingDirection.Out),{BackgroundColor3=Color3.fromRGB(38,45,62)})):Play() end)
    C.MouseLeave:Connect(function(...) (u:Create(C,TweenInfo.new(0.16,Enum.EasingStyle.Quart,Enum.EasingDirection.Out),{BackgroundColor3=t})):Play() end)
    local q=Instance.new ( "TextButton" )q.Size =UDim2.new ( 0 , 30 , 0 , 30 )q.Position =UDim2.new ( 1 , -38 , 0 , 12 )q.BackgroundColor3 =Color3.fromRGB ( 239 , 68 , 68 )q.Text = "X" q.TextColor3 =B q.TextSize = 12 q.Font =Enum.Font.GothamBold q.AutoButtonColor = false q.Parent =U;
    (Instance.new ( "UICorner" ,q)).CornerRadius =UDim.new ( 0 , 8 )
    q.MouseEnter:Connect(function(...) (u:Create(q,TweenInfo.new(0.12,Enum.EasingStyle.Quart,Enum.EasingDirection.Out),{BackgroundColor3=Color3.fromRGB(255,82,82)})):Play() end)
    q.MouseLeave:Connect(function(...) (u:Create(q,TweenInfo.new(0.16,Enum.EasingStyle.Quart,Enum.EasingDirection.Out),{BackgroundColor3=Color3.fromRGB(239,68,68)})):Play() end)
    local n=Instance.new ( "ScrollingFrame" )n.Size =UDim2.new ( 1 , 0 , 1 , -54 )n.Position =UDim2.new ( 0 , 0 , 0 , 54 )n.BackgroundTransparency = 1 n.BorderSizePixel = 0 n.ScrollBarThickness = 3 n.ScrollBarImageColor3 =p n.CanvasSize =UDim2.new ( 0 , 0 , 0 , 0 )n.AutomaticCanvasSize =Enum.AutomaticSize.Y n.Parent =Q
    local I=Instance.new ( "UIListLayout" )I.SortOrder =Enum.SortOrder.LayoutOrder I.Padding =UDim.new ( 0 , 8 )I.Parent =n
    local L=Instance.new ( "UIPadding" )L.PaddingTop =UDim.new ( 0 , 10 )L.PaddingBottom =UDim.new ( 0 , 14 )L.PaddingLeft =UDim.new ( 0 , 12 )L.PaddingRight =UDim.new ( 0 , 12 )L.Parent =n C.MouseButton1Click :Connect(function(...) g=not g C.Text =g and "+" or "-" ;
        (u:Create(Q,TweenInfo.new ( 0.25 ,Enum.EasingStyle.Quart ,Enum.EasingDirection.Out ),{[ "Size" ]=g and UDim2.new ( 0 , 360 , 0 ,R)or UDim2.new ( 0 , 360 , 0 ,i)})):Play()
    end
    )q.MouseButton1Click :Connect(function(...) aM()
    end
    )
    local function E(e,r,...)
        local y=Instance.new ( "Frame" )y.Size =UDim2.new ( 1 , 0 , 0 , 20 )y.BackgroundTransparency = 1 y.LayoutOrder =r y.Parent =n
        local u=Instance.new ( "TextLabel" )u.Size =UDim2.new ( 1 , 0 , 1 , 0 )u.BackgroundTransparency = 1 u.Text =e u.TextColor3 =Color3.fromRGB ( 185 , 125 , 255 )u.TextSize = 11 u.Font =Enum.Font.GothamBold u.TextXAlignment =Enum.TextXAlignment.Left u.AutoLocalize = false u.Parent =y
        return y
    end
    local function b(e,r,y,w,j,k,...)
        local a=Instance.new ( "Frame" )a.Size =UDim2.new ( 1 , 0 , 0 , 52 )a.BackgroundColor3 =t a.LayoutOrder =j a.Parent =n;
        (Instance.new ( "UICorner" ,a)).CornerRadius =UDim.new ( 0 , 10 )
        local AS=Instance.new ( "UIStroke" ,a )AS.Color =Color3.fromRGB ( 55 , 66 , 92 )AS.Transparency = 0.72 AS.Thickness = 1
        local o=Instance.new ( "TextLabel" )o.Size =UDim2.new ( 1 , -60 , 0 , 18 )o.Position =UDim2.new ( 0 , 10 , 0 , 8 )o.BackgroundTransparency = 1 o.Text =e o.TextColor3 =w or B o.TextSize = 13 o.Font =Enum.Font.GothamBold o.TextXAlignment =Enum.TextXAlignment.Left o.AutoLocalize = false o.Parent =a
        local V=Instance.new ( "TextLabel" )V.Size =UDim2.new ( 1 , -60 , 0 , 16 )V.Position =UDim2.new ( 0 , 10 , 0 , 26 )V.BackgroundTransparency = 1 V.Text =r V.TextColor3 =J V.TextSize = 10 V.Font =Enum.Font.Gotham V.TextXAlignment =Enum.TextXAlignment.Left V.AutoLocalize = false V.Parent =a
        local H=Instance.new ( "TextButton" )H.Size =UDim2.new ( 0 , 44 , 0 , 24 )H.Position =UDim2.new ( 1 , -54 , 0.5 , -12 )H.BackgroundColor3 =y and w or K H.Text = "" H.AutoButtonColor = false H.Parent =a;
        (Instance.new ( "UICorner" ,H)).CornerRadius =UDim.new ( 1 , 0 )
        local s=Instance.new ( "Frame" )s.Size =UDim2.new ( 0 , 18 , 0 , 18 )s.Position =y and UDim2.new ( 1 , -21 , 0.5 , -9 )or UDim2.new ( 0 , 3 , 0.5 , -9 )s.BackgroundColor3 =y and v or c s.Parent =H;
        (Instance.new ( "UICorner" ,s)).CornerRadius =UDim.new ( 1 , 0 )
        local p=y
        local function i(e,...) p=e
            local r=TweenInfo.new ( 0.18 ,Enum.EasingStyle.Quart ,Enum.EasingDirection.Out );
            (u:Create(H,r,{[ "BackgroundColor3" ]=p and w or K})):Play();
            (u:Create(s,r,{[ "Position" ]=p and UDim2.new ( 1 , -21 , 0.5 , -9 )or UDim2.new ( 0 , 3 , 0.5 , -9 );
            [ "BackgroundColor3" ]=p and v or c})):Play()
        end
        H.MouseEnter:Connect(function(...)
            (u:Create(a,TweenInfo.new(0.14,Enum.EasingStyle.Quart,Enum.EasingDirection.Out),{BackgroundColor3=Color3.fromRGB(27,32,46)})):Play()
        end)
        H.MouseLeave:Connect(function(...)
            (u:Create(a,TweenInfo.new(0.18,Enum.EasingStyle.Quart,Enum.EasingDirection.Out),{BackgroundColor3=t})):Play()
        end)
        H.MouseButton1Click :Connect(function(...)
            local e=not p i(e)k(e)
        end
        )
        return i
    end
    local function A(e,r,y,u,w,...)
        local j=Instance.new ( "Frame" )j.Size =UDim2.new ( 1 , 0 , 0 , 48 )j.BackgroundColor3 =t j.LayoutOrder =u j.Parent =n;
        (Instance.new ( "UICorner" ,j)).CornerRadius =UDim.new ( 0 , 10 )
        local JS=Instance.new ( "UIStroke" ,j )JS.Color =Color3.fromRGB ( 55 , 66 , 92 )JS.Transparency = 0.72 JS.Thickness = 1
        local k=Instance.new ( "TextLabel" )k.Size =UDim2.new ( 1 , -95 , 0 , 18 )k.Position =UDim2.new ( 0 , 10 , 0 , 6 )k.BackgroundTransparency = 1 k.Text =e k.TextColor3 =y or B k.TextSize = 13 k.Font =Enum.Font.GothamBold k.TextXAlignment =Enum.TextXAlignment.Left k.AutoLocalize = false k.Parent =j
        local a=Instance.new ( "TextLabel" )a.Size =UDim2.new ( 1 , -95 , 0 , 16 )a.Position =UDim2.new ( 0 , 10 , 0 , 24 )a.BackgroundTransparency = 1 a.Text =r a.TextColor3 =J a.TextSize = 10 a.Font =Enum.Font.Gotham a.TextXAlignment =Enum.TextXAlignment.Left a.AutoLocalize = false a.Parent =j
        local o=Instance.new ( "TextButton" )o.Size =UDim2.new ( 0 , 78 , 0 , 30 )o.Position =UDim2.new ( 1 , -86 , 0.5 , -15 )o.BackgroundColor3 =y o.Text = "RUN" o.TextColor3 =Color3.fromRGB ( 255 , 255 , 255 )o.TextSize = 11 o.Font =Enum.Font.GothamBold o.AutoButtonColor = false o.Parent =j;
        (Instance.new ( "UICorner" ,o)).CornerRadius =UDim.new ( 0 , 8 )
        o.MouseEnter:Connect(function(...) (u:Create(o,TweenInfo.new(0.12,Enum.EasingStyle.Quart,Enum.EasingDirection.Out),{Size=UDim2.new(0,82,0,32),BackgroundTransparency=0.05})):Play() end)
        o.MouseLeave:Connect(function(...) (u:Create(o,TweenInfo.new(0.16,Enum.EasingStyle.Quart,Enum.EasingDirection.Out),{Size=UDim2.new(0,78,0,30),BackgroundTransparency=0})):Play() end)
        o.MouseButton1Click :Connect(w)
    end
    E( "AUTO STEAL MODES" , 10 )
    local S= false
    local Z=nil
    local z=nil Z=b( "Auto Steal (Tween)" , "Fly to steal eggs & auto stash into backpack" ,h.pureTweenFarm ,Color3.fromRGB ( 0 , 195 , 255 ), 11 ,function(e,...)
        if S then
            return
        end
        if e then
            T4( "TWEEN" )
        else
            if Y4== "TWEEN" or h.pureTweenFarm then
                T4( "NONE" )
            end
        end
    end
    )z=b( "Auto Steal (Teleport)" , "Teleport to steal eggs in continuous loop" ,h.autoFarmLoop ,Color3.fromRGB ( 168 , 85 , 247 ), 12 ,function(e,...)
        if S then
            return
        end
        if e then
            T4( "WARP" )
        else
            if Y4== "WARP" or h.autoFarmLoop then
                T4( "NONE" )
            end
        end
    end
    )x4=function(e,...) pcall(function(...)
            if Z then
                S= true Z(e)S= false
            end
        end
        )
    end
    W4=function(e,...) pcall(function(...)
            if z then
                S= true z(e)S= false
            end
        end
        )
    end
    A( "Single Steal (Teleport)" , "Teleport to steal 1 target egg and return" ,Color3.fromRGB ( 59 , 130 , 246 ), 13 ,function(...) task.spawn (function(...)
            if Y4~= "NONE" then
                T4( "NONE" )task.wait ( 0.2 )
            end
            local e=N4()
            if e then
                local y=l4(e,nil)
                if y then
                    pcall(u4)
                    if h.autoGlide then
                        Q4(h.glideSpeed )u4()
                    end
                end
            end
        end
        )
    end
    )E( "PLACE EGG" , 20 )A( "Place Egg" , "Tween home, place all carried eggs & hatch" ,Color3.fromRGB ( 16 , 215 , 130 ), 21 ,function(...) task.spawn (function(...) h.statusText = "[Manual] Depositing eggs..." g4(h.glideSpeed )v4()u4()h.isReturning = false h.delivering = false
        end
        )
    end
    )b( "Auto Place (Every 5)" , "Return home every 5 steals, place & wait 5s" ,h.autoPlaceEvery5 ,Color3.fromRGB ( 14 , 165 , 233 ), 22 ,function(e,...) h.autoPlaceEvery5 =e
        if not e then
            h.batchStealCount = 0
        end
    end
    )b( "Auto Hatch" , "Automatically hatch ready eggs continuously" ,h.autoHatch ,Color3.fromRGB ( 16 , 185 , 129 ), 22 ,function(e,...) h.autoHatch =e
    end
    )b( "Auto Return" , "Automatically return to safe area after stealing" ,h.autoGlide ,Color3.fromRGB ( 245 , 158 , 11 ), 23 ,function(e,...) h.autoGlide =e
    end
    )b( "Auto Treadmill" , "Run on base treadmill when no target eggs are spawned" ,h.autoTreadmill ,Color3.fromRGB ( 168 , 85 , 247 ), 24 ,function(e,...) h.autoTreadmill =e x()n4()
        if not e and((h.onTreadmill or L4()))then
            M4()
        end
    end
    )E( "CHARACTER & SAFETY" , 30 )b( "Godmode" , "Invincible against attacks and guards" , false ,Color3.fromRGB ( 244 , 63 , 94 ), 31 ,function(e,...)
        if e then
            enableDesyncGodmode()
        else
            disableDesyncGodmode()
        end
    end
    )A( "Get Out Treadmill" , "Instantly escape from treadmill or gear" ,Color3.fromRGB ( 249 , 115 , 22 ), 32 ,function(...) pcall(M4)pcall(C4)pcall(D4)
    end
    )E( "CONTROLS & SETTINGS" , 40 )
    local F=Instance.new ( "Frame" )F.Size =UDim2.new ( 1 , 0 , 0 , 48 )F.BackgroundColor3 =Color3.fromRGB ( 31 , 38 , 58 ) F.LayoutOrder = 41 F.Parent =n;
    (Instance.new ( "UICorner" ,F)).CornerRadius =UDim.new ( 0 , 8 )
    local O=Instance.new ( "TextLabel" )O.Size =UDim2.new ( 1 , -130 , 0 , 18 )O.Position =UDim2.new ( 0 , 10 , 0 , 6 )O.BackgroundTransparency = 1 O.Text = "Flight Speed" O.TextColor3 =B O.TextSize = 13 O.Font =Enum.Font.GothamBold O.TextXAlignment =Enum.TextXAlignment.Left O.AutoLocalize = false O.Parent =F
    local T=Instance.new ( "TextLabel" )T.Size =UDim2.new ( 0 , 70 , 0 , 24 )T.Position =UDim2.new ( 1 , -80 , 0.5 , -12 )T.BackgroundColor3 =V T.Text =string.format ( "%d Studs/s" ,h.glideSpeed or 600 )T.TextColor3 =Color3.fromRGB ( 0 , 255 , 160 )T.TextSize = 11 T.Font =Enum.Font.GothamBold T.AutoLocalize = false T.Parent =F;
    (Instance.new ( "UICorner" ,T)).CornerRadius =UDim.new ( 0 , 6 )
    local W=Instance.new ( "TextButton" )W.Size =UDim2.new ( 0 , 24 , 0 , 24 )W.Position =UDim2.new ( 1 , -110 , 0.5 , -12 )W.BackgroundColor3 =s W.Text = "-" W.TextColor3 =B W.TextSize = 14 W.Font =Enum.Font.GothamBold W.Parent =F;
    (Instance.new ( "UICorner" ,W)).CornerRadius =UDim.new ( 0 , 6 )
    local m=Instance.new ( "TextButton" )m.Size =UDim2.new ( 0 , 24 , 0 , 24 )m.Position =UDim2.new ( 1 , -138 , 0.5 , -12 )m.BackgroundColor3 =s m.Text = "+" m.TextColor3 =B m.TextSize = 14 m.Font =Enum.Font.GothamBold m.Parent =F;
    (Instance.new ( "UICorner" ,m)).CornerRadius =UDim.new ( 0 , 6 )W.MouseButton1Click :Connect(function(...) h.glideSpeed =math.max ( 100 ,((h.glideSpeed or 600 ))- 25 )T.Text =string.format ( "%d Studs/s" ,h.glideSpeed )Y(h.glideSpeed )
    end
    )m.MouseButton1Click :Connect(function(...) h.glideSpeed =math.min ( 1000 ,((h.glideSpeed or 600 ))+ 25 )T.Text =string.format ( "%d Studs/s" ,h.glideSpeed )Y(h.glideSpeed )
    end
    )A( "Reset Character State" , "Clear velocity, cancel push & unfreeze" ,Color3.fromRGB ( 99 , 102 , 241 ), 42 ,function(...) pcall(D4)pcall(u4)
    end
    )A( "Unload Script" , "Destroy UI and stop all background loops" ,Color3.fromRGB ( 153 , 27 , 27 ), 43 ,function(...) aM()
    end
    )E( "EGG SELECT (ZONES & RARITIES)" , 45 )
    local e4=Instance.new ( "TextButton" )e4.Size =UDim2.new ( 1 , 0 , 0 , 48 )e4.BackgroundColor3 =Color3.fromRGB ( 31 , 38 , 58 ) e4.LayoutOrder = 46 e4.Text = "" e4.AutoButtonColor = false e4.Parent =n;
    (Instance.new ( "UICorner" ,e4)).CornerRadius =UDim.new ( 0 , 8 )
    local function r4(...)
        local e= 0
        for y,u in ipairs(M)do
            if h.selectedZones and h.selectedZones [u]then
                e=e+ 1
            end
        end
        return e
    end
    local w4=Instance.new ( "TextLabel" )w4.Size =UDim2.new ( 1 , -50 , 0 , 18 )w4.Position =UDim2.new ( 0 , 10 , 0 , 6 )w4.BackgroundTransparency = 1 w4.Text =string.format ( "📍 Target Zones (%d/12 Active)" ,r4())w4.TextColor3 =Color3.fromRGB ( 0 , 220 , 255 )w4.TextSize = 13 w4.Font =Enum.Font.GothamBold w4.TextXAlignment =Enum.TextXAlignment.Left w4.AutoLocalize = false w4.Parent =e4
    local j4=Instance.new ( "TextLabel" )j4.Size =UDim2.new ( 1 , -50 , 0 , 16 )j4.Position =UDim2.new ( 0 , 10 , 0 , 26 )j4.BackgroundTransparency = 1 j4.Text = "Click to expand / collapse zone selection" j4.TextColor3 =J j4.TextSize = 10 j4.Font =Enum.Font.Gotham j4.TextXAlignment =Enum.TextXAlignment.Left j4.AutoLocalize = false j4.Parent =e4
    local k4=Instance.new ( "TextLabel" )k4.Size =UDim2.new ( 0 , 30 , 0 , 30 )k4.Position =UDim2.new ( 1 , -38 , 0.5 , -15 )k4.BackgroundTransparency = 1 k4.Text = "▼" k4.TextColor3 =J k4.TextSize = 12 k4.Font =Enum.Font.GothamBold k4.Parent =e4
    local a4=Instance.new ( "Frame" )a4.Size =UDim2.new ( 1 , 0 , 0 , 0 )a4.BackgroundColor3 =Color3.fromRGB ( 18 , 20 , 28 )a4.LayoutOrder = 47 a4.Visible = false a4.ClipsDescendants = true a4.Parent =n;
    (Instance.new ( "UICorner" ,a4)).CornerRadius =UDim.new ( 0 , 8 )
    local o4=Instance.new ( "UIGridLayout" )o4.CellSize =UDim2.new ( 0.48 , 0 , 0 , 32 )o4.CellPadding =UDim2.new ( 0.04 , 0 , 0 , 6 )o4.SortOrder =Enum.SortOrder.LayoutOrder o4.Parent =a4;
    (Instance.new ( "UIPadding" ,a4)).PaddingTop =UDim.new ( 0 , 8 )a4.UIPadding.PaddingBottom =UDim.new ( 0 , 8 )a4.UIPadding.PaddingLeft =UDim.new ( 0 , 8 )a4.UIPadding.PaddingRight =UDim.new ( 0 , 8 )
    local V4={}
    for e,r in ipairs(M)do
        local y=Instance.new ( "TextButton" )y.LayoutOrder =e y.Font =Enum.Font.GothamBold y.TextSize = 11 y.AutoButtonColor = false y.AutoLocalize = false ;
        (Instance.new ( "UICorner" ,y)).CornerRadius =UDim.new ( 0 , 6 )
        local function u(...)
            local e=h.selectedZones and h.selectedZones [r]== true
            if e then
                y.BackgroundColor3 =d[r]or Color3.fromRGB ( 59 , 130 , 246 )y.TextColor3 =Color3.new ( 1 , 1 , 1 )y.Text = "✓ " ..r
            else
                y.BackgroundColor3 =Color3.fromRGB ( 28 , 32 , 44 )y.TextColor3 =Color3.fromRGB ( 140 , 150 , 170 )y.Text =r
            end
        end
        u()
        y.MouseEnter:Connect(function(...) (u:Create(y,TweenInfo.new(0.11,Enum.EasingStyle.Quart,Enum.EasingDirection.Out),{BackgroundTransparency=0.12})):Play() end)
        y.MouseLeave:Connect(function(...) (u:Create(y,TweenInfo.new(0.15,Enum.EasingStyle.Quart,Enum.EasingDirection.Out),{BackgroundTransparency=0})):Play() end)
        y.MouseButton1Click :Connect(function(...)
            if not h.selectedZones then
                h.selectedZones ={}
            end
            h.selectedZones [r]=not((h.selectedZones [r]== true ))u()x()w4.Text =string.format ( "📍 Target Zones (%d/12 Active)" ,r4())
        end
        )y.Parent =a4 V4[r]=y
    end
    local H4= false e4.MouseButton1Click :Connect(function(...) H4=not H4 a4.Visible =true (u:Create(a4,TweenInfo.new(0.22,Enum.EasingStyle.Quart,Enum.EasingDirection.Out),{Size=H4 and UDim2.new(1,0,0,240) or UDim2.new(1,0,0,0)})):Play() k4.Text =H4 and "▲" or "▼" task.delay(0.23,function(...) if not H4 then a4.Visible=false end end)
    end
    )
    local function t4(...)
        local e= 0
        for y,u in ipairs(X)do
            if h.selectedRarities and h.selectedRarities [u]then
                e=e+ 1
            end
        end
        return e
    end
    local s4=Instance.new ( "TextButton" )s4.Size =UDim2.new ( 1 , 0 , 0 , 48 )s4.BackgroundColor3 =Color3.fromRGB ( 31 , 38 , 58 ) s4.LayoutOrder = 48 s4.Text = "" s4.AutoButtonColor = false s4.Parent =n;
    (Instance.new ( "UICorner" ,s4)).CornerRadius =UDim.new ( 0 , 8 )
    local p4=Instance.new ( "TextLabel" )p4.Size =UDim2.new ( 1 , -50 , 0 , 18 )p4.Position =UDim2.new ( 0 , 10 , 0 , 6 )p4.BackgroundTransparency = 1 p4.Text =string.format ( "🥚 Target Rarities (%d/%d Active)" ,t4(),#X)p4.TextColor3 =Color3.fromRGB ( 255 , 180 , 0 )p4.TextSize = 13 p4.Font =Enum.Font.GothamBold p4.TextXAlignment =Enum.TextXAlignment.Left p4.AutoLocalize = false p4.Parent =s4
    local B4=Instance.new ( "TextLabel" )B4.Size =UDim2.new ( 1 , -50 , 0 , 16 )B4.Position =UDim2.new ( 0 , 10 , 0 , 26 )B4.BackgroundTransparency = 1 B4.Text = "Click to expand / collapse rarity selection" B4.TextColor3 =J B4.TextSize = 10 B4.Font =Enum.Font.Gotham B4.TextXAlignment =Enum.TextXAlignment.Left B4.AutoLocalize = false B4.Parent =s4
    local J4=Instance.new ( "TextLabel" )J4.Size =UDim2.new ( 0 , 30 , 0 , 30 )J4.Position =UDim2.new ( 1 , -38 , 0.5 , -15 )J4.BackgroundTransparency = 1 J4.Text = "▼" J4.TextColor3 =J J4.TextSize = 12 J4.Font =Enum.Font.GothamBold J4.Parent =s4
    local K4=Instance.new ( "Frame" )K4.Size =UDim2.new ( 1 , 0 , 0 , 0 )K4.BackgroundColor3 =Color3.fromRGB ( 18 , 20 , 28 )K4.LayoutOrder = 49 K4.Visible = false K4.ClipsDescendants = true K4.Parent =n;
    (Instance.new ( "UICorner" ,K4)).CornerRadius =UDim.new ( 0 , 8 )
    local c4=Instance.new ( "UIGridLayout" )c4.CellSize =UDim2.new ( 0.48 , 0 , 0 , 32 )c4.CellPadding =UDim2.new ( 0.04 , 0 , 0 , 6 )c4.SortOrder =Enum.SortOrder.LayoutOrder c4.Parent =K4;
    (Instance.new ( "UIPadding" ,K4)).PaddingTop =UDim.new ( 0 , 8 )K4.UIPadding.PaddingBottom =UDim.new ( 0 , 8 )K4.UIPadding.PaddingLeft =UDim.new ( 0 , 8 )K4.UIPadding.PaddingRight =UDim.new ( 0 , 8 )
    for e,r in ipairs(X)do
        local y=Instance.new ( "TextButton" )y.LayoutOrder =e y.Font =Enum.Font.GothamBold y.TextSize = 11 y.AutoButtonColor = false y.AutoLocalize = false ;
        (Instance.new ( "UICorner" ,y)).CornerRadius =UDim.new ( 0 , 6 )
        local function u(...)
            local e=h.selectedRarities and h.selectedRarities [r]== true
            if e then
                y.BackgroundColor3 =G[r]or Color3.fromRGB ( 249 , 115 , 22 )y.TextColor3 =Color3.new ( 1 , 1 , 1 )y.Text = "✓ " ..r
            else
                y.BackgroundColor3 =Color3.fromRGB ( 28 , 32 , 44 )y.TextColor3 =Color3.fromRGB ( 140 , 150 , 170 )y.Text =r
            end
        end
        u()
        y.MouseEnter:Connect(function(...) (u:Create(y,TweenInfo.new(0.11,Enum.EasingStyle.Quart,Enum.EasingDirection.Out),{BackgroundTransparency=0.12})):Play() end)
        y.MouseLeave:Connect(function(...) (u:Create(y,TweenInfo.new(0.15,Enum.EasingStyle.Quart,Enum.EasingDirection.Out),{BackgroundTransparency=0})):Play() end)
        y.MouseButton1Click :Connect(function(...)
            if not h.selectedRarities then
                h.selectedRarities ={}
            end
            h.selectedRarities [r]=not((h.selectedRarities [r]== true ))u()x()p4.Text =string.format ( "🥚 Target Rarities (%d/%d Active)" ,t4(),#X)
        end
        )y.Parent =K4
    end
    local i4= false s4.MouseButton1Click :Connect(function(...) i4=not i4 K4.Visible =true (u:Create(K4,TweenInfo.new(0.22,Enum.EasingStyle.Quart,Enum.EasingDirection.Out),{Size=i4 and UDim2.new(1,0,0,160) or UDim2.new(1,0,0,0)})):Play() J4.Text =i4 and "▲" or "▼" task.delay(0.23,function(...) if not i4 then K4.Visible=false end end)
    end
    )e(function(...) Q.Visible = true
    end
    )
end
H( "[+] Initializing Ken Hub x WindUI v42.64 (Steal an Egg Edition)..." )oM()task.spawn (function(...) task.wait ( 0.5 )A4()b4( true )C4()
    if o.Character then
        z4(o.Character )
    end
    u4()H( "[+] Auto Humanoid Swap & Rigid Joint Locking Active." )
end
)o.CharacterAdded :Connect(function(e,...) task.wait ( 0.6 )
    if h.alive then
        D4()n4()C4()A4()b4( true )z4(e)u4()
    end
end
)
if h.performanceMode then
    task.spawn (Mk)
end
if h.disable3D then
    pcall(function(...) y:Set3dRenderingEnabled( false )
    end
    )
end
if h.antiAFK then
    task.spawn (bk)
end
H( "[+] Ken Hub v42.64 Ready! All-In-One Built-in Anti-AFK & Prometheus Ready!" )